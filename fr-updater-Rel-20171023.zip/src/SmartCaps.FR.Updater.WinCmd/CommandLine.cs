﻿using Apache.NMS;
using Apache.NMS.ActiveMQ;
using CLAP;
using log4net;
using SmartCaps.FR.NetMessaging.Services.ActiveMQ;
using SmartCaps.FR.Updater.Services;
using System;

namespace SmartCaps.FR.Updater.WinCmd
{
    public class CommandLine
    {
        private ILog log;

        public CommandLine(ILog log)
        {
            if (log == null)
            {
                throw new ArgumentNullException("log");
            }

            this.log = log;
        }

        [Help(Aliases = "h,?"), Empty]
        public void Help(string help)
        {
            Console.WriteLine(help);
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }

        [Verb(Description = "Listens to ActiveMQ SmartCaps.FR commands", IsDefault = true, Aliases = "l")]
        public void Listen(
        [Description("ActiveMQ server conn string.")][DefaultValue("activemq:tcp://localhost:61616")] string activeMqConn,
        [Description("ActiveMQ server user.")][DefaultValue("admin")] string user,
        [Description("ActiveMQ server password.")][DefaultValue("admin")] string pwd,
        [Description("Face service user.")][DefaultValue("erpl")] string svcUser,
        [Description("Face service password.")][DefaultValue("ABCabc123.")] string svcPwd,
        [Description("ActiveMQ queue to listen to.")][DefaultValue("SmartCaps.FR.Updater")] string queueName,
        [Description("FacesDB conn string.")][DefaultValue(@"Data Source=.\SQLEXPRESS;Initial Catalog=FaceRec;Integrated Security=True")] string facesDbConn,
        [Description("CommandsDB conn string.")][DefaultValue(@"Data Source=.\SQLEXPRESS;Initial Catalog=FaceRec;Integrated Security=True")] string cmdDbConn,
        [Description("Face recognition API server.")][DefaultValue("http://localhost:34456")] string faceRecognitionServer,
        [Description("Faces batch size for re-enroll process.")][DefaultValue(1000)] int reEnrollBatchSize,
        [Description("Delayed run interval for KNN feed in milliseconds.")][DefaultValue("30000")] string delayedKnnInterval,
        [Description("Delayed run batch size for KNN feed.")][DefaultValue(1000)] int delayedKnnBatchSize,
        [Description("Delayed run max items.")][DefaultValue(0)] int delayedKnnMaxItems,
        [Description("Face database commands timeout in seconds.")][DefaultValue(120)] int faceDbCommandsTimeOut,
        [Description("Commands database commands timeout in seconds.")][DefaultValue(120)] int cmdsDbCommandsTimeOut,
        [Description("Commands cleaning interval in milliseconds.")][DefaultValue(60000)] int commandsCleaningInterval,
        [Description("Age in days of the commands to maintain.")][DefaultValue(7)] int ageInDaysOfCommandsToMaintain,
        [Description("Verbose mode.")][DefaultValue(false)] bool verbose)
        {
            this.BeVerbose(verbose);

            IConnectionFactory connectionFactory = new ConnectionFactory(new Uri(activeMqConn));

            using (IConnection connection = connectionFactory.CreateConnection(user, pwd))
            using (ISession session = connection.CreateSession(AcknowledgementMode.ClientAcknowledge))
            {
                var cmdRepo = new Common.Repos.SQLServer.SQLServerCommandRepository(cmdDbConn, cmdsDbCommandsTimeOut, this.log);
                var faceRepo = new Common.Repos.SQLServer.SQLServerFaceRepository(facesDbConn, faceDbCommandsTimeOut, this.log);

                var publisherToKnn = new ActiveMQPublisherService(session, "queue://SmartCaps.FR.Knn", this.log);
                var publisherSvc = new ActiveMQPublisherService(session, "topic://SmartCaps_TOPIC", this.log);

                MatchConfiguration matchConf = new MatchConfiguration();
                matchConf.GetFromApiServer(new Uri(faceRecognitionServer), svcUser, svcPwd, this.log);

                PendingFacesProcessorResolver pendingFacesProcessorResolver = new PendingFacesProcessorResolver(delayedKnnBatchSize, delayedKnnMaxItems, publisherToKnn, faceRepo, this.log);
                IDelayedProcessor delayedEvaluator = pendingFacesProcessorResolver.GetProcessorBasedOnInterval(delayedKnnInterval);
                CommandsCleaner commandsCleaner = new CommandsCleaner(commandsCleaningInterval, ageInDaysOfCommandsToMaintain, cmdRepo, log);

                UpdaterMessagesProcessor messagesProcessor = new UpdaterMessagesProcessor(
                    new ActiveMQConsumerService(session, queueName, ProcessorType.TextMessages, this.log),
                    new UpdaterService(cmdRepo, faceRepo, publisherToKnn, publisherSvc, matchConf, this.log),
                    reEnrollBatchSize,
                    this.log);

                messagesProcessor.StartListening();
                connection.Start();

                delayedEvaluator.Start();
                commandsCleaner.Start();

                this.log.Info("Service successfully started!");

                while (Console.ReadKey(true).Key != ConsoleKey.Escape) ;

                if (messagesProcessor != null)
                    messagesProcessor.StopListening();

                connection.Close();
                delayedEvaluator.Stop();
            }
        }


        private void BeVerbose(bool verbose)
        {
            if (verbose)
            {
                ((log4net.Repository.Hierarchy.Logger)this.log.Logger).Level = log4net.Core.Level.Debug;
            }
            else
            {
                ((log4net.Repository.Hierarchy.Logger)this.log.Logger).Level = log4net.Core.Level.Info;
            }
        }
    }
}
