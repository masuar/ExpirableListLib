﻿using CLAP;
using log4net;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Updater.WinCmd
{
    class Program
    {
        static void Main(string[] args)
        {
            ILog log = log4net.LogManager.GetLogger("SmartCaps.FR.Updater.WinCmd");
            log4net.Config.XmlConfigurator.Configure();

            string appVersion = typeof(CommandLine).Assembly.GetName().Version.ToString();
            string libVersion = typeof(SmartCaps.FR.Common.Model.Face).Assembly.GetName().Version.ToString();

            Console.WriteLine("SmartCaps FR console application.");
            Console.WriteLine("Version " + appVersion);
            Console.WriteLine("Europol, 2017.");
            Console.WriteLine("");
            log.InfoFormat("Subscriber application started! App. version {0}; Lib version: {1}; Params: {2}", appVersion, libVersion, string.Join(" ", args));

            CommandLine cl = new CommandLine(log);
            Parser.Run(args, cl);

            log.Info("Application exited!");


        }
    }
}
