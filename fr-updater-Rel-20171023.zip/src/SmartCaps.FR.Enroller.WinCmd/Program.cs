﻿using CLAP;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Enroller.WinCmd
{
    class Program
    {
        static void Main(string[] args)
        {
            ILog log = log4net.LogManager.GetLogger("SmartCaps.FR.Enroller");
            log4net.Config.XmlConfigurator.Configure();

            string appVersion = typeof(CommandLine).Assembly.GetName().Version.ToString();

            Console.WriteLine("SmartCaps FR enroller console application.");
            Console.WriteLine("Version " + appVersion);
            Console.WriteLine("Europol, 2017.");
            Console.WriteLine("");
            log.InfoFormat("Subscriber application started! App. version {0}; Params: {1}", appVersion, string.Join(" ", args));

            CommandLine cl = new CommandLine(log);

            Parser.Run(args, cl);

            log.Info("Application exited!");
        }
    }
}
