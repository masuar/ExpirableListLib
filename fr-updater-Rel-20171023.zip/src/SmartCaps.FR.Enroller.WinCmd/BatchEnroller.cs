﻿using log4net;
using Newtonsoft.Json;
using ShellProgressBar;
using SmartCaps.FR.Updater.ImageFileReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Enroller.WinCmd
{
    public class BatchEnroller
    {
        private Uri faceApiServer;
        private ILog log;
        private string basicAuthUser;
        private string basicAuthPwd;

        public BatchEnroller(Uri faceApiServer, string basicAuthUser, string basicAuthPwd, ILog log)
        {
            this.faceApiServer = faceApiServer;
            this.basicAuthUser = basicAuthUser;
            this.basicAuthPwd = basicAuthPwd;
            this.log = log;
        }

        public void EnrollFrom(IImageFileReader imagesReader, EnrollOptions options)
        {
            var files = imagesReader.GetFileNames(options.FromDate, options.ToDate, options.Skip, options.Take);
            var originalEndpoint = this.GetEndpointFromOptions(options, asReference: false);
            var sienaNumsFromParams = this.GetSienaNumsFromOptions(options);
            var focalPointsFromParams = this.GetFocalPointsFromOptions(options);

            using (var client = new HttpClient(new HttpClientHandler() { UseDefaultCredentials = true }))
            {
                var userPwString = string.Format("{0}:{1}", this.basicAuthUser, this.basicAuthPwd);
                var userPwArray = Encoding.ASCII.GetBytes(userPwString);
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(userPwArray));

                int filesCount = 0;
                foreach (var file in files)
                {
                    string endpoint = originalEndpoint;
                    filesCount++;
                    if (File.Exists(file.Path))
                    {
                        try
                        {
                            endpoint = this.GetCompleteEndpoint(sienaNumsFromParams, focalPointsFromParams, file, endpoint);

                            HttpContent fileStreamContent = new StreamContent(File.Open(file.Path, FileMode.Open, FileAccess.Read, FileShare.Read));
                            using (var formData = new MultipartFormDataContent())
                            {
                                formData.Add(fileStreamContent, "file", Path.GetFileName(file.Path));
                                var response = client.PostAsync(new Uri(this.faceApiServer, endpoint), formData).Result;
                                if (!response.IsSuccessStatusCode)
                                {
                                    this.log.ErrorFormat("File {0} - ({1}) {2} failed to enroll. Error '{3}'.", filesCount, file.Id, file.Path, response.StatusCode);
                                }
                                else
                                {
                                    this.log.InfoFormat("File {0} - ({1}) {2} was successfully enrolled.", filesCount, file.Id, Path.GetFileName(file.Path));
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            this.log.Error(String.Format("An error ocurred while processing file {0} - ({1}) {2}.", filesCount, file.Id, file.Path), ex);
                        }
                    }
                    else
                    {
                        this.log.WarnFormat("Unable to enroll file {0} - ({1}) {2}. File not found.", filesCount, file.Id, file.Path);
                    }
                }
            }

        }

        public void EnrollReferenceFrom(IImageFileReader imagesReader, EnrollOptions options)
        {
            var files = imagesReader.GetFileNames(options.FromDate, options.ToDate, options.Skip, options.Take);
            this.log.InfoFormat("{0} files to process.", files != null ? files.Count() : -1);
            var endpoint = this.GetEndpointFromOptions(options, asReference: true);
            var sienaNumsFromParams = this.GetSienaNumsFromOptions(options);
            var focalPointsFromParams = this.GetFocalPointsFromOptions(options);

            using (var client = new HttpClient(new HttpClientHandler() { UseDefaultCredentials = true }))
            {
                var userPwString = string.Format("{0}:{1}", this.basicAuthUser, this.basicAuthPwd);
                var userPwArray = Encoding.ASCII.GetBytes(userPwString);
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(userPwArray));
                int totalFiles = files.Count();
                    int filesCount = 0;
                    foreach (var file in files)
                    {
                        filesCount++;
                        if (File.Exists(file.Path))
                        {
                            try
                            {
                                endpoint = this.GetCompleteEndpoint(sienaNumsFromParams, focalPointsFromParams, file, endpoint);
                                object[] imageRefs = new object[] { new { imageId = file.Id, imagePath = (string)null, refType = imagesReader.RefType } };
                                string body = JsonConvert.SerializeObject(imageRefs);
                                HttpContent bodyContent = new StringContent(body, Encoding.UTF8, "application/json");
                                var response = client.PostAsync(new Uri(this.faceApiServer, endpoint), bodyContent).Result;
                                if (!response.IsSuccessStatusCode)
                                {
                                    this.log.ErrorFormat("File {0} - ({1}) {2} failed to enroll. Error '{2}'.", filesCount, file.Id, file.Path, response.StatusCode);
                                }
                                else
                                {
                                    this.log.InfoFormat("File {0} - ({1}) {2} was successfully enrolled.", filesCount, file.Id, Path.GetFileName(file.Path));
                                }
                            }
                            catch (Exception ex)
                            {
                                this.log.Error(String.Format("An error ocurred while processing file {0} - ({1}) {2}.", filesCount, file.Id, file.Path), ex);
                            }
                        }
                        else
                        {
                            this.log.WarnFormat("Unable to enroll file {0} - ({1}) {2}. File not found.", filesCount, file.Id, file.Path);
                        }
                    }
                //}
            }

        }

        private string GetEndpointFromOptions(EnrollOptions options, bool asReference)
        {
            string baseString = "commands/enroll/{0}";
            string imagesMode = "images";
            if (asReference)
            {
                imagesMode = "imageRefs";
            }

            baseString = string.Format(baseString, imagesMode);

            var endpoint = string.Format(baseString + "?async={0}&confirm={1}&requestedby={2}&tags={3}&faceQualityScoreThreshold={4}&batchmode={5}", 
                options.Async, 
                options.Confirm, 
                options.RequestedBy, 
                options.Tags, 
                options.FaceThreshold,
                options.Batch);

            return endpoint;
        }

        private IEnumerable<string> GetFocalPointsFromOptions(EnrollOptions options)
        {
            List<string> focalPointsFromParams = new List<string>();

            if (!string.IsNullOrEmpty(options.FocalPoints))
            {
                focalPointsFromParams.AddRange(options.FocalPoints.Split(',').Select(fp => fp.Trim()).Distinct());
            }

            return focalPointsFromParams;
        }

        private IEnumerable<string> GetSienaNumsFromOptions(EnrollOptions options)
        {
            List<string> sienaNumsFromParams = new List<string>();

            if (!string.IsNullOrEmpty(options.SienaNums))
            {
                sienaNumsFromParams.AddRange(options.SienaNums.Split(',').Select(sn => sn.Trim()).Distinct());
            }

            return sienaNumsFromParams;
        }

        private string GetCompleteEndpoint(IEnumerable<string> sienaNumsFromParams, IEnumerable<string> focalPointsFromParams, FileResult file, string endpoint)
        {
            foreach (string sienaNum in file.SienaNums)
            {
                endpoint += string.Format("&sienarefs={0}", sienaNum);
            }

            foreach (string sienaNum in sienaNumsFromParams)
            {
                if (!file.SienaNums.Contains(sienaNum))
                {
                    endpoint += string.Format("&sienarefs={0}", sienaNum);
                }
            }

            foreach (string focalPoint in file.FocalPoints)
            {
                endpoint += string.Format("&focalpoints={0}", focalPoint);
            }

            foreach (string focalPoint in focalPointsFromParams)
            {
                if (!file.FocalPoints.Contains(focalPoint))
                {
                    endpoint += string.Format("&focalpoints={0}", focalPoint);
                }
            }

            return endpoint;
        }

    }
}
