﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using SmartCaps.FR.Updater.ImageFileReader;
//using System.Data.SqlClient;
//using System.Data;

//namespace SmartCaps.FR.Enroller.Ivas
//{
//    public class OriginalsImageReader : ImageReader
//    {
        

//        public OriginalsImageReader(string connString, string caseName)
//            :base(connString, caseName, null)
//        {
//            this.theBaseQuery = "(SELECT T1.Id, T3.ImportPath + T1.OriginalDirectory + T1.FileName as FileName, T2.MimeType, T1.CreationTime, T5.Identifier, ROW_NUMBER() OVER(ORDER BY T1.CreationTime ASC) ROW_NUM FROM " +
//                                "(((EvidenceFile T1 JOIN Evidence T2 ON T1.EvidenceId = T2.Id) JOIN Source T3 ON T1.SourceId = T3.Id) JOIN CaseEvidence T4 ON T2.Id = T4.EvidenceId) JOIN [Case] T5 ON T4.CaseId = T5.Id WHERE T2.MimeType like 'image/%'{0}) ";
//        }

//        public override string PluginName
//        {
//            get
//            {
//                return "IvasOriginalFilesEnroller";
//            }
//        }

//        public override IEnumerable<FileResult> GetFileNames(DateTime fromDate, DateTime toDate, int skip, int take)
//        {
//            IList<FileResult> result = new List<FileResult>();

//            string imageFileNameQuery = ";WITH theQuery AS " +
//                                        this.theBaseQuery +
//                                        "SELECT * FROM theQuery WHERE ROW_NUM BETWEEN @Skip AND (@Skip + @Take)";

//            IList<SqlParameter> optionals = new List<SqlParameter>();
//            string filter = string.Empty;
//            if (fromDate != default(DateTime))
//            {
//                filter = " AND T1.CreationTime >= @FromDate";
//                optionals.Add(new SqlParameter("@FromDate", SqlDbType.DateTime) { Value = fromDate });
//            }

//            if (toDate != default(DateTime))
//            {
//                filter += " AND T1.CreationTime <= @ToDate";
//                optionals.Add(new SqlParameter("@ToDate", SqlDbType.DateTime) { Value = toDate });
//            }

//            if (!string.IsNullOrEmpty(this.caseName))
//            {
//                filter += " AND T5.Identifier = @CaseName";
//                optionals.Add(new SqlParameter("@CaseName", SqlDbType.NVarChar) { Value = this.caseName });
//            }

//            using (SqlConnection conn = new SqlConnection(this.connString))
//            {
//                conn.Open();
//                using (SqlCommand theCommand = new SqlCommand(string.Format(imageFileNameQuery, filter), conn))
//                {
//                    theCommand.Parameters.Add("@Skip", SqlDbType.Int).Value = skip;
//                    theCommand.Parameters.Add("@Take", SqlDbType.Int).Value = take;
//                    theCommand.Parameters.AddRange(optionals.ToArray());
//                    using (SqlDataReader reader = theCommand.ExecuteReader())
//                    {
//                        while (reader.Read())
//                        {
//                            result.Add(new FileResult(reader.GetSafeInt("Id").ToString(), reader.GetSafeString("FileName")));
//                        }
//                    }
//                }
//            }

//            return result;
//        }
//    }
//}
