﻿using log4net;
using SmartCaps.FR.Updater.ImageFileReader;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Enroller.Ivas
{
    public class ImageReader : IImageFileReader
    {
        protected string connString;
        protected ILog log;
        protected string caseName;
        protected string basePath;
        protected string theBaseQuery = "(SELECT T1.Id, " +
                                            "T1.SHA1, " +
                                            "T1.ExtensionOriginal, " +
                                            "T1.MimeType, " +
                                            "T1.DateEnteredUtc as CreationTime, " +
                                            "ROW_NUMBER() OVER(ORDER BY T1.DateEnteredUtc ASC) ROW_NUM " +
                                        "FROM Evidence as T1 JOIN CaseEvidence T2 ON T1.Id = T2.EvidenceId " +
                                            "JOIN [Case] T3 ON T2.CaseId = T3.Id " +
                                        "WHERE T1.MimeType like 'image/%'{0} " +
                                        "group by T1.Id, T1.SHA1, T1.ExtensionOriginal, T1.MimeType, T1.DateEnteredUtc)";

        public ImageReader(string connString, string caseName, string basePath)
        {
            this.log = log4net.LogManager.GetLogger("SmartCaps.FR.Enroller");
            log4net.Config.XmlConfigurator.Configure();

            this.connString = connString;
            this.caseName = caseName;
            this.basePath = basePath;
        }

        public virtual string PluginName
        {
            get
            {
                return "IvasEnroller";
            }
        }

        public virtual string RefType
        {
            get
            {
                return "IVAS";
            }
        }

        public static string Help = "Provide the following parameters for the constructor: string connString, string caseName. If case name is empty, it will be ignored";

        public virtual int Count(DateTime fromDate, DateTime toDate)
        {
            int result = 0;

            string imageFileNameQuery = ";WITH theQuery AS " + 
                                        this.theBaseQuery + 
                                        "SELECT count(*) FROM theQuery";

            IList<SqlParameter> optionals = new List<SqlParameter>();
            string filter = string.Empty;
            if (fromDate != default(DateTime))
            {
                filter = " AND T1.DateEnteredUtc >= @FromDate";
                optionals.Add(new SqlParameter("@FromDate", SqlDbType.DateTime) { Value = fromDate });
            }

            if (toDate != default(DateTime))
            {
                filter += " AND T1.DateEnteredUtc <= @ToDate";
                optionals.Add(new SqlParameter("@ToDate", SqlDbType.DateTime) { Value = toDate });
            }

            if (!string.IsNullOrEmpty(this.caseName))
            {
                filter += " AND T3.Identifier = @CaseName";
                optionals.Add(new SqlParameter("@CaseName", SqlDbType.NVarChar) { Value = this.caseName });
            }

            using (SqlConnection conn = new SqlConnection(this.connString))
            {
                string theQuery = string.Format(imageFileNameQuery, filter);
                this.log.DebugFormat("The query to run: {0}", theQuery);
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(theQuery, conn))
                {
                    theCommand.CommandTimeout = 300;
                    theCommand.Parameters.AddRange(optionals.ToArray());
                    result = (int)theCommand.ExecuteScalar();
                }
            }

            return result;

        }

        public virtual IEnumerable<FileResult> GetFileNames(DateTime fromDate, DateTime toDate, int skip, int take)
        {
            this.log.Info("Getting files from IVAS...");

            IList<FileResult> result = new List<FileResult>();

            string imageFileNameQuery = ";WITH theQuery AS " +
                                        this.theBaseQuery +
                                        "SELECT * FROM theQuery WHERE ROW_NUM BETWEEN @Skip AND (@Skip + @Take)";

            IList<SqlParameter> optionals = new List<SqlParameter>();
            string filter = string.Empty;
            if (fromDate != default(DateTime))
            {
                filter = " AND T1.DateEnteredUtc >= @FromDate";
                optionals.Add(new SqlParameter("@FromDate", SqlDbType.DateTime) { Value = fromDate });
            }

            if (toDate != default(DateTime))
            {
                filter += " AND T1.DateEnteredUtc <= @ToDate";
                optionals.Add(new SqlParameter("@ToDate", SqlDbType.DateTime) { Value = toDate });
            }

            if (!string.IsNullOrEmpty(this.caseName))
            {
                filter += " AND T3.Identifier = @CaseName";
                optionals.Add(new SqlParameter("@CaseName", SqlDbType.NVarChar) { Value = this.caseName });
            }

            using (SqlConnection conn = new SqlConnection(this.connString))
            {
                conn.Open();
                string theQuery = string.Format(imageFileNameQuery, filter);
                this.log.DebugFormat("The query to run: {0}", theQuery);
                using (SqlCommand theCommand = new SqlCommand(theQuery, conn))
                {
                    theCommand.CommandTimeout = 300;
                    theCommand.Parameters.Add("@Skip", SqlDbType.Int).Value = skip;
                    theCommand.Parameters.Add("@Take", SqlDbType.Int).Value = take;
                    theCommand.Parameters.AddRange(optionals.ToArray());
                    using (SqlDataReader reader = theCommand.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string id = reader.GetSafeInt("Id").ToString();
                            try
                            {
                                string fileExtension = reader.GetSafeString("ExtensionOriginal");
                                string shaHex = BitConverter.ToString(reader.GetSafeByteArray("SHA1")).Replace("-",string.Empty);
                                string theFilePath = this.GetFilePath(this.basePath, shaHex, fileExtension);
                                result.Add(new FileResult(id, theFilePath));
                            }
                            catch (Exception ex)
                            {
                                this.log.Warn(string.Format("Unable to get file from evidence file id '{0}'", id),ex);
                            }
                        }
                    }
                }
            }


            return result;
        }

        private string GetFilePath(string basePath, string shaHex, string fileExtension)
        {
            string result = null;

            if (!string.IsNullOrEmpty(shaHex))
            {
                string folder1 = shaHex.Substring(0,2);
                string folder2 = shaHex.Substring(2, 2);
                string folder3 = shaHex.Substring(4, 2);
                string folder4 = shaHex.Substring(6, 2);

                result = Path.Combine(basePath, folder1, folder2, folder3, folder4, shaHex + fileExtension);
            }

            return result;
        }

    }

    internal static class DataReaderExtensions
    {
        public static string GetSafeString(this IDataReader dr, string fieldName)
        {
            string result = null;
            int index = dr.GetOrdinal(fieldName);

            if (!dr.IsDBNull(index))
            {
                result = dr.GetString(index);
            }

            return result;
        }

        public static bool GetSafeBool(this IDataReader dr, string fieldName)
        {
            bool result = false;

            int index = dr.GetOrdinal(fieldName);

            if (!dr.IsDBNull(index))
            {
                result = dr.GetBoolean(index);
            }

            return result;
        }

        public static DateTime GetSafeDateTime(this IDataReader dr, string fieldName)
        {
            DateTime result = new DateTime(1970, 1, 1);
            int index = dr.GetOrdinal(fieldName);

            if (!dr.IsDBNull(index))
            {
                result = dr.GetDateTime(index);
            }

            return result;
        }

        public static int GetSafeInt(this IDataReader dr, string fieldName)
        {
            int result = 0;
            int index = dr.GetOrdinal(fieldName);

            if (!dr.IsDBNull(index))
            {
                result = dr.GetInt32(index);
            }

            return result;
        }

        public static double GetSafeDouble(this IDataReader dr, string fieldName)
        {
            double result = 0d;
            int index = dr.GetOrdinal(fieldName);

            if (!dr.IsDBNull(index))
            {
                result = dr.GetDouble(index);
            }

            return result;
        }

        public static byte[] GetSafeByteArray(this IDataReader dr, string fieldName)
        {
            byte[] result = null;
            int index = dr.GetOrdinal(fieldName);

            if (!dr.IsDBNull(index))
            {
                result = (byte[])dr[fieldName];
            }

            return result;
        }

        public static bool ColumnExists(this IDataReader dr, string fieldName)
        {
            for (int i = 0; i < dr.FieldCount; i++)
            {
                if (dr.GetName(i).Equals(fieldName, StringComparison.InvariantCultureIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }
    }
}
