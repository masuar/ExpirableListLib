﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SmartCaps.FR.Common.Model.Commands;
using SmartCaps.FR.Updater.Services;
using SmartCaps.FR.Common.Repos.Memory;
using System.Collections.Generic;
using log4net;
using SmartCaps.FR.Common.Model;
using SmartCaps.FR.NetMessaging.Services;
using SmartCaps.FR.NetMessaging.Services.Memory;
using SmartCaps.FR.Updater.Tests.Fakes;

namespace SmartCaps.FR.Updater.Tests
{
    [TestClass]
    public class UpdaterServiceTests
    {
        private class TestSvcStuff
        {
            public IDictionary<string, ICommand> CommandsStore { get; set; }
            public IDictionary<string, Face> FacesStore { get; set; }
            public IList<MessageInMemory> MessagesStore { get; set; }
            public UpdaterService ServiceToTest { get; set; }
        }

        [TestMethod]
        public void EnrollImage_newImage_Success()
        {
            // Arrange
            EnrollImageCommand cmd = new EnrollImageCommand("theToken");
            cmd.Faces.Add(new FaceInCommand() { Id = "sampleFaceId01", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 } });
            cmd.Faces.Add(new FaceInCommand() { Id = "sampleFaceId02", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 } });

            var svc = this.InitializeService();

            // Exec
            svc.ServiceToTest.EnrollFaces(cmd);

            // Assert
            Assert.AreEqual(2, svc.FacesStore.Count);
            Assert.IsTrue(svc.FacesStore.ContainsKey("sampleFaceId01"));
            Assert.IsTrue(svc.FacesStore.ContainsKey("sampleFaceId02"));
            Assert.AreEqual(1, svc.CommandsStore.Count);
            Assert.IsTrue(svc.CommandsStore.ContainsKey("theToken"));
        }

        [TestMethod]
        public void EnrollImage_existingImage_setsAlreadyExistingValue()
        {
            // Arrange
            EnrollImageCommand cmd1 = new EnrollImageCommand("theToken01");
            cmd1.Faces.Add(new FaceInCommand() { Id = "sampleFaceId01", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 } });

            EnrollImageCommand cmd2 = new EnrollImageCommand("theToken02");
            cmd2.Faces.Add(new FaceInCommand() { Id = "sampleFaceId01", BoundingBox = new BoundingBox() { TopLeft = new Coord(30, 30), DownRight = new Coord(40, 40) }, Features = new double[] { 1.25, 1.50, 1.75 } });

            var svc = this.InitializeService();

            // Exec
            svc.ServiceToTest.EnrollFaces(cmd1);
            svc.ServiceToTest.EnrollFaces(cmd2);

            // Assert
            Assert.AreEqual(1, svc.FacesStore.Count);
            Assert.IsTrue(svc.FacesStore.ContainsKey("sampleFaceId01"));
            Assert.IsFalse(((IFacesCommand)svc.CommandsStore[cmd1.Token]).Faces[0].AlreadyExisting);
            Assert.IsTrue(((IFacesCommand)svc.CommandsStore[cmd2.Token]).Faces[0].AlreadyExisting);
        }

        [TestMethod]
        public void EvalImage_Success()
        {
            // Arrange
            EvalImageCommand cmd = new EvalImageCommand("theToken");
            cmd.Faces.Add(new FaceInCommand() { Id = "sampleFaceId01", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 } });
            cmd.Faces.Add(new FaceInCommand() { Id = "sampleFaceId02", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 } });

            var svc = this.InitializeService();

            // Exec
            svc.ServiceToTest.ProcessEvalResults((IEvalCommand)cmd);
            svc.ServiceToTest.ProcessEvalRequest((IFacesCommand)cmd);

            // Assert
            Assert.AreEqual(0, svc.FacesStore.Count);
            Assert.AreEqual(1, svc.CommandsStore.Count);
            Assert.IsTrue(svc.CommandsStore.ContainsKey("theToken"));
        }

        [TestMethod]
        public void EvalImage_UpdatesMetadata_Success()
        {
            // Arrange
            EvalImageCommand cmd = new EvalImageCommand("theToken");
            cmd.Faces.Add(new FaceInCommand() { Id = "sampleFaceId01", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 } });
            cmd.Faces.Add(new FaceInCommand() { Id = "sampleFaceId02", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 } });

            var svc = this.InitializeService();

            // Exec
            svc.ServiceToTest.ProcessEvalResults((IEvalCommand)cmd);
            svc.ServiceToTest.ProcessEvalRequest((IFacesCommand)cmd);

            // Assert
            Assert.AreEqual(0, svc.FacesStore.Count);
            Assert.AreEqual(1, svc.CommandsStore.Count);
            Assert.IsTrue(svc.CommandsStore.ContainsKey("theToken"));
        }

        [TestMethod]
        public void RepublishEnrollFaces_Success()
        {
            // Arrange
            var svc = this.InitializeService();
            svc.FacesStore.Add("sampleFaceId01", new Face() { Id = "sampleFaceId01", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 }, Evaluated = true });
            svc.FacesStore.Add("sampleFaceId02", new Face() { Id = "sampleFaceId02", BoundingBox = new BoundingBox() { TopLeft = new Coord(30, 30), DownRight = new Coord(40, 40) }, Features = new double[] { 1.25, 1.50, 1.75 }, Evaluated = true });

            // Exec
            svc.ServiceToTest.RepublishEnrollFaces(batchSize: 1);

            // Assert
            Assert.AreEqual(2, svc.MessagesStore.Count);
            Assert.AreEqual(0, svc.CommandsStore.Count);
            var msg = svc.MessagesStore.First();
            Assert.AreEqual("SmartCaps.FR.EnrollImage.FacesExtracted", msg.RoutingKey);
            Assert.IsNotNull(msg.Properties);
            Assert.IsTrue(msg.Properties.ContainsKey("JMS_AMQP_ContentType"));
            Assert.AreEqual("SmartCaps.FR.EnrollImage.FacesExtracted", msg.Properties["JMS_AMQP_ContentType"]);
        }

        [TestMethod]
        public void ProcessError_atFirst_Success()
        {
            // Arrange
            var svc = this.InitializeService();
            var cmd = new ErrorCommand() { Token ="theToken",  ErrorMessage = "This is a sample error." };

            // Exec
            svc.ServiceToTest.ProcessError(cmd);

            // Assert
            Assert.AreEqual(1, svc.CommandsStore.Count);
            Assert.IsTrue(svc.CommandsStore.ContainsKey("theToken"));
        }

        [TestMethod]
        public void ProcessError_atAlreadyStartedCommand_Success()
        {
            // Arrange
            var svc = this.InitializeService();
            EnrollImageCommand cmd = new EnrollImageCommand("theToken");
            cmd.Faces.Add(new FaceInCommand() { Id = "sampleFaceId01", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 } });
            svc.ServiceToTest.EnrollFaces(cmd);

            var cmdError = new ErrorCommand() { Token = "theToken", ErrorMessage = "This is a sample error." };

            // Exec
            svc.ServiceToTest.ProcessError(cmdError);

            // Assert
            Assert.AreEqual(1, svc.CommandsStore.Count);
            Assert.IsTrue(svc.CommandsStore.ContainsKey("theToken"));
        }

        [TestMethod]
        public void RemoveFaces_withExistingFaces_Success()
        {
            // Arrange
            var svc = this.InitializeService();
            svc.FacesStore.Add("sampleFaceId01", new Face() { Id = "sampleFaceId01", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 } });
            svc.FacesStore.Add("sampleFaceId02", new Face() { Id = "sampleFaceId02", BoundingBox = new BoundingBox() { TopLeft = new Coord(30, 30), DownRight = new Coord(40, 40) }, Features = new double[] { 1.25, 1.50, 1.75 } });

            RemoveFacesCommand cmd = new RemoveFacesCommand();
            cmd.Token = "theToken";
            cmd.Faces.Add(new FaceInCommand() { Id = "sampleFaceId01" });
            cmd.Faces.Add(new FaceInCommand() { Id = "sampleFaceId02" });

            // Exec
            svc.ServiceToTest.RemoveFaces(cmd);

            // Assert
            Assert.AreEqual(1, svc.CommandsStore.Count);
            Assert.IsTrue(svc.CommandsStore.ContainsKey("theToken"));
            Assert.AreEqual(0, svc.FacesStore.Count);
        }

        [TestMethod]
        public void RemoveFaces_withNonExistingFaces_Success()
        {
            // Arrange
            var svc = this.InitializeService();

            RemoveFacesCommand cmd = new RemoveFacesCommand();
            cmd.Token = "theToken";
            cmd.Faces.Add(new FaceInCommand() { Id = "sampleFaceId01" });
            cmd.Faces.Add(new FaceInCommand() { Id = "sampleFaceId02" });


            // Exec
            svc.ServiceToTest.RemoveFaces(cmd);

            // Assert
            Assert.AreEqual(1, svc.CommandsStore.Count);
            Assert.IsTrue(svc.CommandsStore.ContainsKey("theToken"));
            Assert.AreEqual(0, svc.FacesStore.Count);
        }

        private TestSvcStuff InitializeService()
        {
            IDictionary<string, ICommand> cmdStore = new Dictionary<string, ICommand>();
            IDictionary<string, Face> faceStore = new Dictionary<string, Face>();
            IList<MessageInMemory> msgStore = new List<MessageInMemory>();
            ILog nullLog = new NullLog();
            MemoryCommandRepository cmdRepo = new MemoryCommandRepository(cmdStore, nullLog);
            MemoryFaceRepository faceRepo = new MemoryFaceRepository(faceStore, nullLog);
            IPublisherService publisherToKnn = new MemoryPublisherService(msgStore);
            IPublisherService publisher = new MemoryPublisherService(msgStore);
            MatchConfiguration matchConf = new MatchConfiguration("POSSIBLE MATCH", 0.5d);
            UpdaterService svc = new UpdaterService(cmdRepo, faceRepo, publisherToKnn, publisher, matchConf, nullLog);

            return new TestSvcStuff() { CommandsStore = cmdStore, FacesStore = faceStore, MessagesStore = msgStore, ServiceToTest = svc };
        }
    }
}
