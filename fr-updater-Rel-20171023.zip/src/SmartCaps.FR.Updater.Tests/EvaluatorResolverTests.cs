﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SmartCaps.FR.Updater.Tests
{
    [TestClass]
    public class EvaluatorResolverTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
