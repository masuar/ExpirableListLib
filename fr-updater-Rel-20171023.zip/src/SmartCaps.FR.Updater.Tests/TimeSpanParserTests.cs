﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SmartCaps.FR.Updater.Services;
using System.Linq;
using log4net;
using SmartCaps.FR.Updater.Tests.Fakes;

namespace SmartCaps.FR.Updater.Tests
{
    [TestClass]
    public class TimeSpanParserTests
    {
        [TestMethod]
        public void ParseFromString_CorrectTwoStrings_ReturnsTwoTimeSpans()
        {
            // Arrange
            string toTest = "23:30;15:25:10";
            TimeSpanParser parser = new TimeSpanParser(new NullLog());

            // Execute
            var result = parser.ParseFromString(toTest);

            // Assert
            Assert.AreEqual(2, result.Count());
            Assert.AreEqual(new TimeSpan(23, 30, 0), result.First());
            Assert.AreEqual(new TimeSpan(15, 25, 10), result.Last());
        }

        [TestMethod]
        public void ParseFromString_CorrectStringsSeveralSemicolons_ReturnsTwoTimeSpans()
        {
            // Arrange
            string toTest = ";;23:30;15:25:10;";
            TimeSpanParser parser = new TimeSpanParser(new NullLog());

            // Execute
            var result = parser.ParseFromString(toTest);

            // Assert
            Assert.AreEqual(2, result.Count());
            Assert.AreEqual(new TimeSpan(23, 30, 0), result.First());
            Assert.AreEqual(new TimeSpan(15, 25, 10), result.Last());
        }


        [TestMethod]
        public void ParseFromString_WrongFirstOfTwoStrings_ReturnsSecondOne()
        {
            // Arrange
            string toTest = "15x25:10;23:30";
            TimeSpanParser parser = new TimeSpanParser(new NullLog());

            // Execute
            var result = parser.ParseFromString(toTest);

            // Assert
            Assert.AreEqual(1, result.Count());
            Assert.AreEqual(new TimeSpan(23, 30, 0), result.First());
        }

        [TestMethod]
        public void ParseFromString_WrongSecondOfTwoStrings_ReturnsFirstOne()
        {
            // Arrange
            string toTest = "23:30;15x25:10";
            TimeSpanParser parser = new TimeSpanParser(new NullLog());

            // Execute
            var result = parser.ParseFromString(toTest);

            // Assert
            Assert.AreEqual(1, result.Count());
            Assert.AreEqual(new TimeSpan(23, 30, 0), result.First());
        }

        [TestMethod]
        public void ParseFromString_WrongString_ReturnsEmptyList()
        {
            // Arrange
            string toTest = "23:30j15:25:10";
            TimeSpanParser parser = new TimeSpanParser(new NullLog());

            // Execute
            var result = parser.ParseFromString(toTest);

            // Assert
            Assert.AreEqual(0, result.Count());
        }

        [TestMethod]
        public void ParseFromString_StringAsBigInt_ReturnsEmptyList()
        {
            // Arrange
            string toTest = "10500";
            TimeSpanParser parser = new TimeSpanParser(new NullLog());

            // Execute
            var result = parser.ParseFromString(toTest);

            // Assert
            Assert.AreEqual(0, result.Count());
        }

        [TestMethod]
        public void ParseFromString_StringAsNotThatBigInt_ReturnsEmptyList()
        {
            // Arrange
            string toTest = "7";
            TimeSpanParser parser = new TimeSpanParser(new NullLog());

            // Execute
            var result = parser.ParseFromString(toTest);

            // Assert
            Assert.AreEqual(0, result.Count());
        }

        [TestMethod]
        public void ParseFromString_StringsAsInt_ReturnsEmptyList()
        {
            // Arrange
            string toTest = "7;15:45";
            TimeSpanParser parser = new TimeSpanParser(new NullLog());

            // Execute
            var result = parser.ParseFromString(toTest);

            // Assert
            Assert.AreEqual(1, result.Count());
            Assert.AreEqual(new TimeSpan(15, 45, 0), result.First());
        }

        [TestMethod]
        public void ParseFromString_WeirdTimeStamps_ReturnsEmptyList()
        {
            // Arrange
            string toTest = "17:68;15:45";
            TimeSpanParser parser = new TimeSpanParser(new NullLog());

            // Execute
            var result = parser.ParseFromString(toTest);

            // Assert
            Assert.AreEqual(1, result.Count());
            Assert.AreEqual(new TimeSpan(15, 45, 0), result.First());
        }

        [TestMethod]
        public void ParseFromString_WeirdMix_ReturnsEmptyList()
        {
            // Arrange
            string toTest = "17:68;23";
            TimeSpanParser parser = new TimeSpanParser(new NullLog());

            // Execute
            var result = parser.ParseFromString(toTest);

            // Assert
            Assert.AreEqual(0, result.Count());
        }

        [TestMethod]
        public void ParseFromString_SeveralInts_ReturnsEmptyList()
        {
            // Arrange
            string toTest = "4500;23";
            TimeSpanParser parser = new TimeSpanParser(new NullLog());

            // Execute
            var result = parser.ParseFromString(toTest);

            // Assert
            Assert.AreEqual(0, result.Count());
        }

        [TestMethod]
        public void ParseFromString_SeveralSemicolons_ReturnsEmptyList()
        {
            // Arrange
            string toTest = ";;;";
            TimeSpanParser parser = new TimeSpanParser(new NullLog());

            // Execute
            var result = parser.ParseFromString(toTest);

            // Assert
            Assert.AreEqual(0, result.Count());
        }

    }
}
