﻿using log4net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using SmartCaps.FR.Common.Model;
using SmartCaps.FR.Common.Model.Commands;
using SmartCaps.FR.Common.Repos.Memory;
using SmartCaps.FR.NetMessaging.Services;
using SmartCaps.FR.NetMessaging.Services.Memory;
using SmartCaps.FR.Updater.Services;
using SmartCaps.FR.Updater.Tests.Fakes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Updater.Tests
{
    [TestClass]
    public class MessageProcessorTests
    {
        private class TestStuff
        {
            public IDictionary<string, ICommand> CommandsStore { get; set; }
            public IDictionary<string, Face> FacesStore { get; set; }
            public IList<MessageInMemory> MessagesStore { get; set; }
            public IConsumerService Consumer { get; set; }
            public UpdaterMessagesProcessor ProcessorToTest { get; set; }
        }

        [TestMethod]
        public void ProcessEnrollImageMessage_success()
        {
            // Arrange
            EnrollImageCommand cmd = new EnrollImageCommand("theToken");
            cmd.Faces.Add(new FaceInCommand() { Id = "sampleFaceId01", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 } });
            cmd.Faces.Add(new FaceInCommand() { Id = "sampleFaceId02", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 } });
            var svc = this.InitializeService(this.CreateMessage("SmartCaps.FR.EnrollImage.FacesExtracted", JsonConvert.SerializeObject(cmd)));

            // Exec
            svc.ProcessorToTest.StartListening();
            svc.ProcessorToTest.StopListening();

            // Assert
            Assert.AreEqual(2, svc.FacesStore.Count); // Two new faces imported
            Assert.IsTrue(svc.FacesStore.ContainsKey("sampleFaceId01"));
            Assert.IsTrue(svc.FacesStore.ContainsKey("sampleFaceId02"));
            Assert.AreEqual(1, svc.CommandsStore.Count); // One more command saved
            Assert.IsTrue(svc.CommandsStore.ContainsKey("theToken"));
        }

        [TestMethod]
        public void ProcessEnrollAndEvalImageFacesExtractedMessage_success()
        {
            // Arrange
            EnrollAndEvalImageCommand cmd = new EnrollAndEvalImageCommand("theToken");
            cmd.Faces.Add(new FaceInCommand() { Id = "sampleFaceId01", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 } });
            cmd.Faces.Add(new FaceInCommand() { Id = "sampleFaceId02", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 } });
            var svc = this.InitializeService(
                this.CreateMessage("SmartCaps.FR.EnrollAndEvalImage.FacesExtracted", JsonConvert.SerializeObject(cmd)));

            // Exec
            svc.ProcessorToTest.StartListening();
            svc.ProcessorToTest.StopListening();

            // Assert
            Assert.AreEqual(2, svc.FacesStore.Count); // Two new faces imported
            Assert.IsTrue(svc.FacesStore.ContainsKey("sampleFaceId01"));
            Assert.IsTrue(svc.FacesStore.ContainsKey("sampleFaceId02"));
            Assert.AreEqual(1, svc.CommandsStore.Count); // One more command saved
            Assert.IsTrue(svc.CommandsStore.ContainsKey("theToken"));
            Assert.IsInstanceOfType(svc.CommandsStore["theToken"], typeof(EnrollAndEvalImageCommand));
            Assert.AreEqual(2, ((EnrollAndEvalImageCommand)svc.CommandsStore["theToken"]).Faces.Count);
            Assert.AreEqual(0, ((EnrollAndEvalImageCommand)svc.CommandsStore["theToken"]).Neighbors.Count);
        }

        [TestMethod]
        public void ProcessEnrollAndEvalImageEvaluationDoneMessage_success()
        {
            // Arrange
            EnrollAndEvalImageCommand cmd = new EnrollAndEvalImageCommand("theToken");
            cmd.Neighbors.Add(new FaceNeighbor() { SourceFaceId = "sampleFaceId01", TargetFaceId = "aVeryCommonFaceId", Grade = 0.8 });
            cmd.Neighbors.Add(new FaceNeighbor() { SourceFaceId = "sampleFaceId01", TargetFaceId = "aCommonFaceId", Grade = 1.0 });
            cmd.Neighbors.Add(new FaceNeighbor() { SourceFaceId = "sampleFaceId02", TargetFaceId = "aVeryCommonFaceId", Grade = 0.7 });
            cmd.Neighbors.Add(new FaceNeighbor() { SourceFaceId = "sampleFaceId02", TargetFaceId = "aCommonFaceId", Grade = 0.9 });

            var svc = this.InitializeService(
                this.CreateMessage("SmartCaps.FR.EnrollAndEvalImage.FacesExtracted.KnnDone", JsonConvert.SerializeObject(cmd)));

            // Exec
            svc.ProcessorToTest.StartListening();
            svc.ProcessorToTest.StopListening();

            // Assert
            Assert.AreEqual(0, svc.FacesStore.Count); // Two new faces imported
            Assert.AreEqual(1, svc.CommandsStore.Count); // Only one command saved
            Assert.IsTrue(svc.CommandsStore.ContainsKey("theToken"));
            Assert.IsInstanceOfType(svc.CommandsStore["theToken"], typeof(EnrollAndEvalImageCommand));
            Assert.AreEqual(4, ((EnrollAndEvalImageCommand)svc.CommandsStore["theToken"]).Neighbors.Count);
        }

        [TestMethod]
        public void ProcessEvalImageFacesExtractedMessage_success()
        {
            // Arrange
            EvalImageCommand cmd = new EvalImageCommand("theToken");
            cmd.Faces.Add(new FaceInCommand() { Id = "sampleFaceId01", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 } });
            cmd.Faces.Add(new FaceInCommand() { Id = "sampleFaceId02", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 } });
            var svc = this.InitializeService(
                this.CreateMessage("SmartCaps.FR.EvalImage.FacesExtracted", JsonConvert.SerializeObject(cmd)));

            // Exec
            svc.ProcessorToTest.StartListening();
            svc.ProcessorToTest.StopListening();

            // Assert
            Assert.AreEqual(0, svc.FacesStore.Count); // Two new faces imported
            Assert.AreEqual(1, svc.CommandsStore.Count); // One more command saved
            Assert.IsTrue(svc.CommandsStore.ContainsKey("theToken"));
            Assert.IsInstanceOfType(svc.CommandsStore["theToken"], typeof(EvalImageCommand));
            Assert.AreEqual(2, ((EvalImageCommand)svc.CommandsStore["theToken"]).Faces.Count);
            Assert.AreEqual(0, ((EvalImageCommand)svc.CommandsStore["theToken"]).Neighbors.Count);
        }

        [TestMethod]
        public void ProcessEvalImageEvaluationDoneMessage_success()
        {
            // Arrange
            EvalImageCommand cmd = new EvalImageCommand("theToken");
            cmd.Neighbors.Add(new FaceNeighbor() { SourceFaceId = "1", TargetFaceId = "2", Grade = 0.4 });
            cmd.Neighbors.Add(new FaceNeighbor() { SourceFaceId = "1", TargetFaceId = "3", Grade = 0.9 });
            cmd.Neighbors.Add(new FaceNeighbor() { SourceFaceId = "1", TargetFaceId = "4", Grade = 1.1 });
            cmd.Neighbors.Add(new FaceNeighbor() { SourceFaceId = "1", TargetFaceId = "5", Grade = 1.3 });

            var svc = this.InitializeService(
                this.CreateMessage("SmartCaps.FR.EvalImage.FacesExtracted.KnnDone", JsonConvert.SerializeObject(cmd)));

            svc.FacesStore.Add("2", new Face() { Id = "2", Evaluated = true });
            svc.FacesStore.Add("3", new Face() { Id = "3", Evaluated = true });

            // Exec
            svc.ProcessorToTest.StartListening();
            svc.ProcessorToTest.StopListening();

            // Assert
            Assert.AreEqual(2, svc.FacesStore.Count);
            Assert.AreEqual(1, svc.CommandsStore.Count); // Only one command saved
            Assert.IsTrue(svc.CommandsStore.ContainsKey("theToken"));
            Assert.IsInstanceOfType(svc.CommandsStore["theToken"], typeof(EvalImageCommand));
            Assert.AreEqual(4, ((EvalImageCommand)svc.CommandsStore["theToken"]).Neighbors.Count);
            Assert.IsTrue(svc.FacesStore["2"].Tags.Any(t => t == "POSSIBLE MATCH"));
            Assert.IsFalse(svc.FacesStore["3"].Tags.Any(t => t == "POSSIBLE MATCH"));

        }

        [TestMethod]
        public void ProcessRemoveFacesMessage_success()
        {
            // Arrange
            RemoveFacesCommand cmd = new RemoveFacesCommand();
            cmd.Token = "theToken";
            cmd.Faces.Add( new FaceInCommand() { Id = "sampleFaceId01" } );
            var svc = this.InitializeService(this.CreateMessage("SmartCaps.FR.RemoveFaces", JsonConvert.SerializeObject(cmd)));
            svc.FacesStore.Add("sampleFaceId01", new Face() { Id = "sampleFaceId01", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 } });
            svc.FacesStore.Add("sampleFaceId02", new Face() { Id = "sampleFaceId02", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.25, 0.50, 0.75 } });

            // Exec
            svc.ProcessorToTest.StartListening();
            svc.ProcessorToTest.StopListening();

            // Assert
            Assert.AreEqual(1, svc.FacesStore.Count); // Two new faces imported
            Assert.IsFalse(svc.FacesStore.ContainsKey("sampleFaceId01"));
            Assert.IsTrue(svc.FacesStore.ContainsKey("sampleFaceId02"));
            Assert.AreEqual(1, svc.CommandsStore.Count); // One more command saved
            Assert.IsTrue(svc.CommandsStore.ContainsKey("theToken"));
            Assert.IsInstanceOfType(svc.CommandsStore["theToken"], typeof(RemoveFacesCommand));
            Assert.AreEqual(1, ((RemoveFacesCommand)svc.CommandsStore["theToken"]).Faces.Count());
        }

        [TestMethod]
        public void ProcessErrorMessage_success()
        {
            // Arrange
            ErrorCommand cmd = new ErrorCommand();
            cmd.Token = "theToken";
            var svc = this.InitializeService(this.CreateMessage("SmartCaps.FR.EnrollImage.Error", JsonConvert.SerializeObject(cmd)));

            // Exec
            svc.ProcessorToTest.StartListening();
            svc.ProcessorToTest.StopListening();

            // Assert
            Assert.AreEqual(1, svc.CommandsStore.Count); // One more command saved
            Assert.IsTrue(svc.CommandsStore.ContainsKey("theToken"));
        }


        private TestStuff InitializeService(params MessageInMemory[] msgs)
        {
            IDictionary<string, ICommand> cmdStore = new Dictionary<string, ICommand>();
            IDictionary<string, Face> faceStore = new Dictionary<string, Face>();
            IList<MessageInMemory> msgStore = new List<MessageInMemory>();
            ILog nullLog = new NullLog();
            MemoryCommandRepository cmdRepo = new MemoryCommandRepository(cmdStore, nullLog);
            MemoryFaceRepository faceRepo = new MemoryFaceRepository(faceStore, nullLog);
            IPublisherService publishertoKnn = new MemoryPublisherService(msgStore);
            IPublisherService publisher = new MemoryPublisherService(msgStore);
            MatchConfiguration matchConf = new MatchConfiguration("POSSIBLE MATCH", 0.5d);
            UpdaterService svc = new UpdaterService(cmdRepo, faceRepo, publishertoKnn, publisher, matchConf, nullLog);
            IConsumerService consumer = new MemoryConsumerService(msgs);

            UpdaterMessagesProcessor processor = new UpdaterMessagesProcessor(consumer, svc, 10, nullLog);

            return new TestStuff() { CommandsStore = cmdStore, FacesStore = faceStore, MessagesStore = msgStore, Consumer = consumer, ProcessorToTest = processor };

        }

        private MessageInMemory CreateMessage(string routingKey, string payload)
        {
            var msgProps = new Dictionary<string, string>();
            msgProps.Add("JMS_AMQP_ContentType", routingKey);
            return new MessageInMemory() { RoutingKey = routingKey, Payload = payload, Properties = msgProps };
        }
    }
}
