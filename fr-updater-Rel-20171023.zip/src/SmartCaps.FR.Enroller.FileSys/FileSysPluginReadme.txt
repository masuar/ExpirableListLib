﻿Typical call:

ep -pluginDll="SmartCaps.FR.Updater.FileSys.dll" -parameters="D:\dev\FR\lfw" -skip=0 -take=10 -confirm -verbose