﻿using log4net;
using SmartCaps.FR.Updater.ImageFileReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Enroller.FileSys
{
    public class ImageReader : IImageFileReader
    {
        private string folder;
        private IEnumerable<string> extensions;
        private ILog log;

        public ImageReader(string folder, params string[] mimeTypes)
        {
            this.log = log4net.LogManager.GetLogger("SmartCaps.FR.Enroller");
            log4net.Config.XmlConfigurator.Configure();

            this.folder = folder;
            this.extensions = ImageMimeTypesHelper.GetExtensionsForMimeTypes(mimeTypes);
        }

        public static string Help = "Provide the following parameters for the constructor: string folder, params string[] mimeTypes";

        public string PluginName
        {
            get
            {
                return "FileSysEnroller";
            }
        }

        public string RefType
        {
            get
            {
                return "FILESYS";
            }
        }

        public IEnumerable<FileResult> GetFileNames(DateTime fromDate, DateTime toDate, int skip, int take)
        {
            IList<FileResult> data = new List<FileResult>();
            IEnumerable<FileInfo> files = new DirectoryInfo(folder).GetFiles("*.*", SearchOption.AllDirectories);
            files = files.Where(f => this.extensions.Contains(f.Extension.ToLower()));
            if (fromDate != default(DateTime))
            {
                files = files.Where(f => f.CreationTime >= fromDate);
            }

            if (toDate != default(DateTime))
            {
                files = files.Where(f => f.CreationTime <= toDate);
            }

            files = files.OrderBy(f => f.CreationTime).Skip(skip).Take(take);

            int i = 0;
            foreach (var f in files)
            {
                data.Add(new FileResult(i++.ToString(), f.FullName));
            }

            return data;
        }

        public int Count(DateTime fromDate, DateTime toDate)
        {
            IEnumerable<FileInfo> files = new DirectoryInfo(folder).GetFiles("*.*", SearchOption.AllDirectories);
            files = files.Where(f => this.extensions.Contains(f.Extension.ToLower()));
            if (fromDate != default(DateTime))
            {
                files = files.Where(f => f.CreationTime >= fromDate);
            }

            if (toDate != default(DateTime))
            {
                files = files.Where(f => f.CreationTime <= toDate);
            }

            return files.Count();
        }

    }
}
