﻿using log4net;
using SmartCaps.FR.Common.Repos;
using SmartCaps.FR.NetMessaging.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SmartCaps.FR.Updater.Services
{
    public class ScheduledSingleThreadedEvaluator : IDelayedProcessor
    {
        private IEnumerable<TimeSpan> schedules;
        private int maxItems;
        private ILog log;
        private BackgroundWorker bw;
        private int INTERVAL = 1000;
        private FaceEvaluator faceEvaluator;

        private class WorkerArgs
        {
            public int MaxItems { get; set; }
            public IEnumerable<TimeSpan> Schedules { get; set; }
            public ILog Log { get; set; }
            public FaceEvaluator FaceEvaluator { get; set; }
        }

        public ScheduledSingleThreadedEvaluator(IEnumerable<TimeSpan> schedules, int batchSize, int maxItems, IPublisherService publisherToKnn, IFaceRepository faceRepo, ILog log)
        {
            this.log = log;
            this.schedules = schedules;
            this.maxItems = maxItems;
            this.faceEvaluator = new FaceEvaluator(batchSize, publisherToKnn, faceRepo, log);

            this.bw = new BackgroundWorker();
            this.bw.WorkerSupportsCancellation = true;
            this.bw.DoWork += new DoWorkEventHandler(this.DoWork);
        }

        public void Start()
        {
            if (this.schedules.Count() > 0)
            {
                WorkerArgs args = new WorkerArgs();
                args.MaxItems = this.maxItems;
                args.Schedules = this.schedules;
                args.FaceEvaluator = this.faceEvaluator;
                args.Log = log;

                this.bw.RunWorkerAsync(args);
            }
        }

        public void Stop()
        {
            this.bw.CancelAsync();
        }

        private void DoWork(object sender, DoWorkEventArgs e)  
        {
            BackgroundWorker worker = sender as BackgroundWorker;
            WorkerArgs args = (WorkerArgs)e.Argument;
            while (true)
            {
                if (worker.CancellationPending)
                {
                    e.Cancel = true;
                    this.log.Info("Delayed evaluation process stopped.");
                    break;
                }

                TimeSpan now = DateTime.UtcNow.TimeOfDay;

                foreach(var schedule in args.Schedules)
                {
                    double diff = Math.Abs((schedule - now).TotalMilliseconds);
                    if (diff <= 500)
                    {
                        Stopwatch sw = new Stopwatch();

                        sw.Start();
                        args.FaceEvaluator.EvaluatePendingFaces(args.MaxItems);
                        sw.Stop();

                        args.Log.InfoFormat("Scheduled execution finished, took {0} secs.", sw.ElapsedMilliseconds / 1000);
                        break;
                    }

                }

                Thread.Sleep(this.INTERVAL);
            }
        }

    }
}
