﻿using log4net;
using SmartCaps.FR.Common.Repos;
using SmartCaps.FR.NetMessaging.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Updater.Services
{
    public class PendingFacesProcessorResolver
    {
        private int maxItems;
        private ILog log;
        private int batchSize;
        private IFaceRepository faceRepo;
        private IPublisherService publisherToKnn;
        private TimeSpanParser parser;

        public PendingFacesProcessorResolver(int batchSize, int maxItems, IPublisherService publisherToKnn, IFaceRepository faceRepo, ILog log)
        {
            this.batchSize = batchSize;
            this.maxItems = maxItems;
            this.publisherToKnn = publisherToKnn;
            this.faceRepo = faceRepo;
            this.log = log;

            this.parser = new TimeSpanParser(this.log);
        }

        public IDelayedProcessor GetProcessorBasedOnInterval(string interval)
        {
            IDelayedProcessor result = null;

            IEnumerable<TimeSpan> schedules = this.parser.ParseFromString(interval);
            if (schedules.Count() > 0)
            {
                result = new ScheduledSingleThreadedEvaluator(schedules, this.batchSize, this.maxItems, this.publisherToKnn, this.faceRepo, this.log);
            }
            else 
            {
                int intInterval = 0;
                int.TryParse(interval, out intInterval);
                result = new IntervalSingleThreadedEvaluator(intInterval, this.batchSize, this.maxItems, this.publisherToKnn, this.faceRepo, this.log);
            }

            return result;
        }
    }
}
