﻿using log4net;
using Newtonsoft.Json;
using SmartCaps.FR.Common.Model;
using SmartCaps.FR.Common.Model.Commands;
using SmartCaps.FR.Common.Repos;
using SmartCaps.FR.NetMessaging.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Updater.Services
{
    public class FaceEvaluator
    {
        protected ILog log;
        protected int batchSize;
        protected IFaceRepository faceRepo;
        protected IPublisherService publisherToKnn;

        public FaceEvaluator(int batchSize, IPublisherService publisherToKnn, IFaceRepository faceRepo, ILog log)
        {
            this.batchSize = batchSize;
            this.publisherToKnn = publisherToKnn;
            this.faceRepo = faceRepo;
            this.log = log;
        }

        public void EvaluatePendingFaces(int maxFaces)
        {
            try
            {
                this.log.Info("Pending faces evaluator started.");
                int pageSize = this.batchSize;
                int notEvaluatedFaceCount = this.faceRepo.GetNotEvaluatedFacesCount();
                if (maxFaces > 0)
                {
                    notEvaluatedFaceCount = Math.Min(notEvaluatedFaceCount, maxFaces);
                }

                int totalPages = (int)(notEvaluatedFaceCount / pageSize) + 1;
                int totalFaces = 0;
                for (int pageIndex = 0; pageIndex < totalPages; pageIndex++)
                {
                    IEnumerable<Face> faces = this.faceRepo.GetNotEvaluatedFaces(pageIndex, pageSize, true);

                    string newToken = Guid.NewGuid().ToString();
                    EnrollAndEvalImageCommand cmdToPublish = new EnrollAndEvalImageCommand(newToken);
                    foreach (Face face in faces)
                    {
                        cmdToPublish.Faces.Add(new FaceInCommand(face));
                    }

                    if (cmdToPublish.Faces.Count > 0)
                    {
                        Dictionary<string, string> props = new Dictionary<string, string>();
                        props.Add("JMS_AMQP_ContentType", "SmartCaps.FR.EnrollAndEvalImage.FacesExtracted");
                        string json = JsonConvert.SerializeObject(cmdToPublish);
                        this.publisherToKnn.Publish("SmartCaps.FR.EnrollAndEvalImage.FacesExtracted", json, props);
                        this.log.Info("Delayed evaluator message sent!");
                    }

                    totalFaces += cmdToPublish.Faces.Count;
                }
                this.log.InfoFormat("Pending faces evaluator finished. {0} new faces will be available in the KNN engine.", totalFaces);

            }
            catch (Exception ex)
            {
                this.log.Error("Error processing faces pending evaluation.", ex);
            }
        }

    }
}
