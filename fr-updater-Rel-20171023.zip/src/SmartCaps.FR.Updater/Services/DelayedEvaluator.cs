﻿using log4net;
using Newtonsoft.Json;
using SmartCaps.FR.Common.Model;
using SmartCaps.FR.Common.Model.Commands;
using SmartCaps.FR.Common.Repos;
using SmartCaps.FR.NetMessaging.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace SmartCaps.FR.Updater.Services
{
    public class DelayedEvaluator : IDelayedProcessor
    {
        private Timer timer;
        protected ILog log;
        protected IFaceRepository faceRepo;
        protected IPublisherService publisherToKnn;
        protected int batchSize;
        protected int maxItems;

        private FaceEvaluator faceEvaluator;

        public DelayedEvaluator(int interval, int batchSize, int maxItems, IPublisherService publisherToKnn, IFaceRepository faceRepo, ILog log)
        {
            this.faceEvaluator = new FaceEvaluator(batchSize, publisherToKnn, faceRepo, log);

            this.maxItems = maxItems;
            this.log = log;
            this.timer = new Timer();

            if (interval > 0)
            {
                this.timer.Interval = interval;
                this.timer.Elapsed += new ElapsedEventHandler(OnTimedEvent);
                this.timer.Enabled = true;
            }
            else
            {
                this.timer.Interval = TimeSpan.FromDays(1).TotalMilliseconds;
                this.timer.Enabled = false;
            }
        }

        public virtual void Start()
        {
            if (this.timer.Enabled)
            {
                this.log.InfoFormat("Delayed evaluator instance started. Will run each {0} millisecs.", this.timer.Interval);
                this.OnTimedEvent(this, null);
                this.timer.Start();
            }
            else
            {
                this.log.Warn("Delayed evaluator instance not starting because interval is set to zero or less.");
            }
        }

        public virtual void Stop()
        {
            this.timer.Stop();
        }

        private void OnTimedEvent(object sender, ElapsedEventArgs e)
        {
            this.faceEvaluator.EvaluatePendingFaces(this.maxItems);
        }
    }
}
