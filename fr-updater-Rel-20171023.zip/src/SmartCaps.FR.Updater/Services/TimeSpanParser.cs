﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Updater.Services
{
    public class TimeSpanParser
    {
        private ILog log;

        public TimeSpanParser(ILog log)
        {
            this.log = log;
        }

        public IEnumerable<TimeSpan> ParseFromString(string scheduleTimesString)
        {
            IList<TimeSpan> scheduleTimes = new List<TimeSpan>();

            if (!string.IsNullOrEmpty(scheduleTimesString))
            {
                var timeStrings = scheduleTimesString.Split(';');
                foreach (var timeString in timeStrings)
                {
                    try
                    {
                        TimeSpan timeSpan = TimeSpan.Parse(timeString);

                        if (timeSpan > TimeSpan.Zero && timeSpan < TimeSpan.FromDays(1))
                        {
                            scheduleTimes.Add(timeSpan);
                        }
                    }
                    catch (Exception ex)
                    {
                        this.log.Warn("Exception when parsing schedule times.", ex);
                    }

                }
            }

            return scheduleTimes;
        }
    }
}
