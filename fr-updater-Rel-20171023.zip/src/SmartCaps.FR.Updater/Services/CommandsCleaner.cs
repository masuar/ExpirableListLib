﻿using log4net;
using SmartCaps.FR.Common.Repos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace SmartCaps.FR.Updater.Services
{
    public class CommandsCleaner : IDelayedProcessor
    {
        private Timer timer;
        private ILog log;
        private ICommandRepository cmdRepo;
        private int ageInDaysOfCommandsToMaintain;

        public CommandsCleaner(int interval, int ageInDaysOfCommandsToMaintain, ICommandRepository cmdRepo, ILog log)
        {
            this.cmdRepo = cmdRepo;
            this.ageInDaysOfCommandsToMaintain = ageInDaysOfCommandsToMaintain;
            this.log = log;
            this.timer = new Timer();
            if (interval > 0)
            {
                this.timer.Interval = interval;
                this.timer.Elapsed += new ElapsedEventHandler(OnTimedEvent);
                this.timer.Enabled = true;
            }
            else
            {
                this.timer.Interval = TimeSpan.FromDays(1).TotalMilliseconds;
                this.timer.Enabled = false;
            }
        }

        public void Start()
        {
            if (this.timer.Enabled)
            {
                this.log.InfoFormat("Commands cleaner instance started. Will run each {0} millisecs.", this.timer.Interval);
                this.OnTimedEvent(this, null);
                this.timer.Start();
            }
            else
            {
                this.log.Warn("Commands cleaner instance not starting because interval is set to zero or less.");
            }
        }

        public void Stop()
        {
            this.timer.Stop();
        }

        private void OnTimedEvent(object sender, ElapsedEventArgs e)
        {
            try
            {
                this.log.Info("Commands cleaner triggered.");
                var removedTokens = cmdRepo.DeleteOldCommands(this.ageInDaysOfCommandsToMaintain, true);
                this.log.InfoFormat("{0} commands have been cleaned.", removedTokens.Count());
            }
            catch (Exception ex)
            {
                this.log.Error("Error cleaning commands.", ex);
            }

        }
    }
}
