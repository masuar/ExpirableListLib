﻿using log4net;
using Newtonsoft.Json;
using SmartCaps.FR.NetMessaging.Services;
using SmartCaps.FR.Common.Model;
using SmartCaps.FR.Common.Model.Commands;
using SmartCaps.FR.Common.Repos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace SmartCaps.FR.Updater.Services
{
    public class UpdaterService : IUpdaterService
    {
        private IPublisherService publisherToKnn;
        private IPublisherService publisher;
        private ICommandRepository cmdRepo;
        private IFaceRepository faceRepo;
        private MatchConfiguration matchConf;
        private ILog log;

        public UpdaterService(ICommandRepository cmdRepo, IFaceRepository faceRepo, IPublisherService publisherToKnn, IPublisherService publisher, MatchConfiguration matchConf, ILog log)
        {
            this.cmdRepo = cmdRepo;
            this.faceRepo = faceRepo;
            this.publisherToKnn = publisherToKnn;
            this.publisher = publisher;
            this.matchConf = matchConf;
            this.log = log;
        }

        public void EnrollFaces(IFacesCommand cmd)
        {
            try
            {
                string notReadyMsg = string.Empty;
                int howManyNotReady = cmd.Faces.Count(f => !f.Evaluated);
                if (howManyNotReady > 0)
                {
                    notReadyMsg = string.Format(" ({0} not ready yet)", howManyNotReady);
                }
                this.log.InfoFormat("Saving {0} faces to the DB{1}...", cmd.Faces.Count, notReadyMsg);
                var result = this.faceRepo.AddFaces(cmd.Faces);
                foreach (var alreadyExisting in result.AlreadyExistingFaces)
                {
                    cmd.Faces.Single(f => f.Id == alreadyExisting.Id).AlreadyExisting = true;
                }

                // TODO: Callback processing here...

                string logMsg = string.Format("{0} faces saved to the DB successfully{3}, {1} faces already existing. There are {2} faces in the DB now.", result.AddedFaces.Count, result.AlreadyExistingFaces.Count, this.faceRepo.GetFacesCount(), notReadyMsg);
                if (result.AlreadyExistingFaces.Count > 0)
                {
                    this.log.Warn(logMsg);
                }
                else
                {
                    this.log.Info(logMsg);
                }

            }
            catch (Exception ex)
            {
                this.log.Warn(ex.Message);
            }
            finally
            {
                this.cmdRepo.InsertOrUpdateCommand(cmd);
            }
        }

        public void ProcessVideoResults(IFacesCommand cmd)
        {
            try
            {
                this.log.Info("Processing video command results...");
                this.cmdRepo.InsertOrUpdateCommand(cmd);
                this.log.Info("Command updated.");

                // Drop the video file if it is on FILESYS
                if (cmd.ImageRef != null && cmd.ImageRef.RefType == ImageRefTypes.FILESYS)
                {
                    File.Delete(cmd.ImageRef.Path);
                }
                
                // TODO: Callback processing here...
                this.log.InfoFormat("Processing of video '{0}' was successful.", cmd.ImageRef.Id);
            }
            catch (Exception ex)
            {
                this.log.Error(ex);
            }
        }

        public void ProcessEvalResults(IEvalCommand cmd)
        {
            try
            {
                this.log.Info("Processing face/s evaluation results...");

                IEvalCommand alreadyExistingEvalCommand = this.cmdRepo.GetCommandByToken(cmd.Token) as IEvalCommand;
                if (alreadyExistingEvalCommand != null)
                {
                    alreadyExistingEvalCommand.Neighbors.Clear();
                    alreadyExistingEvalCommand.TopN = cmd.TopN;
                    foreach(var neighbor in cmd.Neighbors)
                    {
                        alreadyExistingEvalCommand.Neighbors.Add(neighbor);
                    }
                    alreadyExistingEvalCommand.LastUpdatedBy = cmd.LastUpdatedBy;
                    alreadyExistingEvalCommand.LastUpdatedOn = cmd.LastUpdatedOn;
                    alreadyExistingEvalCommand.LastStepCompleted = cmd.LastStepCompleted;

                    cmd = alreadyExistingEvalCommand;
                }
                this.cmdRepo.InsertOrUpdateCommand(cmd);

                foreach (var item in cmd.Neighbors)
                {
                    Face theFace1 = this.faceRepo.GetFaceById(item.SourceFaceId, false);
                    if (theFace1 != null && !theFace1.Evaluated)
                    {
                        theFace1.Evaluated = true;
                        this.faceRepo.SetFaceEvaluation(item.SourceFaceId, true);
                    }

                    // Set up posible matches when grade is lower than a threshold
                    if (item.Grade <= this.matchConf.Threshold && item.SourceFaceId != item.TargetFaceId)
                    {
                        if (theFace1 != null && !theFace1.Tags.Contains(this.matchConf.TagText))
                        {
                            theFace1.Tags.Add(this.matchConf.TagText);
                            this.faceRepo.SetFaceTags(theFace1.Id, theFace1.Tags);
                        }

                        Face theFace2 = this.faceRepo.GetFaceById(item.TargetFaceId, false);
                        if (theFace2 != null && !theFace2.Tags.Contains(this.matchConf.TagText))
                        {

                            theFace2.Tags.Add(this.matchConf.TagText);
                            this.faceRepo.SetFaceTags(theFace2.Id, theFace2.Tags);
                        }
                    }
                }

                // TODO: Watchlist processing here...

                // TODO: Callback processing here...

                this.log.InfoFormat("{0} evaluation results processed successfully.", cmd.Neighbors.Count);
            }
            catch (Exception ex)
            {
                this.log.Error(ex);
            }
        }

        public void PublishIAmAlive(string token)
        {
            System.Threading.Thread.Sleep(125);
            ICommand cmd = new StatusCommand(token);
            cmd.StepsCompleted = ComponentSteps.Updater;
            cmd.LastUpdatedBy = "Updater";
            cmd.LastUpdatedOn = DateTime.Now;

            Dictionary<string, string> props = new Dictionary<string, string>();
            string json = JsonConvert.SerializeObject(cmd);
            this.publisher.Publish("SmartCaps.FR.Status.IAmAlive", json);
        }


        public void ProcessEvalRequest(IFacesCommand cmd)
        {
            try
            {
                this.log.Info("Processing face/s extraction results...");
                this.cmdRepo.InsertOrUpdateCommand(cmd);
                this.log.InfoFormat("{0} face extraction results processed successfully.", cmd.Faces.Count);
            }
            catch (Exception ex)
            {
                this.log.Error(ex);
            }
        }

        public void RepublishEnrollFaces(int batchSize)
        {
            int pageSize = batchSize;
            int totalPages = (int)(this.faceRepo.GetFacesCount() / pageSize) + 1;

            for (int pageIndex = 0; pageIndex < totalPages; pageIndex++)
            {
                IEnumerable<Face> faces = this.faceRepo.GetFaces(pageIndex, pageSize, true);

                string newToken = Guid.NewGuid().ToString();
                EnrollImageCommand cmdToPublish = new EnrollImageCommand(newToken);
                foreach (Face face in faces)
                {
                    cmdToPublish.Faces.Add(new FaceInCommand(face) { AlreadyExisting = true });
                }
                if (cmdToPublish.Faces.Count > 0)
                {
                    this.log.DebugFormat("Composing and sending re-enrollment message num. {0}...", pageIndex);
                    Dictionary<string, string> props = new Dictionary<string, string>();
                    props.Add("JMS_AMQP_ContentType", "SmartCaps.FR.EnrollImage.FacesExtracted");
                    string json = JsonConvert.SerializeObject(cmdToPublish);
                    this.publisherToKnn.Publish("SmartCaps.FR.EnrollImage.FacesExtracted", json, props);
                    this.log.Debug("Message sent.");
                }
            }
        }

        public void ProcessError(ErrorCommand cmd)
        {
            try
            {
                this.log.Warn("Processing error command...");
                this.cmdRepo.InsertOrUpdateCommand(cmd);
                this.log.WarnFormat("Error command for token '{0}' processed successfully.", cmd.Token);
            }
            catch (Exception ex)
            {
                this.log.Error(ex);
            }
        }

        public void RemoveFaces(RemoveFacesCommand cmd)
        {
            try
            {
                this.log.Warn("Processing remove faces command...");
                int succeeded = 0;
                foreach (var face in cmd.Faces)
                {
                    if (this.faceRepo.RemoveFaceById(face.Id))
                    {
                        succeeded++;
                    }

                }
                cmd.LastStepCompleted = 1;
                this.cmdRepo.InsertOrUpdateCommand((ICommand)cmd);
                this.log.WarnFormat("{0} faces where removed successfully.", succeeded);
            }
            catch (Exception ex)
            {
                this.log.Error(ex);
            }
        }

        public void ProcessStatusRequest(StatusCommand cmd)
        {
            try
            {
                this.log.Debug("Processing status command...");
                var statusCmd = this.cmdRepo.GetCommandByToken(cmd.Token);

                if(statusCmd != null)
                { 
                    cmd.LastStepCompleted = statusCmd.StepsCompleted.ToString().Split(',').Count() + 1;
                    if (!statusCmd.StepsCompleted.HasFlag(cmd.StepsCompleted))
                    {
                        cmd.StepsCompleted = statusCmd.StepsCompleted | cmd.StepsCompleted;
                    }
                }
                else
                {
                    cmd.LastStepCompleted = 1;
                }

                this.cmdRepo.InsertOrUpdateCommand(cmd);
                this.log.DebugFormat("Status command for token '{0}' processed successfully.", cmd.Token);
            }
            catch (Exception ex)
            {
                this.log.Error(ex);
            }
        }
    }
}
