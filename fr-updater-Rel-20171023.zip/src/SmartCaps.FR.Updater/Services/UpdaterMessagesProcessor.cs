﻿using SmartCaps.FR.NetMessaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmartCaps.FR.NetMessaging.Services;
using log4net;
using Newtonsoft.Json;
using SmartCaps.FR.Common.Model.Commands;

namespace SmartCaps.FR.Updater.Services
{
    public class UpdaterMessagesProcessor : MessagesProcessor
    {
        private int reEnrollBatchSize;
        private IUpdaterService updSvc;

        public UpdaterMessagesProcessor(IConsumerService consumer, IUpdaterService updSvc, int reEnrollBatchSize, ILog log) 
            : base(consumer, log)
        {
            this.updSvc = updSvc;
            this.reEnrollBatchSize = reEnrollBatchSize;
        }

        protected override void ProcessMessage(MessageArrivedEventArgs e)
        {
            try
            {
                string routingKey = e.TypeName;
                this.log.DebugFormat("Message with routing key '{0}' received.", routingKey);

                string json = Encoding.UTF8.GetString(e.BytesPayload);
                bool isOk = true;
                if (routingKey.ToLower().Contains("error"))
                {
                    this.updSvc.ProcessError(JsonConvert.DeserializeObject<ErrorCommand>(json));
                }
                else
                {
                    switch (routingKey)
                    {
                        case "SmartCaps.FR.ReEnroll":
                            this.updSvc.RepublishEnrollFaces(this.reEnrollBatchSize);
                            break;
                        case "SmartCaps.FR.BatchEnrollImage.FacesExtracted":
                            this.updSvc.EnrollFaces(JsonConvert.DeserializeObject<BatchEnrollImageCommand>(json));
                            break;
                        case "SmartCaps.FR.EnrollImagesFromVideo.VideoDone":
                            this.updSvc.ProcessVideoResults(JsonConvert.DeserializeObject<EnrollImageCommand>(json));
                            break;
                        case "SmartCaps.FR.EnrollImage.FacesExtracted":
                            this.updSvc.EnrollFaces(JsonConvert.DeserializeObject<EnrollImageCommand>(json));
                            break;
                        case "SmartCaps.FR.EnrollAndEvalImage.FacesExtracted":
                            this.updSvc.EnrollFaces(JsonConvert.DeserializeObject<EnrollAndEvalImageCommand>(json));
                            break;
                        case "SmartCaps.FR.EnrollAndEvalImage.FacesExtracted.KnnDone":
                            this.updSvc.ProcessEvalResults((IEvalCommand)JsonConvert.DeserializeObject<EnrollAndEvalImageCommand>(json));
                            break;
                        case "SmartCaps.FR.EvalImage.FacesExtracted":
                            this.updSvc.ProcessEvalRequest((IFacesCommand)JsonConvert.DeserializeObject<EvalImageCommand>(json));
                            break;
                        case "SmartCaps.FR.EvalImage.FacesExtracted.KnnDone":
                            this.updSvc.ProcessEvalResults((IEvalCommand)JsonConvert.DeserializeObject<EvalImageCommand>(json));
                            break;
                        case "SmartCaps.FR.RemoveFaces":
                            this.updSvc.RemoveFaces(JsonConvert.DeserializeObject<RemoveFacesCommand>(json));
                            break;
                        case "SmartCaps.FR.Status":
                            this.updSvc.PublishIAmAlive(JsonConvert.DeserializeObject<StatusCommand>(json).Token);
                            break;
                        case "SmartCaps.FR.Status.IAmAlive":
                            this.updSvc.ProcessStatusRequest(JsonConvert.DeserializeObject<StatusCommand>(json));
                            break;
                        default:
                            this.log.WarnFormat("Unexpected message: {0}", routingKey);
                            isOk = false;
                            e.Ack = false;
                            break;
                    }
                }
                if (isOk)
                {
                    this.log.Info("Message processed successfully.");
                    e.Ack = true;
                }
            }
            catch (Exception ex)
            {
                this.log.Error("Error processing message.", ex);
                e.Ack = false;
            }
        }
    }
}
