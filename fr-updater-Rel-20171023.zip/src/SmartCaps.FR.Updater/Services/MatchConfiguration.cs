﻿using log4net;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Updater.Services
{
    public class MatchConfiguration
    {
        private static readonly string defaultTagText = "possible match";
        private static readonly double defaultThreshold = 0.3d;

        public MatchConfiguration(string tagText, double threshold)
        {
            if (string.IsNullOrEmpty(tagText))
            {
                tagText = defaultTagText;
            }
            this.TagText = tagText;
            this.Threshold = threshold;
        }

        public MatchConfiguration()
            : this(defaultTagText, defaultThreshold)
        {
        }

        public double Threshold { get; private set; }
        public string TagText { get; private set; }

        public void GetFromApiServer(Uri apiServer, string user, string pwd, ILog log)
        {
            var endpoint = "settings";
            using (var client = new HttpClient(new HttpClientHandler() { UseDefaultCredentials = true }))
            {
                var userPwString = string.Format("{0}:{1}", user, pwd);
                var userPwArray = Encoding.ASCII.GetBytes(userPwString);
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(userPwArray));

                try
                {
                    var response = client.GetAsync(new Uri(apiServer, endpoint)).Result;
                    if (!response.IsSuccessStatusCode)
                    {
                        log.ErrorFormat("Unable to get settings from Face Recognition server. Error {0}", response.StatusCode);
                        log.WarnFormat("Using default settings. {0}", this.ToString());
                    }
                    else
                    {
                        string strSettings = response.Content.ReadAsStringAsync().Result;
                        dynamic dynObj = JObject.Parse(strSettings);
                        this.Threshold = dynObj.autoMatch.threshold;
                        this.TagText = dynObj.autoMatch.tagString;
                        log.InfoFormat("Settings read successfully from {0}. {1}", apiServer, this.ToString());
                    }
                }
                catch (Exception ex)
                {
                    log.Error(String.Format("An error ocurred while gettings settings from {0}.", apiServer), ex);
                    log.WarnFormat("Using default settings. {0}", this.ToString());
                }
            }
        }

        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
}
