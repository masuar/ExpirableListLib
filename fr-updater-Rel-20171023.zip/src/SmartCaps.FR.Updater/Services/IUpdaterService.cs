﻿using SmartCaps.FR.Common.Model.Commands;

namespace SmartCaps.FR.Updater.Services
{
    public interface IUpdaterService
    {
        void EnrollFaces(IFacesCommand cmd);
        void ProcessEvalRequest(IFacesCommand cmd);
        void ProcessEvalResults(IEvalCommand cmd);
        void ProcessVideoResults(IFacesCommand cmd);
        void RemoveFaces(RemoveFacesCommand cmd);
        void RepublishEnrollFaces(int batchSize);
        void ProcessError(ErrorCommand cmd);
        void ProcessStatusRequest(StatusCommand cmd);
        void PublishIAmAlive(string token);
    }
}