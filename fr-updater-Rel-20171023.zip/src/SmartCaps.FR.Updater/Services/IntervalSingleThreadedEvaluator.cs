﻿using log4net;
using SmartCaps.FR.Common.Repos;
using SmartCaps.FR.NetMessaging.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SmartCaps.FR.Updater.Services
{
    public class IntervalSingleThreadedEvaluator : IDelayedProcessor
    {
        private int interval;
        private int maxItems;
        private ILog log;
        private BackgroundWorker bw;
        private readonly int MIN_MILLIS = 2000;
        private FaceEvaluator faceEvaluator;

        private class WorkerArgs
        {
            public int MaxItems { get; set; }
            public int MinMillis { get; set; }
            public int Interval { get; set; }
            public ILog Log { get; set; }
            public FaceEvaluator FaceEvaluator { get; set; }
        }

        public IntervalSingleThreadedEvaluator(int interval, int batchSize, int maxItems, IPublisherService publisherToKnn, IFaceRepository faceRepo, ILog log)
        {
            this.log = log;
            this.interval = interval;
            this.maxItems = maxItems;
            this.faceEvaluator = new FaceEvaluator(batchSize, publisherToKnn, faceRepo, log);

            this.bw = new BackgroundWorker();
            this.bw.WorkerSupportsCancellation = true;
            this.bw.DoWork += new DoWorkEventHandler(this.DoWork);
        }

        public void Start()
        {
            if (this.interval > 0)
            {
                WorkerArgs args = new WorkerArgs();
                args.MaxItems = this.maxItems;
                args.MinMillis = this.MIN_MILLIS;
                args.Interval = this.interval;
                args.FaceEvaluator = this.faceEvaluator;
                args.Log = log;

                this.bw.RunWorkerAsync(args);
            }
        }

        public void Stop()
        {
            this.bw.CancelAsync();
        }

        private void DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker worker = sender as BackgroundWorker;
            WorkerArgs args = (WorkerArgs)e.Argument;
            while (true)
            {
                if (worker.CancellationPending)
                {
                    e.Cancel = true;
                    args.Log.Info("Delayed evaluation process stopped.");
                    break;
                }

                Stopwatch sw = new Stopwatch();

                sw.Start();
                args.FaceEvaluator.EvaluatePendingFaces(args.MaxItems);
                sw.Stop();

                int remainingMillis = Math.Max((int)(args.Interval - sw.ElapsedMilliseconds), args.MinMillis);
                args.Log.InfoFormat("Delayed execution finished, took {0} millisecs. Will wait for {1} more until next execution.", sw.ElapsedMilliseconds, remainingMillis);
                Thread.Sleep(remainingMillis);
            }
        }

    }
}
