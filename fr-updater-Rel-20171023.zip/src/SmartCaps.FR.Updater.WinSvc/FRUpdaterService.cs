﻿using Apache.NMS;
using Apache.NMS.ActiveMQ;
using log4net;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SmartCaps.FR.NetMessaging.Services.ActiveMQ;
using SmartCaps.FR.Updater.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Updater.WinSvc
{
    public partial class FRUpdaterService : ServiceBase
    {
        private ILog log;
        private IConnection connection;
        private ISession session;
        private UpdaterMessagesProcessor messagesProcessor;
        private IDelayedProcessor delayedEvaluator;
        private CommandsCleaner commandsCleaner;

        public FRUpdaterService(ILog log)
        {
            this.log = log;
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            string libVersion = typeof(SmartCaps.FR.Common.Model.Face).Assembly.GetName().Version.ToString();
            string updVersion = typeof(SmartCaps.FR.Updater.Services.UpdaterService).Assembly.GetName().Version.ToString();
            string msgVersion = typeof(SmartCaps.FR.NetMessaging.MessagesProcessor).Assembly.GetName().Version.ToString();
            string appVersion = typeof(SmartCaps.FR.Updater.WinSvc.FRUpdaterService).Assembly.GetName().Version.ToString();
            this.log.InfoFormat("FR Updater Windows Service started! App version: {0}; Domain lib version: {1}; Updater lib version: {2}; Messaging lib version: {3}; Args: {4};", appVersion, libVersion, updVersion, msgVersion, string.Join(" ", args));

            try
            {
                this.log.Info("Reading configuration values...");
                string activeMqConn = ConfigurationManager.AppSettings["AMQConn"];
                string activeMqUser = ConfigurationManager.AppSettings["AMQUser"];
                string activeMqPwd = ConfigurationManager.AppSettings["AMQPwd"];
                string listenToQueue = ConfigurationManager.AppSettings["ListenToQueue"];
                string knnQueue = ConfigurationManager.AppSettings["KnnQueue"];
                string faceRecognitionServer = ConfigurationManager.AppSettings["FaceRecognitionService"];
                string basicAuthUser = ConfigurationManager.AppSettings["ApiUser"];
                string basicAuthPwd = ConfigurationManager.AppSettings["ApiPwd"];
                string delayedKnnInterval = ConfigurationManager.AppSettings["DelayedKnnInterval"];
                int delayedKnnBatchSize = int.Parse(ConfigurationManager.AppSettings["DelayedKnnBatchSize"]);
                int faceDbCommandstimeOut = int.Parse(ConfigurationManager.AppSettings["FaceDbCommandstimeOut"]);

                // If this parameter is not there, use zero
                int commandsCleaningInterval = 0;
                if (ConfigurationManager.AppSettings["CommandsCleaningInterval"] != null)
                {
                    commandsCleaningInterval = int.Parse(ConfigurationManager.AppSettings["CommandsCleaningInterval"]);
                }

                // If this parameter is not there, use zero
                int delayedKnnMaxItems = 0;
                if (ConfigurationManager.AppSettings["DelayedKnnMaxItems"] != null)
                {
                    delayedKnnMaxItems = int.Parse(ConfigurationManager.AppSettings["DelayedKnnMaxItems"]);
                }


                int cmdDbCommandstimeOut = int.Parse(ConfigurationManager.AppSettings["CmdDbCommandstimeOut"]);
                int ageInDaysOfCommandsToMaintain = int.Parse(ConfigurationManager.AppSettings["AgeInDaysOfCommandsToMaintain"]); 
                string facesConnStr = ConfigurationManager.ConnectionStrings["FacesDb"].ConnectionString;
                string cmdConnStr = ConfigurationManager.ConnectionStrings["CommandsDb"].ConnectionString;

                int reEnrollBatchSize = int.Parse(ConfigurationManager.AppSettings["ReEnrollBatchSize"]);
                this.log.InfoFormat("AMQ Conn: {0}; Listening queue: {1}; Knn queue: {2}; FR API: {3}; Re-enroll batch size: {4};", activeMqConn, listenToQueue, knnQueue, faceRecognitionServer, reEnrollBatchSize);

                MatchConfiguration matchConf = new MatchConfiguration();
                matchConf.GetFromApiServer(new Uri(faceRecognitionServer), basicAuthUser, basicAuthPwd, log);

                IConnectionFactory connectionFactory = new ConnectionFactory(new Uri(activeMqConn));
                this.connection = connectionFactory.CreateConnection(activeMqUser, activeMqPwd);
                this.session = this.connection.CreateSession(AcknowledgementMode.ClientAcknowledge);

                var cmdRepo = new Common.Repos.SQLServer.SQLServerCommandRepository(cmdConnStr, cmdDbCommandstimeOut, this.log);
                var faceRepo = new Common.Repos.SQLServer.SQLServerFaceRepository(facesConnStr, faceDbCommandstimeOut, this.log);
                var publisherToKnn = new ActiveMQPublisherService(session, knnQueue, this.log);
                var publisherSvc = new ActiveMQPublisherService(session, "topic://SmartCaps_TOPIC", this.log);

                PendingFacesProcessorResolver pendingFacesProcessorResolver = new PendingFacesProcessorResolver(delayedKnnBatchSize, delayedKnnMaxItems, publisherToKnn, faceRepo, this.log);
                this.delayedEvaluator = pendingFacesProcessorResolver.GetProcessorBasedOnInterval(delayedKnnInterval);

                this.commandsCleaner = new CommandsCleaner(commandsCleaningInterval, ageInDaysOfCommandsToMaintain, cmdRepo, log);

                this.messagesProcessor = new UpdaterMessagesProcessor(
                    new ActiveMQConsumerService(session, listenToQueue, ProcessorType.TextMessages, log),
                    new UpdaterService(cmdRepo, faceRepo, publisherToKnn, publisherSvc, matchConf, this.log),
                    reEnrollBatchSize, log);

                messagesProcessor.StartListening();
                connection.Start();

                delayedEvaluator.Start();
                commandsCleaner.Start();

                this.log.Info("Service successfully started!");
            }
            catch (Exception ex)
            {
                this.log.Fatal("Unable to start the service, fatal error found.", ex);
                throw;
            }
        }

        protected override void OnStop()
        {
            if (this.messagesProcessor != null)
            {
                this.messagesProcessor.StopListening();
            }

            this.connection.Close();
            this.delayedEvaluator.Stop();
            this.log.Info("Service successfully stopped.");
        }

    }
}
