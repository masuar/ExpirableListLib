﻿using log4net;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Updater.WinSvc
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            string instanceName = ConfigurationManager.AppSettings["InstanceName"];
            if (string.IsNullOrEmpty(instanceName))
            {
                instanceName = "UPDATER_WINSVC_1";
            }
            ILog log = LogManager.GetLogger(instanceName);
            log4net.Config.XmlConfigurator.Configure();
            log.Debug("Instantiating service...");

            ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[]
            {
                new FRUpdaterService(log)
            };
            ServiceBase.Run(ServicesToRun);
        }
    }
}
