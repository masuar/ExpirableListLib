function hasClass(ele, cls) {
    return ele.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));
}

function removeClass(ele, cls) {
    if (hasClass(ele, cls)) {
        var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');
        ele.className = ele.className.replace(reg, '')
    }
}

function removeFromStringArray(array, searchTerm) {
    var index = array.indexOf(searchTerm);
    if (index !== -1) {
        array.splice(index, 1);
    }
    return array;
}

function round(value, decimals)
{
    return Number(Math.round(value + 'e' + decimals) + 'e-' + decimals);
}

//scroll to top
(function ($) {
    $.fn.backTop = function () {
        var backBtn = this;

        var position = 1000;
        var speed = 900;

        $(document).scroll(function () {
            var pos = $(window).scrollTop();

            if (pos >= position) {
                backBtn.fadeIn(speed);
            } else {
                backBtn.fadeOut(speed);
            }
        });

        backBtn.click(function () {
            $("html, body").animate({ scrollTop: 0 }, 900);
        });
    }
}(jQuery));

function getAppHostUrl() {
    var url = window.location.href;
    var arr = url.split("/");
    var root = $('body').data("root");
    var result = arr[0] + '//' + arr[2] + root;

    return result;
}

var applyLoader = true;
var secundaryLoader = false;
$(document).bind({
    ajaxStart: function () {
        if (applyLoader)
        {
            showLoading('.loading-panel');
        }
        if (secundaryLoader)
        {
            showLoading('.loading-panel-secundary');
        }
    },
    ajaxStop: function () {
        hideLoading();
        applyLoader = true;
        secundaryLoader = false;
    }
});

function getHostUrl() {
    var url = window.location.href;
    var arr = url.split("/");
    var root = $('body').data("root");
    var result = arr[0] + "//" + arr[2] + root;
    return result;
}

function showLoading(divId) {
    if ($(divId + " .loader").length) {
        $(divId + " .loader").css({ display: "block" });
    } else {
        $("<div class='loader'></div>").css(
            {
                position: "absolute",
                display: "block",
                width: "100%",
                height: "100%",
                top: 0,
                left: 0,
                "min-height": "50px",
                "min-width": "50px",
                background: "white url(" + getAppHostUrl() +"/content/images/ajax-loader.gif) 50% 50% no-repeat",
                "z-index": 999999
            }).appendTo($(divId).css("position", "relative"));
    }     
}

function hideLoading() {
    $('.loader').css({ display: "none" });
}

function showNotification(text, type, position) {
    if (type == "warning") {
        text = '<strong>Warning!</strong><br/>' + text;
    }
    if (type == "success") {
        text = '<strong>Success!</strong><br/>' + text;
    }
    if (type == "error") {
        text = '<strong>Error!</strong><br/>' + text;
    }

    new Noty({
        text: text,
        layout: position,
        type: type,
        dismissQueue: true,
        timeout: 5000,
        progressBar: true,
        theme: 'relax',
        buttons: false
    }).show();
}

