﻿var statusViewModel;

function initializeStatusInformation()
{
    $.when(GetApiStatus())
    .done(function (data) {
        statusViewModel = new StatusViewModel(data);
        ko.applyBindings(statusViewModel);
    });
}

$(document).ready(function () {
    initializeStatusInformation();
});
