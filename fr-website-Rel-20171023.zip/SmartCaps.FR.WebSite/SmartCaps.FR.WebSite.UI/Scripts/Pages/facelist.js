﻿var faceListViewModel;
var t, $tagBox, searchSienaBox, searchFocalPointsBox, searchTagsBox;
var selectedFaces = [];

function initializeFaceGrid(pageIndex, pageSize, withMetada, faceStatus, tags, sienaRefs, focalPoints, owner) {
    $.when(GetFaceList(pageIndex, pageSize, withMetada, faceStatus, owner, tags, sienaRefs, focalPoints))
    .done(function (data) {
        faceListViewModel = new FaceListViewModel(data);
        initiatePagination(faceListViewModel.totalPages, pageSize, parseInt(pageIndex) + 1, true);
        ko.applyBindings(faceListViewModel);
        initiateDinamycComponents();
        if (faceListViewModel.faces().length == 0) {
            $('.empty-grid-container').css({ display: "block" });
        }

        setFacesSelectedStyle();
        faceListViewModel.selectedItemsCount(selectedFaces.length);
    });
}

function setFacesSelectedStyle() {
    var facesDisplayed = $('.photo');
    for (var i = 0; i < facesDisplayed.length; i++) {
        var faceId = facesDisplayed[i].getElementsByClassName('check-hidden')[0].dataset.id;
        if (selectedFaces.indexOf(faceId) >= 0) {
            facesDisplayed[i].className += " face-selected";
            facesDisplayed[i].getElementsByClassName('check-hidden')[0].value = true;
            var imagesNotSelected = $('.photo').not('.face-selected');
            if (imagesNotSelected == undefined || imagesNotSelected.length <= 0) {
                removeClass($('#btnSelectAllFaces').children()[0], 'fa-square-o');
                $('#btnSelectAllFaces').children()[0].className += " fa-check-square-o";
            }
        }
    }
}

function initiateDinamycComponents() {
    $(".sienaTagBox").tagging();
    $("#inputSienaTags").tagging();

    $("#inputFocalPointsTags").tagging();
    $(".focalPoinTagBox").tagging();

    $('.tooltip').tooltipster({
        theme: 'tooltipster-light',
        contentCloning: true,
        interactive: true
    });
    $('.photo').click(function (item) {
        var faceDiv = item.currentTarget;
        var checkBox = item.currentTarget.getElementsByClassName('check-hidden');
        if (checkBox[0].value == "false") {
            faceDiv.className += " face-selected";
            checkBox[0].value = true;
            faceListViewModel.selectedItemsCount(faceListViewModel.selectedItemsCount() + 1);
            selectedFaces.push(checkBox[0].dataset.id);
            var imagesNotSelected = $('.photo').not('.face-selected');
            if (imagesNotSelected == undefined || imagesNotSelected.length <= 0) {
                removeClass($('#btnSelectAllFaces').children()[0], 'fa-square-o');
                $('#btnSelectAllFaces').children()[0].className += " fa-check-square-o";
            }
        }
        else {
            resetSelectDeselectAllBtn();
            removeClass(faceDiv, "face-selected");
            checkBox[0].value = false;
            selectedFaces = removeFromStringArray(selectedFaces, checkBox[0].dataset.id);
            faceListViewModel.selectedItemsCount(faceListViewModel.selectedItemsCount() - 1);
        }
        sessionStorage.setItem("selectedFaces", selectedFaces);
    });
    $('.face-image').click(function (item) {
        var faceDiv = item.currentTarget;
        var checkBox = item.currentTarget.getElementsByClassName('check-hidden');
        if (checkBox.length > 0) {
            if (checkBox[0].value == "false") {
                faceDiv.className += " face-selected";
                checkBox[0].value = true;
            }
            else {
                removeClass(faceDiv, "face-selected");
                checkBox[0].value = false;
            }
        }
    });
    $('.detailLink').click(function (event) {
        event.stopPropagation();
    });
}

function initiatePagination(pages, itemsPerPage, currentPage, firstRun) {
    $('.pagination').pagination({
        pages: pages,
        knockOutClickBind: 'loadPage',
        currentPage: currentPage,
        firstRun: firstRun,
        listStyle: 'pagination',
        knockOutModel: faceListViewModel,
        knockOutFunction: faceListViewModel.loadPage
    });
}

function refreshFaceListGrid(pageIndex) {
    var pageSize = $('#cboItemsPerPage option:selected').val();
    var faceStatus = $('#cboFaceStatus option:selected').val();
    sessionStorage.setItem("pageSize", pageSize);
    sessionStorage.setItem("faceStatus", faceStatus);
    sessionStorage.setItem("pageIndex", pageIndex);
    var sienaNumbers = searchSienaBox.tagging('getTags', '');
    var tags = searchTagsBox.tagging('getTags', '');
    var focalPoints = searchFocalPointsBox.tagging('getTags', '');

    updateRemoveFiltersBtn(sienaNumbers.length, tags.length, focalPoints.length);

    if (faceStatus == "My Pending") {
        $('#cboFilterUser').val(defaults.Owner.toLowerCase());
    }

    var owner = $('#cboFilterUser').val();
    sessionStorage.setItem("owner", owner);

    $.when(GetFaceList(pageIndex, pageSize, true, faceStatus, owner, tags, sienaNumbers, focalPoints))
        .done(function (data) {
            faceListViewModel.faces(
                (data.data) ?
                ko.utils.arrayMap(data.data,
                    function (item) {
                        var faceViewModel = new FaceViewModel(item);
                        return faceViewModel;
                    })
                : null);
            faceListViewModel.currentPage((data.currentPage + 1) + " / " + data.totalPages);
            faceListViewModel.nextPageUrl(data.nextPageLink);
            faceListViewModel.previousPageUrl(data.prevPageLink);
            faceListViewModel.totalPages = data.totalPages;
            faceListViewModel.totalItems(data.totalItems);
            initiateDinamycComponents();
            initiatePagination(faceListViewModel.totalPages, pageSize, pageIndex + 1, false);
            updateConfirmUnconfirmDisabledStatus($('#cboFaceStatus option:selected').val());
            if (faceListViewModel.faces().length == 0) {
                $('.empty-grid-container').css({ display: "block" });
            } else {
                $('.empty-grid-container').css({ display: "none" });
            }
            resetSelectDeselectAllBtn();
            setFacesSelectedStyle();
        });
}

function updateRemoveFiltersBtn(totalSienaNumbers, totalTags, totalFocalPoints) {
    var totalFilters = totalSienaNumbers + totalTags + totalFocalPoints;
    if (totalFilters > 0) {
        if (hasClass($('#btnRemoveFilters')[0], 'hidden')) {
            removeClass($('#btnRemoveFilters')[0], 'hidden');
        }
    }
    else {
        if (!hasClass($('#btnRemoveFilters')[0], 'hidden')) {
            $('#btnRemoveFilters').addClass('hidden');
        }
    }
}

function updateConfirmUnconfirmDisabledStatus(faceListStatus) {
    if (faceListStatus == "My Pending" || faceListStatus == "All Pending") {
        $('#btnUnconfirmFaces').prop('disabled', true);
        $('#btnConfirmFaces').prop('disabled', false);
    }
    else {
        $('#btnUnconfirmFaces').prop('disabled', false);
        $('#btnConfirmFaces').prop('disabled', true);
    }
}

function createSelectedFacesJson(confirm) {
    var faceListJson = [];
    for (var i = 0; i < selectedFaces.length; i++) {
        var jsonObj = {
            id: selectedFaces[i],
            confirmed: confirm
        }
        faceListJson.push(jsonObj);
    };

    return faceListJson;
}

function resetSelectDeselectAllBtn() {
    if (hasClass($('#btnSelectAllFaces').children()[0], 'fa-check-square-o')) {
        removeClass($('#btnSelectAllFaces').children()[0], 'fa-check-square-o');
        $('#btnSelectAllFaces').children()[0].className += " fa-square-o";
    }
}

function defineItemsPerPageDefaultValue() {

    if (defaults.DefaultPageSize != null) {
        var existingOption = $('#cboItemsPerPage option[value="' + defaults.DefaultPageSize + '"]');
        if (existingOption.length == 0) {
            var option = document.createElement("option");
            var select = $('#cboItemsPerPage');
            option.text = defaults.DefaultPageSize;
            option.value = defaults.DefaultPageSize;
            select.append(option);
            select.val(defaults.DefaultPageSize);
            var selectOptions = $('#cboItemsPerPage option');
            selectOptions.sort(function (a, b) {
                a = a.value;
                b = b.value;

                return a - b;
            });

            select.html(selectOptions);
        }
    }
}

function setRangeValues() {
    $('.range-slider-range').val(defaults.faceDefaultThreshold);
    $('.range-slider-value').text(defaults.faceDefaultThreshold);
    $('.range-slider-range').prop('min', defaults.faceMinThreshold);
    $('.range-slider-range').prop('max', defaults.faceMaxThreshold);
}

function applyFilterTag(tagClass, tag) {
    if (
        (tagClass == 'tag' && (sessionStorage.getItem('tagsSearchItems') == null || sessionStorage.getItem('tagsSearchItems').toString().toLowerCase().split(',').indexOf(tag.toLowerCase()) == -1)) ||
        (tagClass == 'sienaTag' && (sessionStorage.getItem('sienaSearchItems') == null || sessionStorage.getItem('sienaSearchItems').toString().toLowerCase().split(',').indexOf(tag.toLowerCase()) == -1)) ||
        (tagClass == 'focalPointTag' && (sessionStorage.getItem('focalPointsSearchItems') == null || sessionStorage.getItem('focalPointsSearchItems').toString().toLowerCase().split(',').indexOf(tag.toLowerCase()) == -1))
        ) {
        refreshFaceListGrid(0);
        sessionStorage.setItem('sienaSearchItems', searchSienaBox.tagging('getTags', ''));
        sessionStorage.setItem('tagsSearchItems', searchTagsBox.tagging('getTags', ''));
        sessionStorage.setItem('focalPointsSearchItems', searchFocalPointsBox.tagging('getTags', ''));
    }

    $('.tooltip').tooltipster({
        theme: 'tooltipster-light',
        interactive: true
    });
}

function removeFilterTag() {
    refreshFaceListGrid(0);
    sessionStorage.setItem('sienaSearchItems', searchSienaBox.tagging('getTags', ''));
    sessionStorage.setItem('tagsSearchItems', searchTagsBox.tagging('getTags', ''));
    sessionStorage.setItem('focalPointsSearchItems', searchFocalPointsBox.tagging('getTags', ''));
}

function addTags(tags, sienaNumbers, focalPoints) {
    var i;
    if (tags != null) {
        for (i = 0; i < tags.length; i++) {
            searchTagsBox.tagging("add", tags[i]);
        }
    }
}

function addSienaNumbers(sienaNumbers) {
    var i;

    if (sienaNumbers != null) {
        for (i = 0; i < sienaNumbers.length; i++) {
            searchSienaBox.tagging("add", sienaNumbers[i]);
        }
    }
}

function addFocalPoints(tags, sienaNumbers, focalPoints) {
    var i;
    if (focalPoints != null) {
        for (i = 0; i < focalPoints.length; i++) {
            searchFocalPointsBox.tagging("add", focalPoints[i]);
        }
    }
}

function CountAlreadyExisting(successObj) {
    var count = 0;
    for (var i = 0; i < successObj.length; i++) {
        count += successObj[i].alreadyExistingFaces.length;
    }
    return count;
}

function CountEnrolledFaces(successObj) {
    var count = 0;
    for (var i = 0; i < successObj.length; i++) {
        count += successObj[i].enrolledFaces.length;
    }
    return count;
}

function InitiateTagsSearchInputs(sessionTags, sessionSienaRefs, sessionFocalPoints) {
    var taggingBox;

    //tags search set up 
    $.when(GetTags())
    .done(function (data) {
        var options = {
            "add-function": true,
            "remove-function": true,
            "remove-function-implementation": "removeFilterTag",
            "add-function-implementation": "applyFilterTag",
            "tags-input-name": "searchTags",
            "type-zone-id": "tags-type-zone-id",
            "auto-complete": true,
            "auto-complete-data": data
        };
        taggingBox = $("#searchTagBox").tagging(options);
        searchTagsBox = taggingBox[0];
        addTags(sessionTags);
    });

    //Sienas
    $.when(GetSienaRefs())
    .done(function (data) {
        var options = {
            "add-function": true,
            "remove-function": true,
            "remove-function-implementation": "removeFilterTag",
            "add-function-implementation": "applyFilterTag",
            "tag-class": "sienaTag",
            "tags-input-name": "searchSienaNumbers",
            "type-zone-id": "siena-type-zone-id",
            "auto-complete": true,
            "auto-complete-data": data
        };

        taggingBox = $("#searchSienaNumbersBox").tagging(options);
        searchSienaBox = taggingBox[0];
        addSienaNumbers(sessionSienaRefs);
    });

    //FocalPoints search set up 
    $.when(GetFocalPoints())
     .done(function (data) {
         var options = {
             "add-function": true,
             "remove-function": true,
             "remove-function-implementation": "removeFilterTag",
             "add-function-implementation": "applyFilterTag",
             "tag-class": "focalPointTag",
             "tags-input-name": "searchFocalPoints",
             "type-zone-id": "focalpoints-type-zone-id",
             "auto-complete": true,
             "auto-complete-data": data
         };

         taggingBox = $("#searchFocalPointsBox").tagging(options);
         searchFocalPointsBox = taggingBox[0];
         addFocalPoints(sessionFocalPoints);
         t = $("#tagBox").tagging();
         $tagBox = t[0];
     });
}

$('#rgThreshold').on("input change", function () {
    $('.range-slider-value').text($('.range-slider-range').val());
});

$('#btnRemoveFilters').click(function () {
    searchSienaBox.tagging('removeAll', '');
    searchTagsBox.tagging('removeAll', '');
    searchFocalPointsBox.tagging('removeAll', '');
    sessionStorage.setItem('sienaSearchItems', []);
    sessionStorage.setItem('focalPointsSearchItems', []);
    sessionStorage.setItem('tagsSearchItems', []);
});

$('#btnConfirmFaces').click(function () {
    var numberOfFacesSelected = selectedFaces.length;
    if (numberOfFacesSelected > 0) {
        faceListViewModel
        var n = new Noty({
            text: "Push all selected Faces to FRDB?",
            layout: 'center',
            modal: true,
            theme: 'relax',
            buttons: [
                Noty.button('Yes',
                    'btn btn-primary margin-r-5',
                    function () {
                        n.close();
                        $.when(PatchFaces(createSelectedFacesJson(true)))
                            .done(function () {
                                selectedFaces = [];
                                sessionStorage.setItem("selectedFaces", selectedFaces);
                                refreshFaceListGrid($('.active').text() - 1);
                                showNotification(numberOfFacesSelected + ' face/s pushed to FRDB', 'success', 'topRight');
                            })
                            .fail(function () {
                                n.close();
                                showNotification('Selected faces not pushed to FRDB an error has occured',
                                    'error',
                                    'topRight');
                            }
                            );
                    }),
                Noty.button('No',
                    'btn btn-danger',
                    function () {
                        n.close();
                    })
            ]
        }).show();
    } else {
        showNotification('You need to select at least one face', 'warning', 'topRight');
    }
});

$('#btnUnconfirmFaces').click(function () {
    var numberOfFacesSelected = selectedFaces.length;
    if (numberOfFacesSelected > 0) {
        var n = new Noty({
            text: "Delete all selected Faces from FRDB?",
            layout: 'center',
            modal: true,
            theme: 'relax',
            buttons: [
                Noty.button('Yes',
                    'btn btn-primary margin-r-5',
                    function () {
                        n.close();
                        $.when(PatchFaces(createSelectedFacesJson(false)))
                            .done(function () {
                                selectedFaces = [];
                                sessionStorage.setItem("selectedFaces", selectedFaces);
                                refreshFaceListGrid($('.active').text() - 1);
                                showNotification(numberOfFacesSelected + ' face/s removed from FRDB', 'success', 'topRight');
                            })
                            .fail(function () {
                                n.close();
                                showNotification('Selected faces not removed from FRDB an error has occured',
                                    'error',
                                    'topRight');
                            }
                            );
                    }),
                Noty.button('No',
                    'btn btn-danger',
                    function () {
                        n.close();
                    })
            ]
        }).show();
    } else {
        showNotification('You need to select at least one face', 'warning', 'topRight');
    }
});

$('#btnDeleteFaces').click(function () {
    var numberOfFacesSelected = selectedFaces.length;
    if (numberOfFacesSelected > 0) {
        var n = new Noty({
            text: "Delete all selected Faces?",
            layout: 'center',
            theme: 'relax',
            modal: true,
            buttons: [
                Noty.button('Yes',
                    'btn btn-primary margin-r-5',
                    function () {
                        n.close();
                        $.when(DeleteFaces(selectedFaces))
                            .done(function () {
                                selectedFaces = [];
                                sessionStorage.setItem("selectedFaces", selectedFaces);
                                refreshFaceListGrid($('.active').text() - 1);
                                showNotification(numberOfFacesSelected + ' face/s deleted', 'success', 'topRight');
                            })
                            .fail(function () {
                                n.close();
                                showNotification('Selected face/s not deleted an error has occured',
                                    'error',
                                    'topRight');
                            }
                            );
                    }),
                Noty.button('No',
                    'btn btn-danger',
                    function () {
                        n.close();
                    })
            ]
        }).show();
    } else {
        showNotification('You need to select at least one face', 'warning', 'topRight');
    }
});

$('#btnUploadPhotos').click(function (e) {
    e.preventDefault();
    // slide value 
    var tags = [],
        sienaRefs = [],
        focalPoints = [];
    applyLoader = false;
    secundaryLoader = true;
    var threshold = $('.range-slider-range').val();
    tags = tags.concat($tagBox.tagging('getTags', ''));
    sienaRefs = sienaRefs.concat($("#inputSienaTags").tagging('getTags', ''));
    focalPoints = focalPoints.concat($("#inputFocalPointsTags").tagging('getTags', ''));
    var files = $('#importPhotos')[0].files;
    var autoconfirm = $('#cboAutoConfirm').prop('checked');

    if (files.length > 0) {
        $('.uploadForm').addClass("hidden");
        $('#btnUploadPhotos').addClass("hidden");
        $('.close').addClass("hidden");
        var progressBars = $('.progressBar');
        removeClass($('.uploadProgressDiv')[0], 'hidden');
        $('#lblFileProgress').text('Photos upload progress');
        $('#lblSubmitMsg').text('Submitting photos request to server, please wait...');
        $.when(UploadPhotos(tags, files, autoconfirm, threshold, sienaRefs, focalPoints, defaults.Owner))
            .done(function (photodata) {
                $('#lblFileProgress').text('Videos upload progress');
                $('#lblSubmitMsg').text('Submitting videos request to server, please wait...');
                $.when(UploadVideos(tags, files, autoconfirm, threshold, sienaRefs, focalPoints, defaults.Owner))
                    .done(function (videodata) {
                        $('#uploadPhotosWindow').modal('toggle');
                        var existingFacesCount = 0;
                        var enrolledFacesCount = 0;

                        if (photodata != false)
                        {
                            if (photodata.success.length > 0) {
                                existingFacesCount = CountAlreadyExisting(photodata.success);
                                enrolledFacesCount = CountEnrolledFaces(photodata.success);
                            }
                            if (photodata.notFinished.length > 0) {
                                showNotification('Photo upload submitted but not processed. Please wait for the process to be finished.', 'warning', 'topRight');
                            }
                        }

                        if (videodata != false) {
                            if (videodata.success.length > 0) {
                                existingFacesCount = existingFacesCount + CountAlreadyExisting(videodata.success);
                                enrolledFacesCount = enrolledFacesCount + CountEnrolledFaces(videodata.success);
                                
                            }
                            if (videodata.notFinished.length > 0) {
                                showNotification('Video upload submitted but not processed. Please wait for the process to be finished.', 'warning', 'topRight');
                            }
                        }

                        if (existingFacesCount == 1) {
                            showNotification(existingFacesCount + ' face information updated, because it was already in the database', 'success', 'topRight');
                            refreshFaceListGrid(0);
                        }
                        if (existingFacesCount > 1) {
                            showNotification(existingFacesCount + ' faces information updated, because they were already in the database', 'success', 'topRight');
                            refreshFaceListGrid(0);
                        }
                        if (enrolledFacesCount > 0) {
                            showNotification(enrolledFacesCount + ' face/s were submitted successfully', 'success', 'topRight');
                            refreshFaceListGrid(0);
                        }

                        if (enrolledFacesCount == 0 && existingFacesCount == 0 && (videodata != false && videodata.notFinished.length == 0 || videodata == false)  && (photodata != false && photodata.notFinished.length == 0 || photodata == false ))
                        {
                            showNotification('No faces were found in the file/s submitted', 'success', 'topRight');
                        }

                        $tagBox.tagging('removeAll', '');
                        $("#inputSienaTags").tagging('removeAll', '');
                        $("#inputFocalPointsTags").tagging('removeAll', '');
                        $('#txtfocalPoint').val('');
                        $('#txtSienaReference').val('');
                        $('#cboAutoConfirm').prop('checked', false);
                        $('#importPhotos').val('');
                        $('.range-slider-range').val(defaults.faceDefaultThreshold);
                        $('.range-slider-value').text(defaults.faceDefaultThreshold);
                        $('.uploadProgressDiv').addClass("hidden");
                        removeClass($('.uploadForm')[0], 'hidden');
                        removeClass($('#btnUploadPhotos')[0], 'hidden');
                        removeClass($('.close')[0], 'hidden');

                        for (var i = 0; i < progressBars.length; i++)
                        {
                            progressBars[i].style.width = 0 + "%";
                            progressBars[i].innerHTML = 0 + "%";
                        }
                        $('#lblFileProgress').text('Photos upload progress');
                        $('#lblSubmitMsg').text('Submitting photos request to server, please wait...');
                    });
            })
            .fail(function (data) {
                var errorMessage = '';
                if (data.failed != null) {
                    errorMessage = "\n error:' + data.failed[0].errorMessage";
                }
                showNotification('The images were not submitted, please try again or contact a system administrator' + errorMessage,
                    'error',
                    'topRight');
                $('.uploadProgressDiv').addClass("hidden");
                removeClass($('.uploadForm'), 'hidden');
                removeClass($('#btnUploadPhotos')[0], 'hidden');
                removeClass($('.close')[0], 'hidden');

                for (var i = 0; i < progressBars.length; i++) {
                    progressBars[i].style.width = 0 + "%";
                    progressBars[i].innerHTML = 0 + "%";
                }
            });
    } else {
        showNotification('There are no images to submit, please upload at least one.',
            'warning',
            'topRight');
    }
});

$('#btnSelectAllFaces').click(function () {
    var faces = $('.photo');
    var i, faceId;
    if (hasClass(this.children[0], 'fa-square-o')) {
        faces.not('.face-selected').addClass("face-selected");
        $('.check-hidden').prop('value', true);
        removeClass(this.children[0], 'fa-square-o');
        this.children[0].className += " fa-check-square-o";
        for (i = 0; i < faces.length; i++) {
            faceId = faces[i].getElementsByClassName('check-hidden')[0].dataset.id;
            if (selectedFaces.indexOf(faceId) == -1) {
                selectedFaces.push(faceId);

            }
        }
        faceListViewModel.selectedItemsCount(selectedFaces.length);
    } else {
        faces.removeClass('face-selected');
        removeClass(this.children[0], 'fa-check-square-o');
        this.children[0].className += " fa-square-o";
        $('.check-hidden').prop('value', false);
        for (i = 0; i < faces.length; i++) {
            faceId = faces[i].getElementsByClassName('check-hidden')[0].dataset.id;
            selectedFaces = removeFromStringArray(selectedFaces, faceId);
        }
        faceListViewModel.selectedItemsCount(selectedFaces.length);
    }
    sessionStorage.setItem("selectedFaces", selectedFaces);
});

$('.filterCombo').change(function () {
    if ($('#cboFaceStatus option:selected').val() == 'My Pending') {
        $("#cboFilterUser").val(defaults.Owner.toLowerCase());
        sessionStorage.setItem("owner", defaults.Owner.toLowerCase());
        $("#cboFilterUser").prop('disabled', 'disabled');
    }
    else {
        $("#cboFilterUser").prop('disabled', false);
    }
    refreshFaceListGrid(0);
});

$('#btnExpandFilters').click(function () {
    if ($(this).attr('data-name') == 'show') {
        $('.panel-search').show(500);
        $(this).attr('data-name', 'hide');
        removeClass(this.children[0], 'fa-plus');
        this.children[0].className += " fa-minus";
    }
    else {
        $('.panel-search').hide(500);
        $(this).attr('data-name', 'show');
        removeClass(this.children[0], 'fa-minus');
        this.children[0].className += " fa-plus";
    }
});

$(document).ready(function () {
    defineItemsPerPageDefaultValue();
    var pageSize = $('#cboItemsPerPage option:selected').val();
    var comboStatus = $('#cboFaceStatus option:selected').val();
    var pageIndex = 0;

    var sessionSienaRefs = [];
    if (sessionStorage.getItem('sienaSearchItems') != null) {
        sessionSienaRefs = sessionStorage.getItem('sienaSearchItems').split(',').filter(Boolean);
    }

    var sessionTags = [];
    if (sessionStorage.getItem('tagsSearchItems') != null) {
        sessionTags = sessionStorage.getItem('tagsSearchItems').split(',').filter(Boolean);
    }

    var sessionFocalPoints = [];
    if (sessionStorage.getItem('focalPointsSearchItems') != null) {
        sessionFocalPoints = sessionStorage.getItem('focalPointsSearchItems').split(',').filter(Boolean);
    }

    if (sessionStorage.getItem("pageSize") != null && sessionStorage.getItem("pageSize") != "undefined") {
        pageSize = sessionStorage.getItem("pageSize");
        $('#cboItemsPerPage').val(pageSize);
    }

    if (sessionStorage.getItem("faceStatus") != null && sessionStorage.getItem("faceStatus") != "undefined") {
        comboStatus = sessionStorage.getItem("faceStatus");
        $('#cboFaceStatus').val(comboStatus);
        if (comboStatus == "My Pending") {
            $("#cboFilterUser").val(defaults.Owner.toLowerCase());
            $("#cboFilterUser").prop('disabled', 'disabled');
            sessionStorage.setItem("owner", defaults.Owner.toLowerCase());
        }
        else {
            $("#cboFilterUser").prop('disabled', false);
        }
    }

    if (sessionStorage.getItem("pageIndex") != null && sessionStorage.getItem("pageIndex") != "undefined") {
        pageIndex = sessionStorage.getItem("pageIndex");
    }

    if (sessionStorage.getItem("selectedFaces") != null && sessionStorage.getItem("selectedFaces") != "undefined" && sessionStorage.getItem("selectedFaces") != "") {
        selectedFaces = sessionStorage.getItem("selectedFaces").split(',');
    }
    
    InitiateTagsSearchInputs(sessionTags, sessionSienaRefs, sessionFocalPoints)

    $.when(GetSettings())
      .done(function (data) {
          var settings = data;
          defaults.PossibleMatchTag = settings.autoMatch.tagString;
          defaults.faceMinThreshold = settings.faceQualityThreshold.min;
          defaults.faceMaxThreshold = settings.faceQualityThreshold.max;
          defaults.faceDefaultThreshold = settings.faceQualityThreshold.default;
          setRangeValues();
      });

    $.when(GetUsers())
         .done(function (data) {
             for (var i = 0; i < data.length; i++) {
                 $("#cboFilterUser").append(new Option(data[i], data[i]));
             }

             if (data.indexOf(defaults.Owner.toLowerCase()) == -1)
             {
                 $("#cboFilterUser").append(new Option(defaults.Owner.toLowerCase(), defaults.Owner.toLowerCase()));
             }

             if (comboStatus == "My Pending")
             {
                 $("#cboFilterUser").val(defaults.Owner.toLowerCase());
                 sessionStorage.setItem("owner", defaults.Owner.toLowerCase());
             }
             else if (sessionStorage.getItem("owner") != null && sessionStorage.getItem("owner") != "undefined") {
                 $("#cboFilterUser").val(sessionStorage.getItem("owner"));
             }

             initializeFaceGrid(pageIndex, pageSize, true, comboStatus, sessionTags, sessionSienaRefs, sessionFocalPoints, $('#cboFilterUser').val());
        });
    updateRemoveFiltersBtn(sessionTags.length, sessionSienaRefs.length, sessionFocalPoints.length);
    updateConfirmUnconfirmDisabledStatus($('#cboFaceStatus option:selected').val());
});