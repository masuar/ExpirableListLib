﻿var faceViewModel, neighborsList;
var t, tagBox, s, sienaBox, f, focalPointsBox;

function generateFaceDetailPage(faceId, topN)
{
    generateTopNCombo();
    $.when(GetFaceById(faceId, defaults.Owner))
        .done(function (data) {
            faceViewModel = new FaceViewModel(data);
            if (faceViewModel.confirmed) {
                $('#btnUnconfirmFace').prop('disabled', false);
                $('#btnConfirmFace').prop('disabled', true);
            } else {
                $('#btnUnconfirmFace').prop('disabled', true);
                $('#btnConfirmFace').prop('disabled', false);
            }
            generateNearNeighborsComponent(faceId, topN);
        });
}

function generateNearNeighborsComponent(faceId, topN) {
    $.when(PostRecognizeFaceCommand(faceId, topN))
    .done(function (data) {
            var promises = [];
            neighborsList = [];
            if (data.success[0].evalResults != null) {
                for (var i = 0; i < data.success[0].evalResults.length; i++) {
                    promises.push(getNeighbourDetails(data.success[0].evalResults[i]));
                }
                document.getElementById('btnTopNResults').innerText = ' ' + data.success[0].evalResults.length + ' results displayed';
            }
            $.when.apply($, promises)
                .done(function () {
                    faceViewModel.neighbors = neighborsList.sort(compareFacesGrade);
                    ko.applyBindings(faceViewModel);
                    
                    initializeTags();
                    initializeCarousel();
                    $('.tooltip').tooltipster({
                        theme: 'tooltipster-light',
                        interactive: true
                    });
                    $('.compare-tooltip').tooltipster({
                        theme: 'tooltipster-light',
                        content: 'Loading...',
                        interactive: true,
                        functionBefore: function (origin, continueTooltip) {
                            var item = $('#compare-carousel .owl-item.active #fullImgUrl');
                            var fullUrl = item.data('url');
                            origin.content($('<div class="imgLoader" style="min-width:50px;min-height:50px"><img id="imgCompareFace" class="tooltip-img" onload="resizeTooltip(this)" src="' + fullUrl + '"></div>'));
                        },
                        functionReady: function () {
                            showLoading('.imgLoader');
                        }
                    });



                });
            })
    .fail(function() {
                showNotification('Error while retrieving similar faces', 'error', 'topRight');
            }
    );
}

function resizeTooltip() {
    hideLoading();
    $('.compare-tooltip').tooltipster('reposition');
};

function compareFacesGrade(a, b) {
    var gradeA = a.grade.replace('%', '');
    var gradeB = b.grade.replace('%', '');
    if (parseInt(gradeA) < parseInt(gradeB)) {
        return 1;
    }
    if (parseInt(gradeA) > parseInt(gradeB)) {
        return -1;
    }
    return 0;
}

function getNeighbourDetails(item) {
    var dfd = $.Deferred();
    $.when(GetFaceById(item.targetFaceId, defaults.Owner))
        .done(function(data) {
            if (data != undefined)
            {
                var faceModel = new FaceViewModel(data);
                faceModel.grade = calculateFaceGrade(item.grade);
                neighborsList.push(faceModel);
                dfd.resolve();
            }
        })
        .fail(function () {
            dfd.resolve();
        });
    return dfd.promise();
}

function calculateFaceGrade(grade) {
    //return round((1 - (grade - defaults.GradeMin) / (defaults.GradeMax - defaults.GradeMin)) * 100, 0) + '%';
    var converted = (-1 * grade * grade) + 1.15;

    if (converted < 0) { converted = 0; }
    if (converted > 1) { converted = 1; }
    converted = round((converted * 100), 0);
    return converted  + '%';
}

function initializeCarousel()
{
    var neighborsOwl = $('#neighbors-carousel');
    neighborsOwl.owlCarousel({
        nav: true,
        dots: false,
        loop: false,
        margin: 10,
        items: 1,
        responsive: {
            480: { items: 1 },
            640: { items: 2 },
            768: { items: 3 },
            1200: { items: 4 },
            1600: { items: 7 }
        }
    });

    var compareOwl = $('#compare-carousel');
    compareOwl.owlCarousel({
        nav: true,
        dots: false,
        autoHeight: true,
        loop: true,
        margin: 10,
        items: 1,
        onInitialized: function() { $('#compare-carousel .owl-nav').appendTo('#compare-carousel .owl-stage-outer') }
    });
    compareOwl.on('mousewheel', '.owl-stage', function(e)
    {
        if (e.originalEvent.deltaY > 0) {
            compareOwl.trigger('next.owl');
        }
        else{
            compareOwl.trigger('prev.owl');
        }
        e.preventDefault();
    });
    $('.photo').click(function () {
        $('#compare-carousel').trigger('to.owl.carousel', $('.photo').index(this));
    });
}

function initializeTags()
{
    $(".sienaTagBox").tagging();
    $(".focalPoinTagBox").tagging();
    $('.tooltip').tooltipster({
        theme: 'tooltipster-light',
        contentCloning: true,
            interactive: true
    });
    s = $(".faceSienaTagBox").tagging();
    sienaBox = s[0];
    f = $(".faceFocalPoinTagBox").tagging();
    focalPointsBox = f[0];
    t = $("#tagBox").tagging();
    tagBox = t[0];
    addTags(faceViewModel.tags, faceViewModel.sienaNumbers(), faceViewModel.focalPoints());

}

function addTags(tags, sienaNumbers, focalPoints) {
    var i;
    if (tags != null) {
        for (i = 0; i < tags.length; i++) {
            tagBox.tagging("add", tags[i]);
        }
    }
    if (sienaNumbers != null) {
        for (i = 0; i < sienaNumbers.length; i++) {
            sienaBox.tagging("add", sienaNumbers[i]);
        }
    }
    if (focalPoints != null) {
        for (i = 0; i < focalPoints.length; i++) {
            focalPointsBox.tagging("add", focalPoints[i]);
        }
    }
}

function updateTags(tagClass, tag) {
    if (tagClass == 'tag') {
        var tags = tagBox.tagging('getTags', '');
        applyLoader = false;
        if (faceViewModel.tags == null || tag == null || faceViewModel.tags.toString().toLowerCase().split(',').indexOf(tag.toLowerCase()) == -1) {
            UpdateFaceTags(tags, faceViewModel.id);
            faceViewModel.tags = tags;
        }
    }
    if (tagClass == 'sienaTag') {
        var sienaTags = sienaBox.tagging('getTags', '');
        applyLoader = false;
        if (faceViewModel.sienaNumbers() == null ||  tag == null || faceViewModel.sienaNumbers().toString().toLowerCase().split(',').indexOf(tag.toLowerCase()) == -1) {
            UpdateFaceSienaNumbers(sienaTags, faceViewModel.id);
            faceViewModel.sienaNumbers(sienaTags);
        }
    }
    if (tagClass == 'focalPointTag') {
        var focalPointTags = focalPointsBox.tagging('getTags', '');
        applyLoader = false;
        if (faceViewModel.focalPoints() == null || tag == null || faceViewModel.focalPoints().toString().toLowerCase().split(',').indexOf(tag.toLowerCase()) == -1) {
            UpdateFaceFocalPoints(focalPointTags, faceViewModel.id);
            faceViewModel.focalPoints(focalPointTags);
        }
    }

    $('.tooltip').tooltipster({
        theme: 'tooltipster-light',
        interactive: true
    });
}

function removeTags(tagClass, tag)
{
    updateTags(tagClass, null);
}

$('#btnConfirmFace').click(function () {
    if (!faceViewModel.confirmed) {
    var n = new Noty({
        text: "Are you sure you want to push this face to FRDB?",
        layout: 'center',
        theme: 'relax',
        modal: true,
        buttons: [
            Noty.button('Yes',
                'btn btn-primary margin-r-5',
                function () {
                    n.close();
                    $.when(ConfirmFace(faceViewModel.id))
                        .done(function () {
                            faceViewModel.confirmed = true;
                            $('#btnUnconfirmFace').prop('disabled', false);
                            $('#btnConfirmFace').prop('disabled', true);
                            removeClass($('.circle')[0], 'circle-background-not-confirmed');
                            $('.circle')[0].className += " circle-background-confirmed";
                            showNotification('Face pushed to FRDB', 'success', 'topRight');
                        })
                        .fail(function () {
                                n.close();
                                showNotification('Face not pushed to FRDB an error has occured', 'error', 'topRight');
                            }
                        );
                }),
            Noty.button('No',
                'btn btn-danger',
                function () {
                    n.close();
                })
        ]
    }).show();
    }
    else {
        showNotification('Cannot push a face to FR DB that\'s already pushed', 'warning', 'topRight');
    }
});

$('#btnUnconfirmFace').click(function () {
    if (faceViewModel.confirmed) {
        var n = new Noty({
            text: "Are you sure you want to remove this face from FRDB?",
            layout: 'center',
            theme: 'relax',
            modal: true,
            buttons: [
                Noty.button('Yes',
                    'btn btn-primary margin-r-5',
                    function () {
                        n.close();
                        $.when(UnconfirmFace(faceViewModel.id))
                            .done(function () {
                                faceViewModel.confirmed = false;
                                $('#btnUnconfirmFace').prop('disabled', true);
                                $('#btnConfirmFace').prop('disabled', false);
                                removeClass($('.circle')[0], 'circle-background-confirmed');
                                $('.circle')[0].className += " circle-background-not-confirmed";
                                showNotification('Face removed from FRDB', 'success', 'topRight');
                            })
                            .fail(function () {
                                n.close();
                                showNotification('Face not removed from FRDB an error has occured', 'error', 'topRight');
                            }
                            );
                    }),
                Noty.button('No',
                    'btn btn-danger',
                    function () {
                        n.close();
                    })
            ]
        }).show();
    }
    else {
        showNotification('Cannot remove a face from FRDB that\'s not in the FRDB', 'warning', 'topRight');
    }
});

$('#btnDeleteFace').click(function () {
    var n = new Noty({
        text: "Are you sure you want to delete this face? After this action you will be redirected",
        layout: 'center',
        theme: 'relax',
        modal: true,
        buttons: [
            Noty.button('Yes',
                'btn btn-primary margin-r-5',
                function () {
                    n.close();
                    $.when(DeleteFace(faceViewModel.id))
                        .done(function () {
                            window.location.replace(getAppHostUrl());
                        })
                        .fail(function () {
                                n.close();
                                showNotification('Face not deleted an error has occured', 'error', 'topRight')
                            }
                        );
                }),
            Noty.button('No',
                'btn btn-danger',
                function () {
                    n.close();
                })
        ]
    }).show();
});

function generateTopNCombo()
{
    var combo = document.getElementById("ulTopNOptions");
    var topNOptions = defaults.defaultTopNOptions.split(",");
    for (var i = 0; i < topNOptions.length; i++)
    {
        var li = document.createElement("li");
        var optionLink = document.createElement("a");
        optionLink.appendChild(document.createTextNode("See " + topNOptions[i] + " results"));
        optionLink.setAttribute("class", "topNOption");
        optionLink.setAttribute("data-value", topNOptions[i]);
        li.appendChild(optionLink);
        combo.appendChild(li);
    }


    $(".topNOption").click(function () {
        topN = $(this)[0].dataset.value;
        seeMore(topN);
        self.neighbors
    });
}

function seeMore(howMany) {
    if (window.location.href.indexOf('&topn=') !== -1) {
        window.location.href = window.location.href.replace(/topn=[^&$]*/i, 'topn=' + howMany)
    }
    else {
        window.location.href += '&topn=' + howMany;
    }
}


$(window).load(function () {
    setTimeout(function () {
        var itemHeight = $('#compare-carousel').find('.active').height();
        $('#compare-carousel').find('.owl-stage-outer').height(itemHeight);
    }, 1000);
});

$(document).ready(function () {
    $.when(GetSettings())
     .done(function (data) {
         var settings = data;
         defaults.PossibleMatchTag = settings.autoMatch.tagString;
         defaults.faceMinThreshold = settings.faceQualityThreshold.min;
         defaults.faceMaxThreshold = settings.faceQualityThreshold.max;
         defaults.faceDefaultThreshold = settings.faceQualityThreshold.default;
         defaults.defaultTopNOptions = settings.defaultTopNOptions;
         generateFaceDetailPage(viewBagFaceId, viewBagTopN);
     });
    
});