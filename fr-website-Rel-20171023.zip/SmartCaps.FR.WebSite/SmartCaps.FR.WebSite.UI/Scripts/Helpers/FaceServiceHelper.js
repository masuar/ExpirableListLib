﻿function GetFaceById(faceId, username) {
    var url = defaults.FaceRecognitionService + 'faces/' + faceId;

    return $.ajax({
        type: "GET",
        url: url
    });
}

function PostRecognizeFaceCommand(faceId, topN) {
    var url = defaults.FaceRecognitionService + 'commands/eval/faces/' + faceId + '?topn=' + topN.toString();
    return $.ajax({
        type: "POST",
        url: url
    });
}

function GetRecognizeCommandResult(token) {
    var url = defaults.FaceRecognitionService + 'commands/eval?token=' + token;
    return $.ajax({
        type: "GET",
        url: url
    });
}

function GetFocalPoints() {
    var url = defaults.FaceRecognitionService + 'focalpoints';
    return $.ajax({
        type: "GET",
        url: url
    });
}

function GetTags() {
    var url = defaults.FaceRecognitionService + 'faces/tags';
    return $.ajax({
        type: "GET",
        url: url
    });
}

function GetUsers() {
    var url = defaults.FaceRecognitionService + 'faces/owners';
    return $.ajax({
        type: "GET",
        url: url
    });
}

function GetSienaRefs() {
    var url = defaults.FaceRecognitionService + 'faces/sienarefs';
    return $.ajax({
        type: "GET",
        url: url
    });
}

function GetFaceList(pageIndex, pageSize, withMetada, faceStatus, owner, tags, sienaRefs, focalPoints) {
    var url = defaults.FaceRecognitionService + 'faces?withMetadata=' + withMetada;

    if (pageIndex != null & pageIndex != '') {
        url = url + '&pageIndex=' + pageIndex;
    }

    if (pageSize != null & pageSize != '') {
        url = url + '&pageSize=' + pageSize;
    }

    if (faceStatus != null && faceStatus != '') {
        var ownerFilter = '';
        if (owner != 'All') {
            ownerFilter = '&filter.owner=' + owner;
        }

        if (faceStatus == "Confirmed") {
            url = url + '&filter.confirmed=true';
        }
        else {
            url = url + '&filter.confirmed=false';
        }

        url = url + ownerFilter;
    }
    var i;
    if (focalPoints != null && focalPoints != '') {
        for (i = 0; i < focalPoints.length; i++) {
            url = url + '&filter.focalPoints=' + focalPoints[i];
        }
    }

    if (sienaRefs != null && sienaRefs != '') {
        for (i = 0; i < sienaRefs.length; i++) {
            url = url + '&filter.sienaRefs=' + sienaRefs[i];
        }
    }

    if (tags != null && tags != '') {
        for (i = 0; i < tags.length; i++) {
            url = url + '&filter.tags=' + tags[i];
        }
    }

    return $.ajax({
        type: "GET",
        url: url
    });

}

function UploadVideos(tags, files, autoconfirm, threshold, sienaRefs, focalPoints, username) {
    var formData = new FormData();
    var filesCount = 0;
    var progressBar = document.getElementById("filesProgressBar");
    for (var i = 0; i < files.length; i++) {
        if (files[i].type.substring(0,5) == "video") {
            formData.append(files[i].name, files[i]);
            filesCount++;
        }
    }

    if (filesCount > 0) {
        var serviceUrl = defaults.FaceRecognitionService +
            'commands/enroll/videos?async=true&imageRefType=FILESYS&options.confirm=' + autoconfirm +
            '&options.check=false&options.faceQualityScoreThreshold=' + threshold + '&options.requestedBy=' + username + '&options.metadata=Source system|File system (FACE web site)';
        var i;
        if (focalPoints != null && focalPoints != '') {
            for (i = 0; i < focalPoints.length; i++) {
                serviceUrl = serviceUrl + '&options.focalPoints=' + focalPoints[i];
            }
        }

        if (sienaRefs != null && sienaRefs != '') {
            for (i = 0; i < sienaRefs.length; i++) {
                serviceUrl = serviceUrl + '&options.sienaRefs=' + sienaRefs[i];
            }
        }

        if (tags != null && tags != '') {
            for (i = 0; i < tags.length; i++) {
                serviceUrl = serviceUrl + '&options.tags=' + tags[i];
            }
        }

        return $.ajax({
            xhr: function () {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function (event) {
                    if (event.lengthComputable) {
                        var percentComplete = event.loaded / event.total;
                        percentComplete = parseInt(percentComplete * 100);
                        progressBar.style.width = percentComplete + "%";
                        progressBar.innerHTML = percentComplete * 1 + "%";
                    }
                }, false);

                return xhr;
            },
            type: 'POST',
            url: serviceUrl,
            data: formData,
            contentType: false,
            processData: false,
            cache: false
        });
    }

    progressBar.style.width = 100 + "%";
    progressBar.innerHTML = 100 + "%";
    return false;
    return false;
}

function UploadPhotos(tags, files, autoconfirm, threshold, sienaRefs, focalPoints, username) {
    var formData = new FormData();
    var filesCount = 0;
    var progressBar = document.getElementById("filesProgressBar");
    for (var i = 0; i < files.length; i++) {
        if (files[i].type.substring(0, 5) == "image") {
            formData.append(files[i].name, files[i]);
            filesCount++;
        }
    }

    if (filesCount > 0) {
        var serviceUrl = defaults.FaceRecognitionService +
            'commands/enroll/images?async=false&delayedEval=false&imageRefType=FILESYS&options.confirm=' + autoconfirm +
            '&options.check=false&options.faceQualityScoreThreshold=' + threshold + '&options.requestedBy=' + username + '&options.metadata=Source system|File system (FACE web site)';
        var i;
        if (focalPoints != null && focalPoints != '') {
            for (i = 0; i < focalPoints.length; i++) {
                serviceUrl = serviceUrl + '&options.focalPoints=' + encodeURIComponent(focalPoints[i]);
            }
        }

        if (sienaRefs != null && sienaRefs != '') {
            for (i = 0; i < sienaRefs.length; i++) {
                serviceUrl = serviceUrl + '&options.sienaRefs=' + encodeURIComponent(sienaRefs[i]);
            }
        }

        if (tags != null && tags != '') {
            for (i = 0; i < tags.length; i++) {
                serviceUrl = serviceUrl + '&options.tags=' + encodeURIComponent(tags[i]);
            }
        }

        return $.ajax({
            xhr: function () {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function (event) {
                    if (event.lengthComputable) {
                        var percentComplete = event.loaded / event.total;
                        percentComplete = parseInt(percentComplete * 100);
                        progressBar.style.width = percentComplete + "%";
                        progressBar.innerHTML = percentComplete * 1 + "%";
                    }
                }, false);

                return xhr;
            },
            type: 'POST',
            url: serviceUrl,
            data: formData,
            contentType: false,
            processData: false
        });
    }

    progressBar.style.width = 100 + "%";
    progressBar.innerHTML = 100 + "%";
    return false;
}

function ConfirmFace(id) {
    var url = defaults.FaceRecognitionService + 'faces';
    var faceListJson = [];
    var jsonObj = {
        id: id,
        confirmed: true
    };
    faceListJson.push(jsonObj);
    return $.ajax({
        type: "PATCH",
        url: url,
        data: JSON.stringify(faceListJson),
        contentType: "application/json"
    });
}

function UpdateFaceTags(tags, id) {
    var url = defaults.FaceRecognitionService + 'faces';
    var faceListJson = [];
    var jsonObj = {
        id: id,
        tags: tags
    };
    faceListJson.push(jsonObj);
    return $.ajax({
        type: "PATCH",
        url: url,
        data: JSON.stringify(faceListJson),
        contentType: "application/json"
    });
}

function UpdateFaceSienaNumbers(sienaNumbers, id) {
    var url = defaults.FaceRecognitionService + 'faces';
    var faceListJson = [];
    var jsonObj = {
        id: id,
        sienaRefs: sienaNumbers
    };
    faceListJson.push(jsonObj);
    return $.ajax({
        type: "PATCH",
        url: url,
        data: JSON.stringify(faceListJson),
        contentType: "application/json"
    });
}

function UpdateFaceFocalPoints(focalPoints, id) {
    var url = defaults.FaceRecognitionService + 'faces';
    var faceListJson = [];
    var jsonObj = {
        id: id,
        focalPoints: focalPoints
    };
    faceListJson.push(jsonObj);
    return $.ajax({
        type: "PATCH",
        url: url,
        data: JSON.stringify(faceListJson),
        contentType: "application/json"
    });
}

function UnconfirmFace(id) {
    var url = defaults.FaceRecognitionService + 'faces';
    var faceListJson = [];
    var jsonObj = {
        id: id,
        confirmed: false
    };
    faceListJson.push(jsonObj);
    return $.ajax({
        type: "PATCH",
        url: url,
        data: JSON.stringify(faceListJson),
        contentType: "application/json"
    });
}

function DeleteFace(id) {
    var url = defaults.FaceRecognitionService + 'faces/' + id;
    return $.ajax({
        type: "DELETE",
        url: url
    });
}

function DeleteFaces(ids) {
    var url = defaults.FaceRecognitionService + 'faces/';
    return $.ajax({
        type: "DELETE",
        url: url,
        data: JSON.stringify(ids),
        contentType: "application/json"
    });
}

function GetApiStatus() {
    var url = defaults.FaceRecognitionService + 'Status';
    return $.ajax({
        type: "GET",
        url: url
    });
}

function PatchFaces(faces) {
    var url = defaults.FaceRecognitionService + 'faces';
    return $.ajax({
        type: "PATCH",
        url: url,
        data: JSON.stringify(faces),
        contentType: "application/json"

    });
}

function GetSettings() {
    var url = defaults.FaceRecognitionService + 'settings';
    return $.ajax({
        type: "GET",
        url: url
    });
}