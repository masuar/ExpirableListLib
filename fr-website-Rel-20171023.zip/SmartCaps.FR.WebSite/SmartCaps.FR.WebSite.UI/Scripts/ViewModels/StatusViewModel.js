﻿StatusViewModel = function (model) {
    var self = this;
    self.ActiveMQImplementation = model ? model.ActiveMQImplementation : null;
    self.FRWebApiVersion = model ? model.FRWebApiVersion : null;
    self.FRCommonLibVersion = model ? model.FRLibVersion : null;
    self.MsgLibVersion = model ? model.MsgLibVersion : null;
    self.FaceEngineStatus = model ? model.FaceEngine : null;
    self.KnnEngineStatus = model ? model.KnnEngine : null;
    self.DbUpdaterStatus = model ? model.DbUpdater : null;
    self.ServiceStatus = model ? model.Service : null;
    self.Message = model ? model.Message : null;
    self.FRWebApiRelease = model ? model.FRWebApiRelease : null;
    self.VideoEngine = model ? model.VideoEngine : null;
}
