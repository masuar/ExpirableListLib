﻿var FaceListViewModel = function (model) {
    var self = this;
    self.faces = ko.observableArray((model.data) ?
                ko.utils.arrayMap(model.data,
                function (item) {
                    var faceViewModel = new FaceViewModel(item);
                    return faceViewModel;
                })
                : null);
    self.totalPages = model.totalPages;
    self.currentPage = ko.observable(model.currentPage + 1);
    self.pageSize = model.page_size;
    self.totalItems = ko.observable(model.totalItems ? model.totalItems : 0);
    self.nextPageUrl = ko.observable(model.nextPageLink);
    self.previousPageUrl = ko.observable(model.prevPageLink);
    self.loadPage = function(pageNum) {
        refreshFaceListGrid(pageNum - 1);
    };
    self.loadPage2 = function () {
        refreshFaceListGrid();
    }
    self.selectedItemsCount = ko.observable(0);
    self.itemsSummary = ko.computed(function () {
        if (self.selectedItemsCount() >= 0 || self.totalItems() >= 0 || self.faces().length >= 0)
        {
            return self.faces().length + " of " + self.totalItems() + " items, " + self.selectedItemsCount() + " selected";
        }
    });
};
