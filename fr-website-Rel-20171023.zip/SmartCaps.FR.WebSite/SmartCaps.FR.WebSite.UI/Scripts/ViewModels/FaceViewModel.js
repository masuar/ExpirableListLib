﻿FaceViewModel = function (model) {
    var self = this;
    self.id = model ? model.id : null;
    self.grade = null;
    self.tags = model ? model.tags : null;
    self.confirmed = model ? model.confirmed : null;
    self.owner = model ? model.owner : null;
    self.insertedOn = model ? new Date(model.insertedOn).toLocaleString("en-GB") : null;
    self.imageUrl = model ? model.links.image.href : null;
    self.fullImageUrl = model ? model.links.fullImage.href : null;
    self.metadata = new ko.observableDictionary(model ? model.metadata : null);
    self.possibleMatch = ko.computed(function () {
        if (defaults.PossibleMatchTag == null || !(self.tags != null && self.tags.toString().toLowerCase().indexOf(defaults.PossibleMatchTag.toString().toLowerCase()) > -1)) {
            return "hidden";
        }

        return "";
    });
    self.confirmedCss = ko.computed(function () {
        if (self.grade != null && self.grade != '') {
            return "hidden";
        }
        if (self.confirmed != null && self.confirmed) {
            return "circle-background-confirmed";
        }

        return "circle-background-not-confirmed";
    });
    self.neighbors = ko.observableArray(model ? model.neighbors : null);
    self.focalPoints = ko.observableArray(model ? model.focalPoints : null);
    self.sienaNumbers = ko.observableArray(model ? model.sienaRefs : null);
    self.firstSienaNumber = ko.computed(function () {
        if (self.sienaNumbers() != null) {
            if (self.sienaNumbers().length == 1) {
                return self.sienaNumbers()[0];
            }
            if (self.sienaNumbers().length > 1) {
                return self.sienaNumbers()[0] + ' <i class="fa fa-plus-circle"></i>';
            }
        }

        return "";
    });
    self.firstFocalPoint = ko.computed(function () {
        if (self.focalPoints() != null) {
            if (self.focalPoints().length == 1) {
                return self.focalPoints()[0];
            }
            if (self.focalPoints().length > 1) {
                return self.focalPoints()[0] + ' <i class="fa fa-plus-circle"></i>';
            }
        }
        return "";
    });
}
