﻿using log4net;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using static System.Net.WebRequestMethods;

namespace SmartCaps.FR.WebSite.UI.Controllers
{
    public class ProxyController : ApiController
    {
        private readonly Uri redirectionServer;
        private readonly string mediaType = "application/json";
        private ILog log;
        private string basicAuthUser;
        private string basicAuthPwd;

        public ProxyController(string redirectToUrl, string basicAuthUser, string basicAuthPwd, ILog log)
        {
            this.redirectionServer = new Uri(redirectToUrl);
            this.basicAuthUser = basicAuthUser;
            this.basicAuthPwd = basicAuthPwd;
            this.log = log;
        }

        [AcceptVerbs(Http.Get, Http.Head, Http.Post, Http.Put, "PATCH", "DELETE")]
        public HttpResponseMessage Proxy(string url)
        {
            try
            {
                using (var handler = new HttpClientHandler() { UseDefaultCredentials = true, ClientCertificateOptions = ClientCertificateOption.Automatic })
                using (HttpClient client = new HttpClient(handler))
                {
                    client.Timeout = TimeSpan.FromMinutes(10);
                    var userPwString = string.Format("{0}:{1}", this.basicAuthUser, this.basicAuthPwd);
                    var userPwArray = Encoding.ASCII.GetBytes(userPwString);

                    string authString = Convert.ToBase64String(userPwArray);
                    client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", authString);

                    Uri redirectionUri = new Uri(this.redirectionServer, url + this.Request.RequestUri.Query);
                    this.log.DebugFormat("Old Url: '{0}' Redirection Url: '{1}' Auth string: '{2}'", this.Request.RequestUri, redirectionUri, authString);

                    var clone = CloneHttpRequestMessageAsync(this.Request, redirectionUri).Result;

                    clone.RequestUri = redirectionUri;

                    if (clone.Method == HttpMethod.Get)
                    {
                        clone.Content = null;
                    }
                    this.log.DebugFormat("About to make the forward to {0}...", this.Request.RequestUri);
                    var result = client.SendAsync(clone).Result;

                    // Substitute the href results
                    if (result.Content.Headers.ContentType.MediaType == this.mediaType)
                    {
                        string json = result.Content.ReadAsStringAsync().Result;

                        string modifiedJson = json.Replace(this.redirectionServer.ToString(), Url.Content("~/proxy/"));
                        result.Content = new StringContent(modifiedJson, Encoding.UTF8, this.mediaType);
                    }
                    return result;
                }
            }
            catch (Exception ex)
            {
                this.log.Error("Error while redirecting API call.", ex);
                return new HttpResponseMessage(HttpStatusCode.InternalServerError);
            }

        }

        public static async Task<HttpRequestMessage> CloneHttpRequestMessageAsync(HttpRequestMessage req, Uri theNewUri)
        {
            HttpRequestMessage clone = new HttpRequestMessage(req.Method, theNewUri);

            // Copy the request's content (via a MemoryStream) into the cloned object 
            var ms = new MemoryStream();

            if (req.Content != null)
            {
                await req.Content.CopyToAsync(ms).ConfigureAwait(false); ms.Position = 0; clone.Content = new StreamContent(ms);

                // Copy the content headers
                if (req.Content.Headers != null)
                    foreach (var h in req.Content.Headers)
                        clone.Content.Headers.Add(h.Key, h.Value);
            }

            clone.Version = req.Version;

            foreach (KeyValuePair<string, object> prop in req.Properties)
                clone.Properties.Add(prop);

            return clone;
        }

    }
}