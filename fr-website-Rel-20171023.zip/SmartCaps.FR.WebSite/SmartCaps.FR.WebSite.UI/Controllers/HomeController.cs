﻿using System.Reflection;
using System.Web.Mvc;

namespace SmartCaps.FR.WebSite.UI.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult FaceDetails(string faceid, int? topN)
        {
            if (topN == null)
            {
                topN = 10;
            }

            this.ViewData["TopN"] = topN;
            this.ViewData["FaceId"] = faceid;
            return View();
        }
        
        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        // GET: About
        public ActionResult About()
        {
            ViewBag.WebAssemblyVersion = Assembly.GetExecutingAssembly().GetName().Version.ToString();
            return View();
        }

        [AllowAnonymous]
        public ActionResult IAmAlive()
        {
            return View();
        }
    }
}