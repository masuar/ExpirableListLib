﻿using log4net;
using System.Configuration;
using System.Web.Http;
using System.Web.Http.Dispatcher;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace SmartCaps.FR.WebSite.UI
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            var log = LogManager.GetLogger("SmartCaps.FR.WebSite.UI");
            log4net.Config.XmlConfigurator.Configure();

            string appVersion = typeof(Controllers.HomeController).Assembly.GetName().Version.ToString();
            string baseUrl = ConfigurationManager.AppSettings["FaceRecognitionService"];


            log.InfoFormat("SmartCaps.FR.WebSite.UI started! Version '{0}'. Face recognition server: '{1}'", appVersion, baseUrl);
            GlobalConfiguration.Configuration.Services.Replace(typeof(IHttpControllerActivator), new App_Start.CompositionRoot(baseUrl, log));

            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
        
        protected void Application_PreSendRequestHeader()
        {
            Response.Headers.Remove("Server");
        }
    }
}
