﻿using log4net;
using SmartCaps.FR.WebSite.UI.Controllers;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Dispatcher;

namespace SmartCaps.FR.WebSite.UI.App_Start
{
    public class CompositionRoot : IHttpControllerActivator
    {
        private readonly string baseUrl;
        private ILog log; 

        public CompositionRoot(string baseUrl, ILog log)
        {
            this.baseUrl = baseUrl;
            this.log = log;
        }

        public IHttpController Create(HttpRequestMessage request, HttpControllerDescriptor controllerDescriptor, Type controllerType)
        {
            ApiController controller = null;

            if (controllerType == typeof(ProxyController))
            {
                string basicAuthUser = ConfigurationManager.AppSettings["ApiUser"];
                string basicAuthPwd = ConfigurationManager.AppSettings["ApiPwd"];
                controller = new ProxyController(this.baseUrl, basicAuthUser, basicAuthPwd, this.log);
            }

            return controller;
        }
    }
}