﻿using SmartCaps.FR.WebSite.UI.App_Start;
using System.Web.Mvc;

namespace SmartCaps.FR.WebSite.UI
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
