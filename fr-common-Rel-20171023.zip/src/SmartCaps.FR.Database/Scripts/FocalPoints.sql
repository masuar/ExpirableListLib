﻿IF (SELECT COUNT(*) FROM dbo.FocalPoint) = 0
BEGIN

	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Apate FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Asset Recovery FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Cannabis FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Check The Web FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Checkpoint FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Cola FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Copper FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Copy FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Cyborg FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Dolphin FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'EEOC FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Firearms FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'FrontOffice DB'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Furtum FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'GNST FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Heroin FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Hydra FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'ITOC FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Maritime Piracy FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Monitor FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'MTIC FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Non Focal Point'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Phoenix FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Smoke FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Soya FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Sports Corruption FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'SusTrans FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Synergy FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Terminal FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'TFTP FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Travellers FP'); 
	INSERT INTO dbo.FocalPoints (Name) VALUES (N'Twins FP');

END