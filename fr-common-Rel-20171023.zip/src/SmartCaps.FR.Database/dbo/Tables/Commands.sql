﻿CREATE TABLE [dbo].[Commands](
	[Token] [nvarchar](50) NOT NULL,
	[CommandType] [nvarchar](512) NOT NULL,
	[CreatedBy] [nvarchar](255) NULL,
	[CreatedOn] [datetime] NOT NULL,
	[LastUpdatedBy] [nvarchar](255) NULL,
	[LastUpdatedOn] [datetime] NOT NULL,
	[TotalSteps] [int] NOT NULL,
	[LastStepCompleted] [int] NOT NULL,
	[TopN] [int] NULL,
	[Autoconfirm] [bit] NOT NULL,
	[Tags] [nvarchar](max) NULL,
	[SienaRefs] [nvarchar](max) NULL,
	[FocalPoints] [nvarchar](max) NULL,
	[FaceQualityScoreThreshold] [float] NOT NULL DEFAULT 0,
	[ErrorMessage] [nvarchar](255) NULL,
 [CommandObj] NVARCHAR(MAX) NULL, 
    CONSTRAINT [PK_Commands] PRIMARY KEY CLUSTERED 
(
	[Token] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Commands] ADD  CONSTRAINT [DF_Commands_Autoconfirm]  DEFAULT ((0)) FOR [Autoconfirm]
GO

CREATE INDEX [IX_LastUpdatedOn] ON [dbo].[Commands] ([LastUpdatedOn])
