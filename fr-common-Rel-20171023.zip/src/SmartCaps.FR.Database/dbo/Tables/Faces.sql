﻿CREATE TABLE [dbo].[Faces](
	[FaceId] [nvarchar](255) NOT NULL,
	[ImageRefType] [nvarchar](50) NOT NULL,
	[ImageId] [nvarchar](255) NOT NULL,
	[BoundTop] [int] NOT NULL,
	[BoundLeft] [int] NOT NULL,
	[BoundDown] [int] NOT NULL,
	[BoundRight] [int] NOT NULL,
	[Owner] [nvarchar](50) NULL,
	[InsertedOn] [datetime] NULL,
	[LastUpdatedOn] [datetime] NULL,
	[Features] [nvarchar](max) NOT NULL,
	[Confirmed] [bit] NOT NULL,
	[Tags] [nvarchar](max) NULL,
	[SienaRefs] [nvarchar](max) NULL,
	[FocalPoints] [nvarchar](max) NULL,
	[QualityScore] [float] NOT NULL DEFAULT 0,
     [Evaluated] BIT NOT NULL DEFAULT 1, 
    [SoftDeleted] BIT NOT NULL DEFAULT 0, 
    CONSTRAINT [PK_Faces] PRIMARY KEY CLUSTERED 
(
	[FaceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO
ALTER TABLE [dbo].[Faces] ADD  CONSTRAINT [DF_Faces_Confirmed]  DEFAULT ((0)) FOR [Confirmed]
GO
create NONCLUSTERED index IX_LastUpdatedOn
	ON dbo.Faces (LastUpdatedOn)
GO