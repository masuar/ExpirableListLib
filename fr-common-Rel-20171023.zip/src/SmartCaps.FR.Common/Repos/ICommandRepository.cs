﻿using SmartCaps.FR.Common.Model.Commands;
using System.Collections.Generic;

namespace SmartCaps.FR.Common.Repos
{
    public interface ICommandRepository
    {
        ICommand GetCommandByToken(string token);

        bool DeleteCommandByToken(string token);

        IEnumerable<string> DeleteOldCommands(int daysOlder, bool deleteErrorCmds);

        bool DoesCommandExist(string token);

        void InsertOrUpdateCommand(ICommand cmd);

    }
}
