﻿using SmartCaps.FR.Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Repos
{
    public interface IFocalPointRepository 
    {
        IEnumerable<string> GetFocalPoints();
    }
}
