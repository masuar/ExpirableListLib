﻿using System;
using System.Collections.Generic;
using System.Linq;
using SmartCaps.FR.Common.Model;
using log4net;
using System.Data.SqlClient;
using System.Data;

namespace SmartCaps.FR.Common.Repos.SQLServer
{
    public class SQLServerFaceRepository : IFaceRepository
    {
        private ILog log;
        private readonly string connectionString;
        private readonly int commandsTimeOut;
        private readonly SQLServerFactory factory = new SQLServerFactory();

        public SQLServerFaceRepository(string connectionString, int commandsTimeOut, ILog log)
        {
            this.log = log;
            this.commandsTimeOut = commandsTimeOut;
            this.connectionString = connectionString;
        }

        public IEnumerable<Face> GetFaces(int pageIndex, int pageSize, bool includeFeatures)
        {
            return this.GetFaces(pageIndex, pageSize, includeFeatures, evaluated: true);
        }

        #region publicMethdos       

        public IEnumerable<Face> GetFaces(IDictionary<ImageRef, IDictionary<string, string>> imagesWithMetadata, string owner, IEnumerable<string> tags, IEnumerable<string> sienaRefs, IEnumerable<string> focalPoints, bool? confirmed, bool includeFeatures, int pageIndex, int pageSize)
        {
            IList<Face> result = new List<Face>();
            string whereWord = string.Empty;
            string imagesFilter = string.Empty;
            string ownerFilter = string.Empty;
            string confFilter = string.Empty;
            List<SqlParameter> parameters = new List<SqlParameter>();
            string getAllFacesSqlCmd = "SELECT * FROM dbo.Faces WHERE SoftDeleted = 0 {0} ORDER BY LastUpdatedOn DESC OFFSET(@PageIndex * @PageSize) ROWS FETCH NEXT @PageSize ROWS ONLY";

            if (imagesWithMetadata != null && imagesWithMetadata.Any())
            {
                int c = 0;
                parameters.AddRange(imagesWithMetadata.Keys.Select(i => new SqlParameter("@img" + c++, i.RefType.ToString() + "|" + i.Id)).ToList());
                imagesFilter = "ImageRefType + '|' + ImageId IN (" + string.Join(",", parameters.Select(p => p.ParameterName)) + ")";
            }

            if (owner != null)
            {
                var ownerParam = new SqlParameter("@owner", owner);
                parameters.Add(ownerParam);
                ownerFilter = "Owner = @owner";
            }

            string tagsFilter = GetTagsFilter(tags, ref parameters);

            string sienaRefsFilter = GetSienaRefsFilter(sienaRefs, ref parameters);

            string focalPointsFilter = GetFocalPointsFilter(focalPoints, ref parameters);

            if (confirmed != null)
            {
                int v = (bool)confirmed ? 1 : 0;
                var confParam = new SqlParameter("@conf", v);
                parameters.Add(confParam);
                confFilter = "Confirmed = @conf";
            }

            var evalParam = new SqlParameter("@eval", 1);
            parameters.Add(evalParam);
            string evalFilter = "Evaluated = @eval";

            var filters = string.Join(" AND ", (new string[] { imagesFilter, ownerFilter, tagsFilter, sienaRefsFilter, focalPointsFilter, confFilter, evalFilter }).Where(f => !string.IsNullOrEmpty(f)));
            if (!string.IsNullOrEmpty(filters))
            {
                filters = "AND " + filters;
            }

            getAllFacesSqlCmd = string.Format(getAllFacesSqlCmd, filters);

            parameters.Add(new SqlParameter("@PageIndex", pageIndex));
            parameters.Add(new SqlParameter("@PageSize", pageSize));


            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(getAllFacesSqlCmd, conn))
                {
                    theCommand.CommandTimeout = this.commandsTimeOut;
                    theCommand.Parameters.AddRange(parameters.ToArray());
                    using (SqlDataReader reader = theCommand.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Face theFace = this.factory.CreateCompleteFaceFromDataReader(reader, includeFeatures);
                            if (imagesWithMetadata != null && imagesWithMetadata.ContainsKey(theFace.ImageRef))
                            {
                                theFace.Metadata = imagesWithMetadata[theFace.ImageRef];
                            }

                            result.Add(theFace);
                        }
                    }
                }
            }

            return result;

        }

        public int GetFacesCount()
        {
            return this.GetFacesCount(evaluated: true);
        }

        public int GetFacesCount(IEnumerable<ImageRef> images, string owner, IEnumerable<string> tags, IEnumerable<string> sienaRefs, IEnumerable<string> focalPoints, bool? confirmed)
        {
            int result = 0;

            string whereWord = string.Empty;
            string imagesFilter = string.Empty;
            string ownerFilter = string.Empty;
            string confFilter = string.Empty;

            List<SqlParameter> parameters = new List<SqlParameter>();
            string getAllFacesSqlCmd = "SELECT count(*) FROM dbo.Faces WHERE SoftDeleted = 0 {0}";

            if (images != null && images.Any())
            {
                int c = 0;
                parameters.AddRange(images.Select(i => new SqlParameter("@img" + c++, i.RefType.ToString() + "|" + i.Id)).ToList());
                imagesFilter = "ImageRefType + '|' + ImageId IN (" + string.Join(",", parameters.Select(p => p.ParameterName)) + ")";
            }

            if (owner != null)
            {
                var ownerParam = new SqlParameter("@owner", owner);
                parameters.Add(ownerParam);
                ownerFilter = "Owner = @owner";
            }


            string tagsFilter = GetTagsFilter(tags, ref parameters);

            string sienaRefsFilter = GetSienaRefsFilter(sienaRefs, ref parameters);

            string focalPointsFilter = GetFocalPointsFilter(focalPoints, ref parameters);

            if (confirmed != null)
            {
                int v = (bool)confirmed ? 1 : 0;
                var confParam = new SqlParameter("@conf", v);
                parameters.Add(confParam);
                confFilter = "Confirmed = @conf";
            }

            var evalParam = new SqlParameter("@eval", 1);
            parameters.Add(evalParam);
            string evalFilter = "Evaluated = @eval";

            var filters = string.Join(" AND ", (new string[] { imagesFilter, ownerFilter, tagsFilter, sienaRefsFilter, focalPointsFilter, confFilter, evalFilter }).Where(f => !string.IsNullOrEmpty(f)));
            if (!string.IsNullOrEmpty(filters))
            {
                filters = "AND " + filters;
            }

            getAllFacesSqlCmd = string.Format(getAllFacesSqlCmd, filters);


            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(getAllFacesSqlCmd, conn))
                {
                    theCommand.CommandTimeout = this.commandsTimeOut;
                    theCommand.Parameters.AddRange(parameters.ToArray());
                    result = (int)theCommand.ExecuteScalar();
                }
            }

            return result;
        }

        public AddFacesResult AddFaces(IEnumerable<Face> faces)
        {
            AddFacesResult result = new AddFacesResult();
            string addFaceSqlCmd = "INSERT INTO dbo.Faces (FaceId, ImageRefType, ImageId, BoundTop, BoundLeft, BoundDown, BoundRight, Features, Owner, InsertedOn, LastUpdatedOn, Confirmed, Tags, SienaRefs, FocalPoints, QualityScore, Evaluated) VALUES (@Id, @ImageRefType, @ImageId, @BoundTop, @BoundLeft, @BoundDown, @BoundRight, @Features, @Owner, @InsertedOn, @LastUpdatedOn, @Confirmed, @Tags, @SienaRefs, @FocalPoints, @QualityScore, @Evaluated);";

            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                var trans = conn.BeginTransaction();

                using (SqlCommand theCommand = new SqlCommand(addFaceSqlCmd, conn, trans))
                {
                    theCommand.Parameters.Add("@Id", SqlDbType.NVarChar, 255);
                    theCommand.Parameters.Add("@ImageRefType", SqlDbType.NVarChar, 50);
                    theCommand.Parameters.Add("@ImageId", SqlDbType.NVarChar, 255);
                    theCommand.Parameters.Add("@BoundTop", SqlDbType.Int);
                    theCommand.Parameters.Add("@BoundLeft", SqlDbType.Int);
                    theCommand.Parameters.Add("@BoundDown", SqlDbType.Int);
                    theCommand.Parameters.Add("@BoundRight", SqlDbType.Int);
                    theCommand.Parameters.Add("@Features", SqlDbType.NVarChar);
                    theCommand.Parameters.Add("@Owner", SqlDbType.NVarChar, 50);
                    theCommand.Parameters.Add("@InsertedOn", SqlDbType.DateTime);
                    theCommand.Parameters.Add("@LastUpdatedOn", SqlDbType.DateTime);
                    theCommand.Parameters.Add("@Confirmed", SqlDbType.Bit);
                    theCommand.Parameters.Add("@Tags", SqlDbType.NVarChar);
                    theCommand.Parameters.Add("@SienaRefs", SqlDbType.NVarChar);
                    theCommand.Parameters.Add("@FocalPoints", SqlDbType.NVarChar);
                    theCommand.Parameters.Add("@QualityScore", SqlDbType.Float);
                    theCommand.Parameters.Add("@Evaluated", SqlDbType.Bit);

                    foreach (Face face in faces)
                    {
                        var existing = this.GetFaceById(face.Id, includeFeatures: false, includeSoftDeleted: true);
                        if (existing != null)
                        {
                            if (!existing.SoftDeleted)
                            {
                                result.AlreadyExistingFaces.Add(existing);
                            }

                            face.SoftDeleted = false;
                            this.UpdateFace(face, existing);
                        }
                        else
                        {
                            theCommand.Parameters["@Id"].Value = face.Id;
                            theCommand.Parameters["@ImageRefType"].Value = face.ImageRef.RefType.ToString();
                            theCommand.Parameters["@ImageId"].Value = face.ImageRef.Id;
                            theCommand.Parameters["@BoundTop"].Value = face.BoundingBox.TopLeft.X;
                            theCommand.Parameters["@BoundLeft"].Value = face.BoundingBox.TopLeft.Y;
                            theCommand.Parameters["@BoundDown"].Value = face.BoundingBox.DownRight.X;
                            theCommand.Parameters["@BoundRight"].Value = face.BoundingBox.DownRight.Y;
                            theCommand.Parameters["@Features"].Value = string.Join(",", face.Features);
                            theCommand.Parameters["@Owner"].Value = face.Owner;
                            theCommand.Parameters["@InsertedOn"].Value = face.InsertedOn;
                            theCommand.Parameters["@LastUpdatedOn"].Value = face.LastUpdatedOn;
                            theCommand.Parameters["@Confirmed"].Value = face.Confirmed ? 1 : 0;
                            theCommand.Parameters["@QualityScore"].Value = face.QualityScore;
                            theCommand.Parameters["@Evaluated"].Value = face.Evaluated ? 1 : 0;

                            if (face.Tags != null)
                            {
                                theCommand.Parameters["@Tags"].Value = string.Join(",", face.Tags);
                            }
                            else
                            {
                                theCommand.Parameters["@Tags"].Value = string.Empty;
                            }

                            if (face.SienaRefs != null)
                            {
                                theCommand.Parameters["@SienaRefs"].Value = string.Join(",", face.SienaRefs);
                            }
                            else
                            {
                                theCommand.Parameters["@SienaRefs"].Value = string.Empty;
                            }

                            if (face.FocalPoints != null)
                            {
                                theCommand.Parameters["@FocalPoints"].Value = string.Join(",", face.FocalPoints);
                            }
                            else
                            {
                                theCommand.Parameters["@FocalPoints"].Value = string.Empty;
                            }

                            theCommand.ExecuteNonQuery();
                            result.AddedFaces.Add(face);
                        }
                    }

                    trans.Commit();
                }
            }

            return result;
        }

        public Face GetFaceById(string id)
        {
            return this.GetFaceById(id, includeFeatures: true);
        }

        public Face GetFaceById(string id, bool includeFeatures)
        {
            return this.GetFaceById(id, includeFeatures, false);
        }

        //public bool IsFaceExisting(string id)
        //{
        //    int howMany = 0;
        //    string getFaceSqlCmd = "SELECT count(*) FROM dbo.Faces WHERE FaceId = @Id;";

        //    using (SqlConnection conn = new SqlConnection(this.connectionString))
        //    {
        //        conn.Open();
        //        using (SqlCommand theCommand = new SqlCommand(getFaceSqlCmd, conn))
        //        {
        //            theCommand.Parameters.Add("@Id", SqlDbType.NVarChar, 255);
        //            theCommand.Parameters["@Id"].Value = id;

        //            howMany = (int)theCommand.ExecuteScalar();
        //        }
        //    }

        //    return howMany > 0;
        //}

        public bool RemoveFaceById(string id)
        {
            int rowsAffected = 0;
            string removeFaceSqlCmd = "UPDATE dbo.Faces SET SoftDeleted = 1 WHERE FaceId = @Id;";

            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(removeFaceSqlCmd, conn))
                {
                    theCommand.Parameters.Add("@Id", SqlDbType.NVarChar, 255);
                    theCommand.Parameters["@Id"].Value = id;

                    rowsAffected = theCommand.ExecuteNonQuery();
                }
            }
            this.log.WarnFormat("{0} face/s with Id '{1}' has been soft deleted.", rowsAffected, id);

            return rowsAffected > 0;
        }

        public bool SetFaceOwner(string id, string owner)
        {
            bool result = false;

            string updateFaceSqlCmd = "UPDATE dbo.Faces SET Owner = @owner, LastUpdatedOn = @LastUpdatedOn WHERE FaceId = @id;";
            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(updateFaceSqlCmd, conn))
                {
                    theCommand.Parameters.Add("@id", SqlDbType.NVarChar, 50).Value = id;
                    theCommand.Parameters.Add("@owner", SqlDbType.NVarChar, 50).Value = owner;
                    theCommand.Parameters.Add("@LastUpdatedOn", SqlDbType.DateTime).Value = DateTime.UtcNow;

                    int affected = theCommand.ExecuteNonQuery();
                    result = affected > 0;
                }
            }

            return result;
        }

        public bool SetFaceConfirmation(string id, bool confirmation)
        {
            bool result = false;

            string updateFaceSqlCmd = "UPDATE dbo.Faces SET Confirmed = @Confirmed, LastUpdatedOn = @LastUpdatedOn WHERE FaceId = @id;";
            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(updateFaceSqlCmd, conn))
                {
                    theCommand.Parameters.Add("@id", SqlDbType.NVarChar, 50).Value = id;
                    theCommand.Parameters.Add("@Confirmed", SqlDbType.Bit).Value = confirmation ? 1 : 0;
                    theCommand.Parameters.Add("@LastUpdatedOn", SqlDbType.DateTime).Value = DateTime.UtcNow;

                    int affected = theCommand.ExecuteNonQuery();
                    result = affected > 0;
                }
            }

            return result;
        }

        public bool SetFaceTags(string id, IList<string> tags)
        {
            bool result = false;
            if (tags != null)
            {
                string updateFaceSqlCmd = "UPDATE dbo.Faces SET Tags = @Tags, LastUpdatedOn = @LastUpdatedOn WHERE FaceId = @id;";
                using (SqlConnection conn = new SqlConnection(this.connectionString))
                {
                    conn.Open();
                    using (SqlCommand theCommand = new SqlCommand(updateFaceSqlCmd, conn))
                    {
                        theCommand.Parameters.Add("@id", SqlDbType.NVarChar, 50).Value = id;
                        theCommand.Parameters.Add("@Tags", SqlDbType.NVarChar).Value = string.Join(",", tags.Distinct());
                        theCommand.Parameters.Add("@LastUpdatedOn", SqlDbType.DateTime).Value = DateTime.UtcNow;

                        int affected = theCommand.ExecuteNonQuery();
                        result = affected > 0;
                    }
                }
            }

            return result;
        }

        public bool SetFaceSienaRefs(string id, IList<string> sienaRefs)
        {
            bool result = false;
            if (sienaRefs != null)
            {
                string updateFaceSqlCmd = "UPDATE dbo.Faces SET SienaRefs = @SienaRefs, LastUpdatedOn = @LastUpdatedOn WHERE FaceId = @id;";
                using (SqlConnection conn = new SqlConnection(this.connectionString))
                {
                    conn.Open();
                    using (SqlCommand theCommand = new SqlCommand(updateFaceSqlCmd, conn))
                    {
                        theCommand.Parameters.Add("@id", SqlDbType.NVarChar, 50).Value = id;
                        theCommand.Parameters.Add("@SienaRefs", SqlDbType.NVarChar).Value = string.Join(",", sienaRefs.Distinct());
                        theCommand.Parameters.Add("@LastUpdatedOn", SqlDbType.DateTime).Value = DateTime.UtcNow;

                        int affected = theCommand.ExecuteNonQuery();
                        result = affected > 0;
                    }
                }
            }

            return result;
        }

        public bool SetFaceFocalPoints(string id, IList<string> focalPoints)
        {
            bool result = false;
            if (focalPoints != null)
            {
                string updateFaceSqlCmd = "UPDATE dbo.Faces SET FocalPoints = @FocalPoints, LastUpdatedOn = @LastUpdatedOn WHERE FaceId = @id;";
                using (SqlConnection conn = new SqlConnection(this.connectionString))
                {
                    conn.Open();
                    using (SqlCommand theCommand = new SqlCommand(updateFaceSqlCmd, conn))
                    {
                        theCommand.Parameters.Add("@id", SqlDbType.NVarChar, 50).Value = id;
                        theCommand.Parameters.Add("@FocalPoints", SqlDbType.NVarChar).Value = string.Join(",", focalPoints.Distinct());
                        theCommand.Parameters.Add("@LastUpdatedOn", SqlDbType.DateTime).Value = DateTime.UtcNow;

                        int affected = theCommand.ExecuteNonQuery();
                        result = affected > 0;
                    }
                }
            }

            return result;
        }

        public bool UpdateFace(Face newFace, Face oldFace)
        {
            int rowsAffected = 0;
            string removeFaceSqlCmd = @"UPDATE dbo.Faces  
                                        SET 
                                        [SoftDeleted] = @SoftDeleted,
                                        [LastUpdatedOn] = @LastUpdatedOn,
                                        [Confirmed] = @Confirmed,
                                        [Tags] = @Tags,
                                        [SienaRefs] = @SienaRefs,
                                        [FocalPoints] = @FocalPoints,
                                        [Owner] = @Owner
                                        WHERE [FaceId] = @Id;";
            var tagList = newFace.Tags == null ? new List<string>() : newFace.Tags.ToList();
            tagList.AddRange(oldFace.Tags ?? new List<string>());
            var mergedTags = tagList.Distinct().ToList();
            var sienaList = newFace.SienaRefs == null ? new List<string>() : newFace.SienaRefs.ToList();
            sienaList.AddRange(oldFace.SienaRefs ?? new List<string>());
            var mergedSienaRefs = sienaList.Distinct().ToList();
            var focalPointsList = newFace.FocalPoints == null ? new List<string>() : newFace.FocalPoints.ToList();
            focalPointsList.AddRange(oldFace.FocalPoints ?? new List<string>());
            var mergedFocalPoints = focalPointsList.Distinct().ToList();

            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(removeFaceSqlCmd, conn))
                {
                    theCommand.Parameters.Add("@Id", SqlDbType.NVarChar, 50);
                    theCommand.Parameters.Add("@SoftDeleted", SqlDbType.Bit);
                    theCommand.Parameters.Add("@LastUpdatedOn", SqlDbType.DateTime);
                    theCommand.Parameters.Add("@Confirmed", SqlDbType.Bit);
                    theCommand.Parameters.Add("@Tags", SqlDbType.NVarChar);
                    theCommand.Parameters.Add("@SienaRefs", SqlDbType.NVarChar);
                    theCommand.Parameters.Add("@FocalPoints", SqlDbType.NVarChar);
                    theCommand.Parameters.Add("@Owner", SqlDbType.NVarChar, 50);
                    theCommand.Parameters["@Id"].Value = newFace.Id;
                    theCommand.Parameters["@Tags"].Value = string.Join(",", mergedTags);
                    theCommand.Parameters["@SienaRefs"].Value = string.Join(",", mergedSienaRefs);
                    theCommand.Parameters["@FocalPoints"].Value = string.Join(",", mergedFocalPoints);

                    theCommand.Parameters["@SoftDeleted"].Value = newFace.SoftDeleted;
                    theCommand.Parameters["@LastUpdatedOn"].Value = DateTime.UtcNow;
                    theCommand.Parameters["@Confirmed"].Value = newFace.Confirmed;
                    if (oldFace.SoftDeleted)
                    {
                        theCommand.Parameters["@Owner"].Value = newFace.Owner;
                    }
                    else
                    {
                        theCommand.Parameters["@Owner"].Value = oldFace.Owner;
                    }

                    rowsAffected = theCommand.ExecuteNonQuery();
                }
            }
            this.log.WarnFormat("{0} face with Id '{1}' was updated.", rowsAffected, newFace.Id);

            return rowsAffected > 0;
        }

        private Face GetFaceById(string id, bool includeFeatures, bool includeSoftDeleted)
        {
            Face result = null;
            string getFaceSqlCmd = "SELECT * FROM dbo.Faces WHERE FaceId = @Id";
            if (!includeSoftDeleted)
            {
                getFaceSqlCmd = string.Concat(getFaceSqlCmd, " AND SoftDeleted = 0");
            }

            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(getFaceSqlCmd, conn))
                {
                    theCommand.Parameters.Add("@Id", SqlDbType.NVarChar, 255);
                    theCommand.Parameters["@Id"].Value = id;

                    using (SqlDataReader reader = theCommand.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            result = this.factory.CreateCompleteFaceFromDataReader(reader, includeFeatures);
                        }
                    }
                }
            }

            return result;
        }

        public bool SetFaceEvaluation(string id, bool evaluation)
        {
            bool result = false;

            string updateFaceSqlCmd = "UPDATE dbo.Faces SET Evaluated = @Evaluated, LastUpdatedOn = @LastUpdatedOn WHERE FaceId = @id;";
            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(updateFaceSqlCmd, conn))
                {
                    theCommand.Parameters.Add("@id", SqlDbType.NVarChar, 50).Value = id;
                    theCommand.Parameters.Add("@Evaluated", SqlDbType.Bit).Value = evaluation ? 1 : 0;
                    theCommand.Parameters.Add("@LastUpdatedOn", SqlDbType.DateTime).Value = DateTime.UtcNow;

                    int affected = theCommand.ExecuteNonQuery();
                    result = affected > 0;
                }
            }

            return result;

        }

        public IEnumerable<Face> GetNotEvaluatedFaces(int pageIndex, int pageSize, bool includeFeatures)
        {
            return this.GetFaces(pageIndex, pageSize, includeFeatures, evaluated: false);
        }

        public int GetNotEvaluatedFacesCount()
        {
            return this.GetFacesCount(evaluated: false);
        }

        public IEnumerable<string> GetSienaRefsFromFaces()
        {
            var result = new List<string>();

            string getFocalPointsSqlCmd = @"select SienaRefs from Faces
                                            where SienaRefs <> ''
                                            Group by SienaRefs";
            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(getFocalPointsSqlCmd, conn))
                {
                    using (SqlDataReader reader = theCommand.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(reader.GetString(0));
                        }
                    }
                }
            }

            result = string.Join(",", result.ToArray()).Split(',').Distinct().ToList();
            return result;
        }

        public IEnumerable<string> GetTagsFromFaces()
        {
            var result = new List<string>();

            string getFocalPointsSqlCmd = @"select Tags from Faces
                                            where Tags <> '' and SoftDeleted = 0 
                                            Group by Tags";
            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(getFocalPointsSqlCmd, conn))
                {
                    using (SqlDataReader reader = theCommand.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(reader.GetString(0));
                        }
                    }
                }
            }

            result = string.Join(",", result.ToArray()).Split(',').Distinct().ToList();
            return result;
        }

        public IEnumerable<string> GetOwnersFromFaces()
        {
            var result = new List<string>();

            string getFocalPointsSqlCmd = @"select Owner from Faces
                                                where Owner <> '' and SoftDeleted = 0 
                                                Group by Owner";
            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(getFocalPointsSqlCmd, conn))
                {
                    using (SqlDataReader reader = theCommand.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(reader.GetString(0).ToLower());
                        }
                    }
                }
            }

            return result;
        }

        #endregion

        #region privateMethods

        private static string GetFocalPointsFilter(IEnumerable<string> focalPoints, ref List<SqlParameter> parameters)
        {
            var focalPointsFilter = string.Empty;
            if (focalPoints != null && focalPoints.Any())
            {
                int j = 0;
                var focalPointsParams =
                    focalPoints.Select(fp => new SqlParameter("@focalPoints" + j++, string.Format("%{0}%", fp))).ToList();
                focalPointsFilter = "(" +
                                    string.Join(" AND ",
                                        focalPointsParams.Select(tp => string.Format("FocalPoints LIKE {0}", tp.ParameterName))) +
                                    ")";
                parameters.AddRange(focalPointsParams);
            }

            return focalPointsFilter;
        }

        private static string GetSienaRefsFilter(IEnumerable<string> sienaRefs, ref List<SqlParameter> parameters)
        {
            var sienaRefsFilter = string.Empty;
            if (sienaRefs != null && sienaRefs.Any())
            {
                int j = 0;
                var sienaRefsParams =
                    sienaRefs.Select(sn => new SqlParameter("@sienaRefs" + j++, string.Format("%{0}%", sn))).ToList();
                sienaRefsFilter = "(" +
                                     string.Join(" AND ",
                                         sienaRefsParams.Select(tp => string.Format("SienaRefs LIKE {0}", tp.ParameterName))) +
                                     ")";
                parameters.AddRange(sienaRefsParams);
            }

            return sienaRefsFilter;
        }

        private static string GetTagsFilter(IEnumerable<string> tags, ref List<SqlParameter> parameters)
        {
            var tagsFilter = string.Empty;
            if (tags != null && tags.Count() > 0)
            {
                int j = 0;
                var tagParams = tags.Select(t => new SqlParameter("@tag" + j++, string.Format("%{0}%", t))).ToList();
                tagsFilter = "(" + string.Join(" AND ", tagParams.Select(tp => string.Format("Tags LIKE {0}", tp.ParameterName))) +
                             ")";
                parameters.AddRange(tagParams);
            }

            return tagsFilter;
        }

        private double[] GetDoubleArrayFromString(string str)
        {
            string[] strItems = str.Split(new string[] { "," }, StringSplitOptions.None);
            double[] result = new double[strItems.Length];
            for (int i = 0; i < strItems.Length; i++)
            {
                double parsedValue;
                result[i] = double.TryParse(strItems[i], out parsedValue) ? parsedValue : 0;
            }

            return result;
        }

        private int GetFacesCount(bool evaluated)
        {
            int result = 0;

            string getFacesCountSqlCmd = "SELECT count(*) FROM dbo.Faces WHERE Evaluated = @Evaluated AND SoftDeleted = 0";

            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(getFacesCountSqlCmd, conn))
                {
                    theCommand.CommandTimeout = this.commandsTimeOut;
                    theCommand.Parameters.Add("@Evaluated", SqlDbType.Bit).Value = evaluated ? 1 : 0;
                    result = (int)theCommand.ExecuteScalar();
                }
            }

            return result;
        }

        private IEnumerable<Face> GetFaces(int pageIndex, int pageSize, bool includeFeatures, bool evaluated)
        {
            this.log.DebugFormat("Getting faces (pageIndex={0}, pageSize={1}, includeFeatures={2}, evaluated={3})...", pageIndex, pageSize, includeFeatures, evaluated);
            IList<Face> result = new List<Face>();

            string getAllFacesSqlCmd = "SELECT * FROM dbo.Faces WHERE Evaluated = @Evaluated AND SoftDeleted = 0 ORDER BY LastUpdatedOn DESC OFFSET(@PageIndex * @PageSize) ROWS FETCH NEXT @PageSize ROWS ONLY";

            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(getAllFacesSqlCmd, conn))
                {
                    theCommand.CommandTimeout = this.commandsTimeOut;
                    theCommand.Parameters.Add("@Evaluated", SqlDbType.Bit).Value = evaluated ? 1 : 0;
                    theCommand.Parameters.Add("@PageIndex", SqlDbType.Int).Value = pageIndex;
                    theCommand.Parameters.Add("@PageSize", SqlDbType.Int).Value = pageSize;
                    using (SqlDataReader reader = theCommand.ExecuteReader())
                    {
                        int i = 0;
                        while (reader.Read())
                        {
                            Face face = this.factory.CreateCompleteFaceFromDataReader(reader, includeFeatures);
                            result.Add(face);
                            this.log.DebugFormat("Face {0} read and composed successfully.", i++);
                        }
                    }

                }
            }

            this.log.DebugFormat("{0} faces got.", result.Count);

            return result;
        }
        #endregion
    }
}
