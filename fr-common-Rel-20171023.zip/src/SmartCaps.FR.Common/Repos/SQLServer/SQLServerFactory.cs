﻿using SmartCaps.FR.Common.Model;
using SmartCaps.FR.Common.Model.Commands;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Repos.SQLServer
{
    internal class SQLServerFactory
    {
        public EnrollAndEvalImageCommand CreateEnrollAndEvalImageCommandFromDataReader(IDataReader dr)
        {
            EnrollAndEvalImageCommand cmd = null;
            bool moreRows = true;
            if (moreRows)
            {
                cmd = new EnrollAndEvalImageCommand(dr.GetSafeString("Token"));

                this.SetBasicCommandPropertiesFromDataReader(cmd, dr);
                this.SetEvalCommandPropertiesFromDataReader(cmd, dr);
                this.SetFacesCommandPropertiesFromDataReader(cmd, dr);
                this.AddFacesAndResultsToCommandFromDataReader(cmd, dr);
            }
            return cmd;
        }

        public EvalImageCommand CreateEvalImageCommandFromDataReader(IDataReader dr)
        {
            EvalImageCommand cmd = null;
            bool moreRows = true;
            if (moreRows)
            {
                cmd = new EvalImageCommand(dr.GetSafeString("Token"));

                this.SetBasicCommandPropertiesFromDataReader(cmd, dr);
                this.SetEvalCommandPropertiesFromDataReader(cmd, dr);
                this.SetFacesCommandPropertiesFromDataReader(cmd, dr);
                this.AddFacesAndResultsToCommandFromDataReader(cmd, dr);
            }
            return cmd;
        }

        public EnrollImageCommand CreateEnrollImageCommandFromDataReader(IDataReader dr)
        {
            EnrollImageCommand cmd = null;
            bool moreRows = true;
            if (moreRows)
            {
                cmd = new EnrollImageCommand(dr.GetSafeString("Token"));

                this.SetBasicCommandPropertiesFromDataReader(cmd, dr);
                this.SetFacesCommandPropertiesFromDataReader(cmd, dr);
                this.AddFacesToCommandFromDataReader(cmd, dr);
            }
            return cmd;
        }

        public BatchEnrollImageCommand CreateBatchEnrollImageCommandFromDataReader(IDataReader dr)
        {
            BatchEnrollImageCommand cmd = null;
            bool moreRows = true;
            if (moreRows)
            {
                cmd = new BatchEnrollImageCommand(dr.GetSafeString("Token"));

                this.SetBasicCommandPropertiesFromDataReader(cmd, dr);
                this.SetFacesCommandPropertiesFromDataReader(cmd, dr);
                this.AddFacesToCommandFromDataReader(cmd, dr);
            }
            return cmd;
        }

        public EnrollImagesFromVideoCommand CreateEnrollImagesFromVideoCommandFromDataReader(IDataReader dr)
        {
            EnrollImagesFromVideoCommand cmd = null;
            bool moreRows = true;
            if (moreRows)
            {
                cmd = new EnrollImagesFromVideoCommand(dr.GetSafeString("Token"));

                this.SetBasicCommandPropertiesFromDataReader(cmd, dr);
                this.SetFacesCommandPropertiesFromDataReader(cmd, dr);
                this.AddFacesToCommandFromDataReader(cmd, dr);
            }
            return cmd;
        }

        public RemoveFacesCommand CreateRemoveFacesCommandFromDataReader(IDataReader dr)
        {
            RemoveFacesCommand cmd = null;
            bool moreRows = true;
            if (moreRows)
            {
                cmd = new RemoveFacesCommand(dr.GetSafeString("Token"));

                this.SetBasicCommandPropertiesFromDataReader(cmd, dr);
                this.AddFacesToCommandFromDataReader(cmd, dr);
            }
            return cmd;
        }

        public StatusCommand CreateStatusCommandFromDataReader(IDataReader dr)
        {
            var cmd = new StatusCommand(dr.GetSafeString("Token"));
            this.SetBasicCommandPropertiesFromDataReader(cmd, dr);

            return cmd;
        }

        public Face CreateFaceFromDataReader(IDataReader dr, bool includeFeatures)
        {
            var face = new Face();
            face.Id = dr.GetSafeString("FaceId");

            int x1 = dr.GetSafeInt("BoundTop");
            int y1 = dr.GetSafeInt("BoundLeft");
            int x2 = dr.GetSafeInt("BoundDown");
            int y2 = dr.GetSafeInt("BoundRight");

            face.BoundingBox = new BoundingBox() { TopLeft = new Coord(x1, y1), DownRight = new Coord(x2, y2) };
            face.ImageRef = this.GetImageRefFromDataReader(dr);

            face.QualityScore = dr.GetSafeDouble("QualityScore");

            if (dr.ColumnExists("Confirmed")) // This is the same as asking: Is this dr from a face or from a faceInCommand?
            {
                face.Confirmed = dr.GetSafeBool("Confirmed");
                face.Evaluated = dr.GetSafeBool("Evaluated");
                face.SoftDeleted = dr.GetSafeBool("SoftDeleted");
                string tags = dr.GetSafeString("Tags");
                if (!string.IsNullOrEmpty(tags))
                {
                    face.Tags = new List<string>(tags.Split(','));
                }

                string sienas = dr.GetSafeString("SienaRefs");
                if (!string.IsNullOrEmpty(sienas))
                {
                    face.SienaRefs = new List<string>(sienas.Split(','));
                }

                string focalPoints = dr.GetSafeString("FocalPoints");
                if (!string.IsNullOrEmpty(focalPoints))
                {
                    face.FocalPoints = new List<string>(focalPoints.Split(','));
                }
            }

            if (includeFeatures)
            {
                face.Features = this.GetDoubleArrayFromString(dr.GetSafeString("Features"));
            }

            return face;
        }

        public Face CreateCompleteFaceFromDataReader(IDataReader dr, bool includeFeatures)
        {
            var face = this.CreateFaceFromDataReader(dr, includeFeatures);

            face.Owner = dr.GetSafeString("Owner");
            face.InsertedOn = dr.GetSafeDateTime("InsertedOn");
            face.LastUpdatedOn = dr.GetSafeDateTime("LastUpdatedOn");

            return face;
        }

        public FaceInCommand CreateFaceInCommandFromDataReader(IDataReader dr)
        {
            var face = this.CreateFaceFromDataReader(dr, includeFeatures: false);

            FaceInCommand result = new FaceInCommand(face);
            result.AlreadyExisting = dr.GetSafeBool("AlreadyExisting");

            return result;
        }

        private void AddResultsToCommandFromDataReader(IEvalCommand cmd, IDataReader dr)
        {
            bool moreRows = true;
            bool moreNeighbors = true;
            do
            {
                FaceNeighbor fn = new FaceNeighbor();
                fn.SourceFaceId = dr.GetSafeString("SourceFaceId");
                fn.TargetFaceId = dr.GetSafeString("TargetFaceId");
                fn.Grade = dr.GetSafeDouble("Grade");

                if (!string.IsNullOrEmpty(fn.SourceFaceId))
                {
                    cmd.Neighbors.Add(fn);
                }

                moreRows = dr.Read();
                if (moreRows && (string.IsNullOrEmpty(fn.SourceFaceId) || fn.SourceFaceId != dr.GetSafeString("SourceFaceId")))
                {
                    moreNeighbors = false;
                }
            }
            while (moreRows && moreNeighbors);
        }

        private void AddFacesToCommandFromDataReader(IFacesCommand cmd, IDataReader dr)
        {
            bool moreFaces = false;
            bool moreRows = true;
            do
            {
                FaceInCommand face = this.CreateFaceInCommandFromDataReader(dr);
                if (!string.IsNullOrEmpty(face.Id))
                {
                    cmd.Faces.Add(face);
                }

                moreRows = dr.Read();
                if (moreRows && (!string.IsNullOrEmpty(face.Id) && face.Id != dr.GetSafeString("FaceId")))
                {
                    moreFaces = true;
                }
            }
            while (moreRows && moreFaces);
        }

        private void AddFacesAndResultsToCommandFromDataReader(EvalImageCommand cmd, IDataReader dr)
        {
            bool moreFaces = false;
            bool moreRows = true;
            do
            {
                FaceInCommand face = this.CreateFaceInCommandFromDataReader(dr);
                if (!string.IsNullOrEmpty(face.Id) && !cmd.Faces.Any(f => f.Id == face.Id))
                {
                    cmd.Faces.Add(face);
                }

                bool moreNeighbors = true;
                do
                {
                    FaceNeighbor fn = new FaceNeighbor();
                    fn.SourceFaceId = dr.GetSafeString("SourceFaceId");
                    fn.TargetFaceId = dr.GetSafeString("TargetFaceId");
                    fn.Grade = dr.GetSafeDouble("Grade");

                    if (!string.IsNullOrEmpty(fn.SourceFaceId))
                    {
                        cmd.Neighbors.Add(fn);
                    }

                    moreRows = dr.Read();
                    if (moreRows && (string.IsNullOrEmpty(fn.SourceFaceId) || fn.SourceFaceId != dr.GetSafeString("SourceFaceId")))
                    {
                        moreNeighbors = false;
                    }
                }
                while (moreRows && moreNeighbors);

                if (moreRows && (!string.IsNullOrEmpty(face.Id) && face.Id != dr.GetSafeString("FaceId")))
                {
                    moreFaces = true;
                }
            }
            while (moreRows && moreFaces);
        }

        private void SetBasicCommandPropertiesFromDataReader(ICommand cmd, IDataReader dr)
        {
            cmd.CreatedBy = dr.GetSafeString("CreatedBy");
            cmd.CreatedOn = dr.GetSafeDateTime("CreatedOn");
            cmd.LastUpdatedBy = dr.GetSafeString("LastUpdatedBy");
            cmd.LastUpdatedOn = dr.GetSafeDateTime("LastUpdatedOn");
            cmd.TotalSteps = dr.GetSafeInt("TotalSteps");
            cmd.LastStepCompleted = dr.GetSafeInt("LastStepCompleted");
            cmd.ErrorMessage = dr.GetSafeString("ErrorMessage");
        }

        private void SetEvalCommandPropertiesFromDataReader(IEvalCommand cmd, IDataReader dr)
        {
            cmd.TopN = dr.GetSafeInt("TopN");
        }

        private void SetFacesCommandPropertiesFromDataReader(IFacesCommand cmd, IDataReader dr)
        {
            ImageRef imageRef = this.GetImageRefFromDataReader(dr);

            cmd.ImageRef.RefType = imageRef.RefType;
            cmd.ImageRef.Id = imageRef.Id;

            cmd.FaceQualityScoreThreshold = dr.GetSafeDouble("FaceQualityScoreThreshold");
        }

        private ImageRef GetImageRefFromDataReader(IDataReader dr)
        {
            ImageRef imageRef = new Model.ImageRef();

            imageRef.RefType = (ImageRefTypes)Enum.Parse(typeof(ImageRefTypes), string.IsNullOrEmpty(dr.GetSafeString("ImageRefType")) ? "NONE" : dr.GetSafeString("ImageRefType"));
            imageRef.Id = dr.GetSafeString("ImageId");

            return imageRef;
        }

        private double[] GetDoubleArrayFromString(string str)
        {
            string[] strItems = str.Split(new string[] { "," }, StringSplitOptions.None);
            double[] result = new double[strItems.Length];
            for (int i = 0; i < strItems.Length; i++)
            {
                double parsedValue;
                result[i] = double.TryParse(strItems[i], out parsedValue) ? parsedValue : 0;
            }

            return result;
        }
    }

    internal static class DataReaderExtensions
    {
        public static string GetSafeString(this IDataReader dr, string fieldName)
        {
            string result = null;
            int index = dr.GetOrdinal(fieldName);

            if (!dr.IsDBNull(index))
            {
                result = dr.GetString(index);
            }

            return result;
        }

        public static bool GetSafeBool(this IDataReader dr, string fieldName)
        {
            bool result = false;

            int index = dr.GetOrdinal(fieldName);

            if (!dr.IsDBNull(index))
            {
                result = dr.GetBoolean(index);
            }

            return result;
        }

        public static DateTime GetSafeDateTime(this IDataReader dr, string fieldName)
        {
            DateTime result = new DateTime(1970, 1, 1);
            int index = dr.GetOrdinal(fieldName);

            if (!dr.IsDBNull(index))
            {
                result = DateTime.SpecifyKind(dr.GetDateTime(index), DateTimeKind.Utc);
            }

            return result;
        }

        public static int GetSafeInt(this IDataReader dr, string fieldName)
        {
            int result = 0;
            int index = dr.GetOrdinal(fieldName);

            if (!dr.IsDBNull(index))
            {
                result = dr.GetInt32(index);
            }

            return result;
        }

        public static double GetSafeDouble(this IDataReader dr, string fieldName)
        {
            double result = 0d;
            int index = dr.GetOrdinal(fieldName);

            if (!dr.IsDBNull(index))
            {
                result = dr.GetDouble(index);
            }

            return result;
        }

        public static bool ColumnExists(this IDataReader dr, string fieldName)
        {
            for (int i = 0; i < dr.FieldCount; i++)
            {
                if (dr.GetName(i).Equals(fieldName, StringComparison.InvariantCultureIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }
    }


}