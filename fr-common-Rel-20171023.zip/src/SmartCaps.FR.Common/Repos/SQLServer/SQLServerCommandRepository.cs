﻿using System;
using System.Collections.Generic;
using SmartCaps.FR.Common.Model.Commands;
using log4net;
using System.Data.SqlClient;
using System.Data;
using SmartCaps.FR.Common.Model;
using Newtonsoft.Json;

namespace SmartCaps.FR.Common.Repos.SQLServer
{
    public class SQLServerCommandRepository : ICommandRepository
    {
        private ILog log;
        private string connectionString;
        private SQLServerFactory factory = new SQLServerFactory();
        private readonly int commandsTimeout;

        public SQLServerCommandRepository(string connectionString, int commandsTimeout, ILog log)
        {
            this.log = log;
            this.commandsTimeout = commandsTimeout;
            this.connectionString = connectionString;
        }

        public bool DoesCommandExist(string token)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                var trans = conn.BeginTransaction();
                result = this.DoesCommandExist(conn, trans, token);
                trans.Commit();
            }

            return result;
        }

        public ICommand GetCommandByToken(string token)
        {
            ICommand result = null;
            string getCmdSqlCmd = "SELECT CommandType, CommandObj FROM [dbo].[Commands] WHERE Token = @Token;";
            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(getCmdSqlCmd, conn))
                {
                    theCommand.CommandTimeout = this.commandsTimeout;
                    theCommand.Parameters.Add("@Token", SqlDbType.NVarChar, 50).Value = token;
                    using (SqlDataReader dr = theCommand.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            string cmdTypeName = dr.GetSafeString("CommandType");
                            string serializedObj = dr.GetSafeString("CommandObj");
                            try
                            {
                                Type cmdType = Type.GetType(cmdTypeName);
                                result = (ICommand)JsonConvert.DeserializeObject(serializedObj, cmdType);
                            }
                            catch(Exception ex)
                            {
                                this.log.Error(string.Format("Unable to deserialize command '{0}' of type '{1}'. Serialized string is '{2}'", token, cmdTypeName, serializedObj), ex);
                            }
                        }
                    }
                }
            }

            return result;
        }

        public bool DeleteCommandByToken(string token)
        {
            bool hasBeenDeleted = false;
            string delCmdSqlCmd = "DELETE FROM dbo.Commands WHERE Token = @Token;"; // CASCADE ON!
            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(delCmdSqlCmd, conn))
                {
                    theCommand.CommandTimeout = this.commandsTimeout;
                    theCommand.Parameters.Add("@Token", SqlDbType.NVarChar, 50).Value = token;
                    hasBeenDeleted = (int)theCommand.ExecuteNonQuery() > 0;
                }
            }

            return hasBeenDeleted;
        }

        public IEnumerable<string> DeleteOldCommands(int daysOlder, bool deleteErrorCmds)
        {
            IList<string> removedTokens = new List<string>();

            string getCmdSqlCmd = "SELECT Token FROM [dbo].[Commands] WHERE DATEDIFF(day, LastUpdatedOn, GETDATE()) > @DaysOlder{0};";
            string delCmdSqlCmd = "DELETE FROM [dbo].[Commands] WHERE DATEDIFF(day, LastUpdatedOn, GETDATE()) > @DaysOlder{0};";

            if (deleteErrorCmds)
            {
                getCmdSqlCmd = string.Format(getCmdSqlCmd, string.Empty);
                delCmdSqlCmd = string.Format(delCmdSqlCmd, string.Empty);
            }
            else
            {
                getCmdSqlCmd = string.Format(getCmdSqlCmd, " AND TotalSteps = LastStepCompleted");
                delCmdSqlCmd = string.Format(delCmdSqlCmd, " AND TotalSteps = LastStepCompleted");
            }

            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                using (SqlCommand theSelectCommand = new SqlCommand(getCmdSqlCmd, conn))
                {
                    theSelectCommand.CommandTimeout = this.commandsTimeout;
                    theSelectCommand.Parameters.Add("@DaysOlder", SqlDbType.Int).Value = daysOlder;
                    using (var dr = theSelectCommand.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            removedTokens.Add((string)dr["Token"]);
                        }
                    }
                }

                using (SqlCommand theDeleteCommand = new SqlCommand(delCmdSqlCmd, conn))
                {
                    theDeleteCommand.CommandTimeout = this.commandsTimeout;
                    theDeleteCommand.Parameters.Add("@DaysOlder", SqlDbType.Int).Value = daysOlder;
                    int deleteCount = theDeleteCommand.ExecuteNonQuery();
                }

            }

            return removedTokens;
        }

        public void InsertOrUpdateCommand(ICommand cmd)
        {
            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                var trans = conn.BeginTransaction();

                try
                {
                    this.InsertOrUpdateCommand(conn, trans, cmd);
                    trans.Commit();
                }
                catch (Exception ex)
                {
                    this.log.Error(string.Format("An error ocurred while inserting or updating the command '{0}'.", cmd.Token), ex);
                    this.log.Warn("Rollbacking the transaction...");
                    try
                    {
                        trans.Rollback();
                    }
                    catch (Exception rollbackEx)
                    {
                        this.log.Error("Rollback exception!", rollbackEx);
                    }
                }
            }
        }

        private bool DoesCommandExist(SqlConnection conn, SqlTransaction trans, string token)
        {
            bool result = false;

            string getCmdSqlCmd = "SELECT count(*) FROM dbo.Commands WHERE Token = @Token;";
            using (SqlCommand theCommand = new SqlCommand(getCmdSqlCmd, conn, trans))
            {
                theCommand.CommandTimeout = this.commandsTimeout;
                theCommand.Parameters.Add("@Token", SqlDbType.NVarChar, 50).Value = token;
                result = (int)theCommand.ExecuteScalar() > 0;
            }

            return result;
        }

        private void InsertOrUpdateCommand(SqlConnection conn, SqlTransaction trans, ICommand cmd)
        {
            string serializedCmd = JsonConvert.SerializeObject(cmd);
            if (!this.DoesCommandExist(conn, trans, cmd.Token))
            {
                string addCmdSqlCmd = "INSERT INTO dbo.Commands (Token, CommandType, CreatedBy, CreatedOn, LastUpdatedBy, LastUpdatedOn, TotalSteps, LastStepCompleted, CommandObj) VALUES (@Token, @CommandType, @CreatedBy, @CreatedOn, @LastUpdatedBy, @LastUpdatedOn, @TotalSteps, @LastStepCompleted, @CommandObj);";

                using (SqlCommand theCommand = new SqlCommand(addCmdSqlCmd, conn, trans))
                {
                    theCommand.CommandTimeout = this.commandsTimeout;

                    theCommand.Parameters.Add("@Token", SqlDbType.NVarChar, 50).Value = cmd.Token;
                    theCommand.Parameters.Add("@CommandType", SqlDbType.NVarChar, 512).Value = cmd.GetType().AssemblyQualifiedName;
                    theCommand.Parameters.Add("@CreatedBy", SqlDbType.NVarChar, 255).Value = this.GetSafeString(cmd.CreatedBy);
                    theCommand.Parameters.Add("@CreatedOn", SqlDbType.DateTime).Value = this.GetSafeDate(cmd.CreatedOn);
                    theCommand.Parameters.Add("@LastUpdatedBy", SqlDbType.NVarChar, 255).Value = this.GetSafeString(cmd.LastUpdatedBy);
                    theCommand.Parameters.Add("@LastUpdatedOn", SqlDbType.DateTime).Value = this.GetSafeDate(cmd.LastUpdatedOn);
                    theCommand.Parameters.Add("@TotalSteps", SqlDbType.Int).Value = cmd.TotalSteps;
                    theCommand.Parameters.Add("@LastStepCompleted", SqlDbType.Int).Value = cmd.LastStepCompleted;
                    theCommand.Parameters.Add("@ErrorMessage", SqlDbType.NVarChar).Value = this.GetSafeString(cmd.ErrorMessage);
                    theCommand.Parameters.Add("@CommandObj", SqlDbType.NVarChar).Value = serializedCmd;

                    theCommand.ExecuteNonQuery();
                }
            }
            else
            {
                string updateCmdSqlCmd = "UPDATE dbo.Commands SET LastUpdatedBy = @LastUpdatedBy, LastUpdatedOn = @LastUpdatedOn, LastStepCompleted = @LastStepCompleted, ErrorMessage = @ErrorMessage, CommandObj = @CommandObj WHERE Token = @Token;";
                using (SqlCommand theCommand = new SqlCommand(updateCmdSqlCmd, conn, trans))
                {
                    theCommand.CommandTimeout = this.commandsTimeout;

                    theCommand.Parameters.Add("@Token", SqlDbType.NVarChar, 50).Value = cmd.Token;
                    theCommand.Parameters.Add("@LastUpdatedBy", SqlDbType.NVarChar, 255).Value = this.GetSafeString(cmd.LastUpdatedBy);
                    theCommand.Parameters.Add("@LastUpdatedOn", SqlDbType.DateTime).Value = this.GetSafeDate(cmd.LastUpdatedOn);
                    theCommand.Parameters.Add("@LastStepCompleted", SqlDbType.Int).Value = cmd.LastStepCompleted;
                    theCommand.Parameters.Add("@ErrorMessage", SqlDbType.NVarChar, 255).Value = this.GetSafeString(cmd.ErrorMessage);
                    theCommand.Parameters.Add("@CommandObj", SqlDbType.NVarChar).Value = serializedCmd;

                    theCommand.ExecuteNonQuery();
                }
            }
        }

        private DateTime GetSafeDate(DateTime dt)
        {
            DateTime result = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);

            if (dt.ToUniversalTime() > result)
            {
                result = dt.ToUniversalTime();
            }

            return result;
        }

        private object GetSafeString(string value)
        {
            object result = DBNull.Value;
            if (!string.IsNullOrEmpty(value))
            {
                result = value;
            }
            return result;
        }

    }
}
