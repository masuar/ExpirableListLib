﻿using log4net;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Repos.SQLServer
{
    public class SQLServerFocalPointRepository : IFocalPointRepository
    {
        private ILog log;
        private string connectionString;

        public SQLServerFocalPointRepository(string connectionString, ILog log)
        {
            this.log = log;
            this.connectionString = connectionString;
        }

        public IEnumerable<string> GetFocalPoints()
        {
            var result = new List<string>();

            string getFocalPointsSqlCmd = "Select [Name] From dbo.FocalPoints;";
            using (SqlConnection conn = new SqlConnection(this.connectionString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(getFocalPointsSqlCmd, conn))
                {
                    using (SqlDataReader reader = theCommand.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(reader.GetString(0));
                        }
                    }
                }
            }

            return result;
        }

    }
}
