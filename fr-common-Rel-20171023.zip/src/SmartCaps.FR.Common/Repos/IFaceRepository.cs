﻿using SmartCaps.FR.Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Repos
{
    public interface IFaceRepository 
    {
        Face GetFaceById(string id, bool includeFeatures);

        IEnumerable<Face> GetFaces(int pageIndex, int pageSize, bool includeFeatures);

        IEnumerable<Face> GetFaces(IDictionary<ImageRef, IDictionary<string,string>> imagesWithMetadata, string owner, IEnumerable<string> tags, IEnumerable<string> sienaRefs, IEnumerable<string> focalPoints, bool? confirmed, bool includeFeatures, int pageIndex, int pageSize);

        IEnumerable<Face> GetNotEvaluatedFaces(int pageIndex, int pageSize, bool includeFeatures);

        int GetFacesCount();

        int GetNotEvaluatedFacesCount();

        int GetFacesCount(IEnumerable<ImageRef> images, string owner, IEnumerable<string> tags, IEnumerable<string> sienaRefs, IEnumerable<string> focalPoints, bool? confirmed);

        AddFacesResult AddFaces(IEnumerable<Face> faces);

        bool RemoveFaceById(string id);

        bool SetFaceConfirmation(string id, bool confirmation);

        bool SetFaceEvaluation(string id, bool evaluation);

        bool SetFaceOwner(string id, string owner);

        bool SetFaceTags(string id, IList<string> tags);

        bool SetFaceSienaRefs(string id, IList<string> sienaRefs);

        bool SetFaceFocalPoints(string id, IList<string> focalPoints);

        IEnumerable<string> GetSienaRefsFromFaces();

        IEnumerable<string> GetTagsFromFaces();

        IEnumerable<string> GetOwnersFromFaces();
    }

    public class AddFacesResult
    {
        public AddFacesResult()
        {
            this.AddedFaces = new List<Face>();
            this.AlreadyExistingFaces = new List<Face>();
        }
        public IList<Face> AddedFaces { get; set; }
        public IList<Face> AlreadyExistingFaces { get; set; }
    }
}
