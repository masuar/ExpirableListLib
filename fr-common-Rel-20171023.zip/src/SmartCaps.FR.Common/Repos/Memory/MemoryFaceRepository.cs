﻿using System.Collections.Generic;
using System.Linq;
using SmartCaps.FR.Common.Model;
using log4net;

namespace SmartCaps.FR.Common.Repos.Memory
{
    public class MemoryFaceRepository : IFaceRepository
    {
        private ILog log;
        private IDictionary<string, Face> memoryStore;

        public MemoryFaceRepository(IDictionary<string, Face> memoryStore, ILog log)
        {
            this.memoryStore = memoryStore;
            this.log = log;
        }

        public int GetFacesCount()
        {
            return this.memoryStore.Where(f => f.Value.Evaluated == true).Count();
        }

        public IEnumerable<Face> GetFaces(int pageIndex, int pageSize)
        {
            return this.GetFaces(pageIndex, pageSize, includeFeatures: true);
        }

        public IEnumerable<Face> GetFaces(int pageIndex, int pageSize, bool includeFeatures)
        {
            return this.memoryStore.Values.Skip(pageIndex * pageSize).Take(pageSize);
        }

        public IEnumerable<Face> GetFaces(IDictionary<ImageRef, IDictionary<string, string>> imagesWithMetadata, string owner, IEnumerable<string> tags, IEnumerable<string> sienaRefs, IEnumerable<string> focalPoints, bool? confirmed, bool includeFeatures, int pageIndex, int pageSize)
        {
            IEnumerable<Face> result = new List<Face>(this.memoryStore.Values);
            if (imagesWithMetadata != null && imagesWithMetadata.Any())
            {
                result = this.memoryStore.Values.Where(item => imagesWithMetadata.Any(i => i.Key.Id == item.ImageRef.Id && i.Key.RefType == item.ImageRef.RefType));
            }

            if (owner != null)
            {
                result = result.Where(item => item.Owner == owner);
            }

            if (tags != null && tags.Any())
            {
                result = result.Where(item => item.Tags.Intersect(tags).Any());
            }

            if (sienaRefs != null && sienaRefs.Any())
            {
                result = result.Where(item => item.SienaRefs.Intersect(sienaRefs).Any());
            }

            if (focalPoints != null && focalPoints.Any())
            {
                result = result.Where(item => item.FocalPoints.Intersect(sienaRefs).Any());
            }

            if (confirmed != null)
            {
                result = result.Where(item => item.Confirmed == confirmed);
            }

            result = result.Where(f => f.Evaluated == true);
            result = result.Skip(pageIndex * pageSize).Take(pageSize);

            return result;

        }

        public int GetFacesCount(IEnumerable<ImageRef> images, string owner, IEnumerable<string> tags, IEnumerable<string> sienaRefs, IEnumerable<string> focalPoints, bool? confirmed)
        {
            IEnumerable<Face> faces = new List<Face>();

            if (images != null && images.Any())
            {
                faces = this.memoryStore.Values.Where(item => images.Any(i => i.Id == item.ImageRef.Id && i.RefType == item.ImageRef.RefType));
            }

            if (owner != null)
            {
                faces = faces.Where(item => item.Owner == owner);
            }

            if (tags != null && tags.Any())
            {
                faces = faces.Where(item => item.Tags.Intersect(tags).Any());
            }

            if (sienaRefs != null && sienaRefs.Any())
            {
                faces = faces.Where(item => item.SienaRefs.Intersect(sienaRefs).Any());
            }

            if (focalPoints != null && focalPoints.Any())
            {
                faces = faces.Where(item => item.FocalPoints.Intersect(sienaRefs).Any());
            }

            if (confirmed != null)
            {
                faces = faces.Where(item => item.Confirmed == confirmed);
            }

            faces = faces.Where(f => f.Evaluated == true);

            return faces.Count();
        }

        public Face GetFaceById(string id, bool includeFeatures)
        {
            Face result = null;
            if (this.memoryStore.ContainsKey(id) && this.memoryStore[id].Evaluated)
            {
                result = this.memoryStore[id];
            }

            return result;
        }

        public AddFacesResult AddFaces(IEnumerable<Face> faces)
        {
            AddFacesResult result = new AddFacesResult();
            foreach (Face face in faces)
            {
                if (this.memoryStore.ContainsKey(face.Id))
                {
                    result.AlreadyExistingFaces.Add(face);
                }
                else
                {
                    this.memoryStore.Add(face.Id, face);
                    result.AddedFaces.Add(face);
                }
            }

            this.log.DebugFormat("{0} faces added, {1} already existing. There are {2} faces in total.", result.AddedFaces.Count, result.AlreadyExistingFaces.Count, this.memoryStore.Count);

            return result;
        }

        public bool RemoveFaceById(string id)
        {
            return this.memoryStore.Remove(id);
        }

        public bool SetFaceConfirmation(string id, bool confirmation)
        {
            bool result = false;

            Face face = this.GetFaceById(id, false);
            if (face != null)
            {
                face.Confirmed = confirmation;
            }

            return result;
        }

        public bool SetFaceTags(string id, IList<string> tags)
        {
            bool result = false;

            Face face = this.GetFaceById(id, false);
            if (face != null)
            {
                face.Tags = tags;
                result = true;
            }

            return result;
        }

        public bool SetFaceOwner(string id, string owner)
        {
            bool result = false;

            Face face = this.GetFaceById(id, false);
            if (face != null)
            {
                face.Owner = owner;
                result = true;
            }

            return result;
        }

        public bool SetFaceSienaRefs(string id, IList<string> sienaRefs)
        {
            bool result = false;

            Face face = this.GetFaceById(id, false);
            if (face != null)
            {
                face.SienaRefs = sienaRefs;
                result = true;
            }

            return result;

        }

        public bool SetFaceFocalPoints(string id, IList<string> focalPoints)
        {
            bool result = false;

            Face face = this.GetFaceById(id, false);
            if (face != null)
            {
                face.FocalPoints = focalPoints;
                result = true;
            }

            return result;
        }

        public bool SetFaceEvaluation(string id, bool evaluation)
        {
            bool result = false;

            Face face = this.GetFaceById(id, false);
            if (face != null)
            {
                face.Evaluated = evaluation;
            }

            return result;

        }

        public IEnumerable<Face> GetNotEvaluatedFaces(int pageIndex, int pageSize, bool includeFeatures)
        {
            return this.memoryStore.Values.Where(f => f.Evaluated == false).Skip(pageIndex * pageSize).Take(pageSize);
        }

        public int GetNotEvaluatedFacesCount()
        {
            return this.memoryStore.Where(f => f.Value.Evaluated == false).Count();
        }

        IEnumerable<string> IFaceRepository.GetSienaRefsFromFaces()
        {
            var focalPoints = string.Join(",", this.memoryStore.Values.Select(x => x.SienaRefs));
            return focalPoints.Split(',');
        }

        public IEnumerable<string> GetTagsFromFaces()
        {
            var focalPoints = string.Join(",", this.memoryStore.Values.Select(x => x.Tags));
            return focalPoints.Split(',');
        }

        public IEnumerable<string> GetOwnersFromFaces()
        {
            return this.memoryStore.Values.Select(x => x.Owner).Distinct();
        }
    }
}