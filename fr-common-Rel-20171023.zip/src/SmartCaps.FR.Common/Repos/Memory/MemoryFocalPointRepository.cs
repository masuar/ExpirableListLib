﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Repos.Memory
{
    class MemoryFocalPointRepository : IFocalPointRepository
    {
        private ILog log;
        private IList<string> memoryStore;

        public MemoryFocalPointRepository(IList<string> memoryStore, ILog log)
        {
            this.memoryStore = memoryStore;
            this.log = log;
        }

        public IEnumerable<string> GetFocalPoints()
        {
            var focalPoints = string.Join(",", this.memoryStore);
            return focalPoints.Split(',');
        }
    }
}
