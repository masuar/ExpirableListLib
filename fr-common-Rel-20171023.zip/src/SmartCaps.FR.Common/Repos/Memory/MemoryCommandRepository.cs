﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmartCaps.FR.Common.Model.Commands;
using log4net;

namespace SmartCaps.FR.Common.Repos.Memory
{
    public class MemoryCommandRepository : ICommandRepository
    {
        private ILog log;
        private IDictionary<string, ICommand> memoryStore;

        public MemoryCommandRepository(IDictionary<string, ICommand> memoryStore, ILog log)
        {
            this.memoryStore = memoryStore;
            this.log = log;
        }

        public bool DoesCommandExist(string token)
        {
            return this.memoryStore.ContainsKey(token);
        }

        public ICommand GetCommandByToken(string token)
        {
            ICommand result = null;
            if (this.memoryStore.ContainsKey(token))
            {
                result = ObjectCopier.Clone<BaseCommand>(this.memoryStore[token] as BaseCommand);
            }

            return result;
        }

        public bool DeleteCommandByToken(string token)
        {
            return this.memoryStore.Remove(token);
        }

        public IEnumerable<string> DeleteOldCommands(int daysOlder, bool deleteErrorCmds)
        {
            IList<string> removedTokens = new List<string>();
            var oldCommands = this.memoryStore.Values.Where(c => c.LastUpdatedOn < (DateTime.UtcNow.Subtract(TimeSpan.FromDays(daysOlder))));
            foreach(ICommand cmd in oldCommands)
            {
                if (this.DeleteCommandByToken(cmd.Token))
                {
                    removedTokens.Add(cmd.Token);
                }
            }
            return removedTokens;
        }

        public void InsertOrUpdateCommand(IFacesCommand cmd)
        {
            this.InsertOrUpdateCommand((ICommand)cmd);
        }

        public void InsertOrUpdateCommand(IEvalCommand cmd)
        {
            this.InsertOrUpdateCommand((ICommand)cmd);
        }

        public void InsertOrUpdateCommand(ICommand cmd)
        {
            // TODO: Must be with clones
            if (!this.memoryStore.ContainsKey(cmd.Token))
            {
                this.memoryStore.Add(cmd.Token, cmd);
            }
            else
            {
                this.memoryStore[cmd.Token] = cmd;
            }

            this.log.DebugFormat("Command added / updated. There are {0} commands in total.", this.memoryStore.Count);
        }
    }
}
