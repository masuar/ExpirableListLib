﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model
{
    public enum ImageRefTypes
    {
        NONE,
        FILESYS,
        FMMS,
        IVAS
    }
}
