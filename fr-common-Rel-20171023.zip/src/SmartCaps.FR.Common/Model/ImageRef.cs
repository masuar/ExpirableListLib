﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model
{
    public class ImageRef : IEquatable<ImageRef>
    {
        [JsonConverter(typeof(StringEnumConverter))]
        [JsonProperty("refType")]
        public ImageRefTypes RefType { get; set; }

        [JsonProperty("imageId")]
        public string Id { get; set; }

        [JsonProperty("imagePath")]
        public string Path { get; set; }

        public bool Equals(ImageRef other)
        {
            if (other == null)
            {
                return false;
            }
            
            return string.Equals(this.Id,other.Id) && this.RefType.Equals(other.RefType);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;

            if (obj.GetType() != GetType()) return false;

            return Equals(obj as ImageRef);
        }

        public override int GetHashCode()
        {
            return (this.Id + this.RefType.ToString()).GetHashCode();
        }

    }
}


