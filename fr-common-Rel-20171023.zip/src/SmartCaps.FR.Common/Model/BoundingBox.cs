﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model
{
    public class BoundingBox
    {
        [JsonProperty("topLeft")]
        public Coord TopLeft { get; set; }

        [JsonProperty("downRight")]
        public Coord DownRight { get; set; }

        [JsonIgnore]
        public int Width 
        {
            get
            {
                return this.DownRight.Y - this.TopLeft.Y;
            }
        }

        [JsonIgnore]
        public int Height
        {
            get
            {
                return this.DownRight.X - this.TopLeft.X;
            }
        }

    }
}
