﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model.Commands
{
    public class IAmAliveCommand : BaseCommand
    {
        public IAmAliveCommand() 
            : base()
        {
        }

        public IAmAliveCommand(string token) 
            : base(token)
        {
        }
    }
}
