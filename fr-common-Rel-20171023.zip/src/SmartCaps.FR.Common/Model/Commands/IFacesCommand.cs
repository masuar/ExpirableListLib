﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model.Commands
{
    public interface IFacesCommand : ICommand
    {
        IList<FaceInCommand> Faces { get; }

        ImageRef ImageRef { get; }

        bool Autoconfirm { get; set; }

        IEnumerable<string> Tags { get; }

        IEnumerable<string> SienaRefs { get; }

        IEnumerable<string> FocalPoints { get; }

        double FaceQualityScoreThreshold { get; set; }
    }
}
