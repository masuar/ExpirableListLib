﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Security.Principal;

namespace SmartCaps.FR.Common.Model.Commands
{
    public abstract class BaseCommand : ICommand
    {
        public BaseCommand()
        {
            this.CreatedBy = WindowsIdentity.GetCurrent().Name;
            this.CreatedOn = DateTime.UtcNow;
            this.LastUpdatedBy = this.CreatedBy;
            this.LastUpdatedOn = this.CreatedOn;
        }

        public BaseCommand(string token) 
            : this()
        {
            this.Token = token;
        }

        [JsonProperty("cmdType")]
        public string CommandType
        {
            get
            {
                return this.GetType().Name;
            }
        }
        [JsonProperty("token")]
        public string Token { get; set; }

        [JsonProperty("createdBy")]
        public string CreatedBy { get; set; }

        [JsonProperty("createdOn")]
        [JsonConverter(typeof(IsoDateTimeConverter))]
        public DateTime CreatedOn { get; set; }

        [JsonProperty("lastUpdatedBy")]
        public string LastUpdatedBy { get; set; }

        [JsonProperty("lastUpdatedOn")]
        [JsonConverter(typeof(IsoDateTimeConverter))]
        public DateTime LastUpdatedOn { get; set; }

        [JsonProperty("totalSteps")]
        public int TotalSteps { get; set; }

        [JsonProperty("lastStepCompleted")]
        public int LastStepCompleted { get; set; }

        [JsonProperty("stepscompleted")]
        public ComponentSteps StepsCompleted { get; set; }

        [JsonProperty("errorMessage")]
        public string ErrorMessage { get; set; }
    }
}
