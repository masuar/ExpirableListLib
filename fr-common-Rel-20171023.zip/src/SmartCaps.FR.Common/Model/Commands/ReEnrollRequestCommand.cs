﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model.Commands
{
    public class ReEnrollRequestCommand : BaseCommand
    {
        public ReEnrollRequestCommand() 
            : base()
        {
        }

        public ReEnrollRequestCommand(string token) 
            : base(token)
        {
        }
    }
}
