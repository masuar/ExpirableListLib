﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model.Commands
{
    public class RemoveFacesCommand : BaseCommand, IFacesCommand
    {
        public RemoveFacesCommand() 
            : this(null)
        {
        }

        public RemoveFacesCommand(string token) 
            : base(token)
        {
            this.TotalSteps = 1;
            this.Faces = new List<FaceInCommand>();
        }

        [JsonProperty("autoConfirm")]
        public bool Autoconfirm { get; set; }

        [JsonProperty("faces")]
        public IList<FaceInCommand> Faces { get; private set; }

        [JsonProperty("imageRef")]
        public ImageRef ImageRef { get; private set; }

        [JsonProperty("tags")]
        public IEnumerable<string> Tags { get; private set; }

        [JsonProperty("sienaRefs")]
        public IEnumerable<string> SienaRefs { get; private set; }

        [JsonProperty("focalPoints")]
        public IEnumerable<string> FocalPoints { get; private set; }

        [JsonProperty("faceQualityScoreThreshold")]
        public double FaceQualityScoreThreshold { get; set; }

    }
}
