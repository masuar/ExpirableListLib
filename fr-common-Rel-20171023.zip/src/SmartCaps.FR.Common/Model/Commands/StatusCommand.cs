﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model.Commands
{
    public class StatusCommand : BaseCommand
    {
        public StatusCommand() 
            : base()
        {
            this.TotalSteps = 4;
        }

        public StatusCommand(string token) 
            : base(token)
        {
            this.TotalSteps = 4;
        }

    }
}
