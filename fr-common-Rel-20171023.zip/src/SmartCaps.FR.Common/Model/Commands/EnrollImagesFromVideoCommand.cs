﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model.Commands
{
    public class EnrollImagesFromVideoCommand : EnrollImageCommand
    {
        public EnrollImagesFromVideoCommand()
            :base()
        {
        }

        public EnrollImagesFromVideoCommand(string token)
            : base()
        {
            this.Token = token;
        }

    }
}
