﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model.Commands
{
    public class FaceInCommand : Face
    {
        public FaceInCommand(Face original)
            :base()
        {
            this.BoundingBox = original.BoundingBox;
            this.Confirmed = original.Confirmed;
            this.Features = original.Features;
            this.QualityScore = original.QualityScore;
            this.Id = original.Id;
            this.ImageRef = original.ImageRef;
            this.InsertedOn = original.InsertedOn;
            this.LastUpdatedOn = original.LastUpdatedOn;
            this.Metadata = original.Metadata;
            this.Owner = original.Owner;
            this.Tags = original.Tags;
            this.SienaRefs = original.SienaRefs;
            this.FocalPoints = original.FocalPoints;
        }

        public FaceInCommand()
            : base()
        {

        }

        [JsonProperty(PropertyName = "alreadyExisting", Order = 9)]
        public bool AlreadyExisting { get; set; }
    }
}
