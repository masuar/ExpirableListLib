﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model.Commands
{
    public class BatchEnrollImageCommand : EnrollImageCommand
    {
        public BatchEnrollImageCommand() 
            : base()
        {
        }

        public BatchEnrollImageCommand(string token) 
            : this()
        {
            this.Token = token;
        }

    }
}
