﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model.Commands
{
    public interface IEvalCommand : IFacesCommand
    {
        int TopN { get; set; }

        IList<FaceNeighbor> Neighbors { get; }

    }
}
