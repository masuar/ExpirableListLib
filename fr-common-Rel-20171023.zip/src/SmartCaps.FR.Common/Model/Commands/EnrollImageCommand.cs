﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model.Commands
{
    public class EnrollImageCommand : BaseCommand, IFacesCommand
    {
        public EnrollImageCommand() 
            : base()
        {
            this.Faces = new List<FaceInCommand>();
            this.ImageRef = new ImageRef();
            this.TotalSteps = 1;
        }

        public EnrollImageCommand(string token) 
            : this()
        {
            this.Token = token;
        }

        [JsonProperty("faces")]
        public IList<FaceInCommand> Faces { get; protected set; }

        [JsonProperty("imageRef")]
        public ImageRef ImageRef { get; protected set; }

        [JsonProperty("autoConfirm")]
        public bool Autoconfirm { get; set; }

        [JsonProperty("tags")]
        public IEnumerable<string> Tags { get; set; }

        [JsonProperty("sienaRefs")]
        public IEnumerable<string> SienaRefs { get; set; }

        [JsonProperty("focalPoints")]
        public IEnumerable<string> FocalPoints { get; set; }

        [JsonProperty("faceQualityScoreThreshold")]
        public double FaceQualityScoreThreshold { get; set; }

        [JsonProperty("originalFileName")]
        public string OriginalFileName { get; set; }

        [JsonProperty("metadata")]
        public IEnumerable<string> Metadata { get; set; }
    }
}
