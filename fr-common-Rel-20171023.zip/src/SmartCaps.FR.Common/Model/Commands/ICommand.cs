﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model.Commands
{
    public interface ICommand
    {
        string Token { get; }

        string CreatedBy { get; set; }

        DateTime CreatedOn { get; set; }

        string LastUpdatedBy { get; set; }

        DateTime LastUpdatedOn { get; set; }

        int TotalSteps { get; set; }

        int LastStepCompleted { get; set; }

        ComponentSteps StepsCompleted { get; set; }

        string ErrorMessage { get; set; }
    }
}
