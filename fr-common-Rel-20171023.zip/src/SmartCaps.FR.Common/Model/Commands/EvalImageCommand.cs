﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model.Commands
{
    public class EvalImageCommand : BaseCommand, IEvalCommand
    {
        public EvalImageCommand() 
            : base()
        {
            this.ImageRef = new ImageRef();
            this.Faces = new List<FaceInCommand>();
            this.Neighbors = new List<FaceNeighbor>();
            this.TotalSteps = 2;
            this.TopN = 10;
        }

        public EvalImageCommand(string token) 
            : this()
        {
            this.Token = token;
        }

        [JsonProperty("topN")]
        public int TopN { get; set; }

        [JsonProperty("faces")]
        public IList<FaceInCommand> Faces { get; private set; }

        [JsonProperty("tags")]
        public IEnumerable<string> Tags { get; set; }

        [JsonProperty("sienaRefs")]
        public IEnumerable<string> SienaRefs { get; set; }

        [JsonProperty("focalPoints")]
        public IEnumerable<string> FocalPoints { get; set; }

        [JsonProperty("faceQualityScoreThreshold")]
        public double FaceQualityScoreThreshold { get; set; }

        [JsonProperty("originalFileName")]
        public string OriginalFileName { get; set; }

        [JsonProperty("imageRef")]
        public ImageRef ImageRef { get; private set; }

        [JsonProperty("autoConfirm")]
        public bool Autoconfirm { get; set; }

        [JsonProperty("neighbours")]
        public IList<FaceNeighbor> Neighbors { get; private set; }
    }
}
