﻿namespace SmartCaps.FR.Common.Model.Commands
{
    public class EnrollAndEvalImageCommand : EvalImageCommand
    {
        public EnrollAndEvalImageCommand() 
            : base()
        {
        }

        public EnrollAndEvalImageCommand(string token) 
            : base(token)
        {
        }
    }
}
