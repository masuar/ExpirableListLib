﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model
{
    public class FaceNeighbor
    {
        [JsonProperty("sourceFaceId")]
        public string SourceFaceId { get; set; }

        [JsonProperty("targetFaceId")]
        public string TargetFaceId { get; set; }

        [JsonProperty("grade")]
        public double Grade { get; set; }
    }
}
