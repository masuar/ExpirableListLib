﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model
{
    [Flags]
    public enum ComponentSteps
    {
        None = 0,
        FaceEngine = 1,
        Knn = 2,
        Video = 4,
        Updater = 8
    }
}
