﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.Model
{
    public class Face
    {
        public Face()
        {
            this.Metadata = new Dictionary<string, string>();
            this.Tags = new List<string>();
            this.InsertedOn = DateTime.UtcNow;
            this.LastUpdatedOn = this.InsertedOn;
        }

        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("boundingBox")]
        public BoundingBox BoundingBox { get; set; }

        [JsonProperty("features")]
        public double[] Features { get; set; }

        [JsonProperty("qualityScore")]
        public double QualityScore { get; set; }

        [JsonProperty("imageRef")]
        public ImageRef ImageRef { get; set; }

        [JsonProperty("confirmed")]
        public bool Confirmed { get; set; }

        [JsonProperty("metadata")]
        public IDictionary<string,string> Metadata { get; set; }

        [JsonProperty("tags")]
        public IList<string> Tags { get; set; }

        [JsonProperty("sienaRefs")]
        public IList<string> SienaRefs { get; set; }

        [JsonProperty("focalPoints")]
        public IList<string> FocalPoints { get; set; }

        [JsonProperty("insertedBy")]
        public string Owner { get; set; }

        [JsonProperty("insertedOn")]
        public DateTime InsertedOn { get; set; }

        [JsonProperty("lastUpdatedOn")]
        public DateTime LastUpdatedOn { get; set; }

        [JsonProperty("evaluated")]
        public bool Evaluated { get; set; }

        [JsonProperty("softDeleted")]
        public bool SoftDeleted { get; set; }

        [JsonProperty("watchListed")]
        public bool WatchListed { get; set; }
    }
}
