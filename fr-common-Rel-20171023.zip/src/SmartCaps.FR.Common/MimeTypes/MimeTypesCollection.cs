﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.MimeTypes
{
    public class MimeTypesCollection : IMimeTypesCollection
    {
        protected string keyWord;
        protected IDictionary<string, string> supportedMimeTypes = new Dictionary<string, string>(StringComparer.InvariantCultureIgnoreCase);

        public MimeTypesCollection(string keyWord)
            : this(keyWord, "application/octet-stream")
        {
        }

        public MimeTypesCollection(string keyWord, string unspecifiedMimeType)
        {
            if (string.IsNullOrEmpty(keyWord) || string.IsNullOrEmpty(unspecifiedMimeType))
            {
                throw new ArgumentNullException();
            }

            this.keyWord = keyWord;
            this.UnspecifiedMimeType = unspecifiedMimeType;
        }

        public string UnspecifiedMimeType { get; private set; }

        public string DefaultMimeType
        {
            get
            {
                if (supportedMimeTypes.Count > 0)
                {
                    return supportedMimeTypes.First().Value;
                }
                else
                {
                    return this.UnspecifiedMimeType;
                }
            }
        }

        public bool IsSupported(string mimeType)
        {
            bool result = false;
            if (!string.IsNullOrEmpty(mimeType) && this.supportedMimeTypes.Values.Any(mt => mt == mimeType.ToLower()))
            {
                result = true;
            }

            return result;
        }

        public bool IsExtensionSupported(string extension)
        {
            bool result = false;
            this.AssureDotOnExtension(ref extension);
            if (!string.IsNullOrEmpty(extension) && this.supportedMimeTypes.Keys.Any(mt => mt == extension))
            {
                result = true;
            }

            return result;
        }


        public void Support(string extension, string mimeType)
        {
            if (string.IsNullOrEmpty(extension) || string.IsNullOrEmpty(mimeType))
            {
                throw new ArgumentNullException();
            }

            if (this.IsLikeMe(mimeType))
            {
                this.AssureDotOnExtension(ref extension);
                if (!this.IsExtensionSupported(extension))
                {
                    this.supportedMimeTypes.Add(extension.ToLower(), mimeType.ToLower());
                }
            }
        }

        public void SupportRange(IDictionary<string, string> mimeTypes)
        {
            foreach (var kvp in mimeTypes)
            {
                this.Support(kvp.Key, kvp.Value);
            }
        }

        public IEnumerable<string> GetExtensions(IEnumerable<string> mimeTypes)
        {
            IEnumerable<string> result = null;

            if (mimeTypes == null || mimeTypes.Count() == 0)
            {
                result = this.supportedMimeTypes.Select(kvp => kvp.Key);
            }
            else
            {
                result = this.supportedMimeTypes.Where(mt => mimeTypes.Contains(mt.Value)).Select(kvp => kvp.Key);
            }

            return result;
        }

        public IEnumerable<string> GetMimeTypes(IEnumerable<string> extensions)
        {
            IEnumerable<string> result = null;

            if (extensions == null || extensions.Count() == 0)
            {
                result = this.supportedMimeTypes.Select(kvp => kvp.Value).Distinct();
            }
            else
            {
                result = this.supportedMimeTypes.Where(mt => extensions.Contains(mt.Key)).Select(kvp => kvp.Value).Distinct();
            }


            return result;
        }


        public string GetMimeTypeFromFileName(string fileName)
        {
            return this.GetMimeTypeFromExtension(Path.GetExtension(fileName));
        }

        public string GetMimeTypeFromExtension(string extension)
        {
            string result = this.UnspecifiedMimeType;
            this.AssureDotOnExtension(ref extension);
            if (string.IsNullOrEmpty(extension))
            {
                result = this.DefaultMimeType;

            }
            else if (this.supportedMimeTypes.ContainsKey(extension))
            {
                result = this.supportedMimeTypes[extension];
            }

            return result;
        }

        protected void AssureDotOnExtension(ref string extension)
        {
            if (!string.IsNullOrEmpty(extension))
            {
                extension = extension.ToLower();
                if (!extension.StartsWith("."))
                {
                    extension = string.Concat(".", extension);
                }
            }
        }

        protected bool IsLikeMe(string mimeType)
        {
            bool result = false;
            if (!string.IsNullOrEmpty(mimeType) && mimeType.StartsWith(this.keyWord))
            {
                result = true;
            }

            return result;
        }
    }
}
