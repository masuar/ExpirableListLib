﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.MimeTypes
{
    public class ImageMimeTypes : MimeTypesCollection
    {
        private IDictionary<string, string> defaults = new Dictionary<string, string>(StringComparer.InvariantCultureIgnoreCase)
        {
            { ".gif",  "image/gif"},
            { ".jpe",  "image/jpeg"},
            { ".jpeg", "image/jpeg"},
            { ".jpg",  "image/jpeg"},
            { ".png",  "image/png"}
        };

        public ImageMimeTypes()
            :base("image")
        {
            this.SupportRange(defaults);
        }
    }
}
