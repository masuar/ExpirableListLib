﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SmartCaps.FR.Common.MimeTypes
{
    public class MimeTypesHelper : IMimeTypesCollection
    {

        public MimeTypesHelper() 
        {
            this.Images = new ImageMimeTypes();
            this.Videos = new VideoMimeTypes();
        }

        public MimeTypesHelper(IDictionary<string,string> supportedMimeTypes)
            :this()
        {
            if (supportedMimeTypes != null)
            {
                this.Images.SupportRange(supportedMimeTypes);
                this.Videos.SupportRange(supportedMimeTypes);
            }
        }

        public MimeTypesCollection Images { get; private set; }

        public MimeTypesCollection Videos { get; private set; }

        public string UnspecifiedMimeType
        {
            get
            {
                return this.Images.UnspecifiedMimeType;
            }
        }

        public string DefaultMimeType
        {
            get
            {
                return this.Images.DefaultMimeType;
            }
        }

        public IEnumerable<string> GetExtensions(IEnumerable<string> mimeTypes)
        {
            List<string> result = new List<string>();

            result.AddRange(this.Images.GetExtensions(mimeTypes));
            result.AddRange(this.Videos.GetExtensions(mimeTypes));

            return result;
        }

        public IEnumerable<string> GetMimeTypes(IEnumerable<string> extensions)
        {
            List<string> result = new List<string>();

            result.AddRange(this.Images.GetMimeTypes(extensions));
            result.AddRange(this.Videos.GetMimeTypes(extensions));

            return result;
        }

        public string GetMimeTypeFromFileName(string fileName)
        {
            return this.GetMimeTypeFromExtension(Path.GetExtension(fileName));
        }

        public string GetMimeTypeFromExtension(string extension)
        {
            string result = this.Images.GetMimeTypeFromExtension(extension);

            if (result == "application/octet-stream")
            {
                result = this.Videos.GetMimeTypeFromExtension(extension);
            }

            return result;
        }

        public bool IsSupported(string mimeType)
        {
            return this.Images.IsSupported(mimeType) || this.Videos.IsSupported(mimeType);
        }

        public void Support(string extension, string mimeType)
        {
            this.Images.Support(extension, mimeType);
            this.Videos.Support(extension, mimeType);
        }

        public void SupportRange(IDictionary<string, string> mimeTypes)
        {
            this.Images.SupportRange(mimeTypes);
            this.Videos.SupportRange(mimeTypes);
        }

        public bool IsExtensionSupported(string extension)
        {
            bool isSupportedOnImage = this.Images.IsExtensionSupported(extension);
            bool isSupportedOnVideo = this.Videos.IsExtensionSupported(extension);

            return isSupportedOnImage || isSupportedOnVideo;
        }
    }
}
