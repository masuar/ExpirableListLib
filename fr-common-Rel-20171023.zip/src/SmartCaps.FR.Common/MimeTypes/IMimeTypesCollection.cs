﻿using System.Collections.Generic;

namespace SmartCaps.FR.Common.MimeTypes
{
    public interface IMimeTypesCollection
    {
        string UnspecifiedMimeType { get; }

        string DefaultMimeType { get; }

        IEnumerable<string> GetExtensions(IEnumerable<string> mimeTypes);

        IEnumerable<string> GetMimeTypes(IEnumerable<string> extensions);

        bool IsSupported(string mimeType);

        bool IsExtensionSupported(string extension);

        void Support(string extension, string mimeType);

        void SupportRange(IDictionary<string, string> mimeTypes);

        /// <summary>
        /// Gets the Mime Type name given a file name.
        /// </summary>
        /// <param name="fileName">The file name to analyze.</param>
        /// <returns>The correspondent Mime Type name.</returns>
        string GetMimeTypeFromFileName(string fileName);

        /// <summary>
        /// Gets the Mime Type name given a extension.
        /// </summary>
        /// <param name="extension">The extension, with the dot included (e.g. '.txt')</param>
        /// <returns>The correspondent Mime Type name.</returns>
        string GetMimeTypeFromExtension(string extension);
    }
}