﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Common.MimeTypes
{
    public class VideoMimeTypes : MimeTypesCollection
    {
        private IDictionary<string, string> defaults = new Dictionary<string, string>(StringComparer.InvariantCultureIgnoreCase)
        {
            { ".wmv",  "video/x-ms-wmv"},
            { ".mp4",  "video/mp4"},
            { ".3gp",  "video/3gpp"},
            { ".mov",  "video/quicktime"},
            { ".avi",  "video/x-msvideo"}
        };

        public VideoMimeTypes()
            :base("video")
        {
            this.SupportRange(defaults);
        }
    }
}
