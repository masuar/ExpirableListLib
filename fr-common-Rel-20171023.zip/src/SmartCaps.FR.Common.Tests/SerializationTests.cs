﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SmartCaps.FR.Common.Model.Commands;
using Newtonsoft.Json;
using SmartCaps.FR.Common.Model;

namespace SmartCaps.FR.Updater.Tests
{
    [TestClass]
    public class SerializationTests
    {
        private DateTime sampleDate = new DateTime(2017, 01, 02, 18, 42, 37, DateTimeKind.Utc).ToUniversalTime();
        private string evalImageCommandJson =           "{\"topN\":1,\"faces\":[{\"id\":\"aSampleFaceId\",\"boundingBox\":{\"topLeft\":{\"x\":10,\"y\":10},\"downRight\":{\"x\":20,\"y\":20}},\"features\":[0.1,0.2,0.3]}],\"imageRef\":{\"refType\":\"FILESYS\",\"imagePath\":\"aSampleImagePath\",\"imageId\":\"aSampleImageId\"},\"neighbours\":[{\"sourceFaceId\":\"aSampleFaceId\",\"targetFaceId\":\"anotherSampleFaceId\",\"grade\":0.75}],\"cmdType\":\"EvalImageCommand\",\"token\":\"aSampleToken\",\"createdBy\":\"someone\",\"createdOn\":\"2017-01-02T18:42:37Z\",\"lastUpdatedOn\":\"2017-01-02T18:42:37Z\",\"totalSteps\":9,\"lastStepCompleted\":8}";
        private string enrollAndEvalImageCommandJson =  "{\"topN\":1,\"faces\":[{\"id\":\"aSampleFaceId\",\"boundingBox\":{\"topLeft\":{\"x\":10,\"y\":10},\"downRight\":{\"x\":20,\"y\":20}},\"features\":[0.1,0.2,0.3]}],\"imageRef\":{\"refType\":\"FILESYS\",\"imagePath\":\"aSampleImagePath\",\"imageId\":\"aSampleImageId\"},\"neighbours\":[{\"sourceFaceId\":\"aSampleFaceId\",\"targetFaceId\":\"anotherSampleFaceId\",\"grade\":0.75}],\"cmdType\":\"EnrollAndEvalImageCommand\",\"token\":\"aSampleToken\",\"createdBy\":\"someone\",\"createdOn\":\"2017-01-02T18:42:37Z\",\"lastUpdatedOn\":\"2017-01-02T18:42:37Z\",\"totalSteps\":9,\"lastStepCompleted\":8}";
        private string enrollImageCommandJson = "{\"faces\":[{\"id\":\"aSampleFaceId\",\"boundingBox\":{\"topLeft\":{\"x\":10,\"y\":10},\"downRight\":{\"x\":20,\"y\":20}},\"features\":[0.1,0.2,0.3]}],\"imageRef\":{\"refType\":\"FILESYS\",\"imagePath\":\"aSampleImagePath\",\"imageId\":\"aSampleImageId\"},\"cmdType\":\"EnrollImageCommand\",\"token\":\"aSampleToken\",\"createdBy\":\"someone\",\"createdOn\":\"2017-01-02T18:42:37Z\",\"lastUpdatedOn\":\"2017-01-02T18:42:37Z\",\"totalSteps\":9,\"lastStepCompleted\":8}";
        
        [TestMethod]
        public void EvalImageCommand_serializes_properly()
        {
            // Arrange
            EvalImageCommand sampleCommand = new EvalImageCommand("aSampleToken");
            sampleCommand.TopN = 1;
            sampleCommand.Neighbors.Add(new FaceNeighbor() { SourceFaceId = "aSampleFaceId", TargetFaceId = "anotherSampleFaceId", Grade = 0.75 });
            sampleCommand.CreatedBy = "someone";
            sampleCommand.CreatedOn = this.sampleDate;
            sampleCommand.Faces.Add(new FaceInCommand() { Id = "aSampleFaceId", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] {0.1, 0.2, 0.3 } });
            sampleCommand.ImageRef.Id = "aSampleImageId";
            sampleCommand.ImageRef.RefType = ImageRefTypes.FILESYS;
            sampleCommand.LastUpdatedOn = this.sampleDate;
            sampleCommand.TotalSteps = 9;
            sampleCommand.LastStepCompleted = 8;
            string expected = this.evalImageCommandJson;

            // Exec
            string json = JsonConvert.SerializeObject(sampleCommand);

            // Assert
            Assert.IsTrue(json.Contains("\"topN\":1"));
            Assert.IsTrue(json.Contains("\"faces\":[{\"id\":\"aSampleFaceId\""));
            Assert.IsTrue(json.Contains("\"imageRef\":{\"refType\":\"FILESYS\",\"imageId\":\"aSampleImageId\",\"imagePath\":null}"));
            Assert.IsTrue(json.Contains("\"lastUpdatedBy\":\""));
            Assert.IsTrue(json.Contains("\"lastUpdatedOn\":\"2017-01-02T18:42:37Z\""));
            Assert.IsTrue(json.Contains("\"totalSteps\":9"));
            Assert.IsTrue(json.Contains("\"lastStepCompleted\":8"));
            Assert.IsTrue(json.Contains("\"token\":\"aSampleToken\""));
            Assert.IsTrue(json.Contains("\"cmdType\":\"EvalImageCommand\""));

        }

        [TestMethod]
        public void EvalImageCommand_deserializes_properly()
        {
            // Arrange
            string expectedJson = this.evalImageCommandJson;

            // Exec
            EvalImageCommand deserialized = JsonConvert.DeserializeObject<EvalImageCommand>(expectedJson);

            // Assert
            Assert.AreEqual("aSampleToken", deserialized.Token);
            Assert.AreEqual(1, deserialized.TopN);
            Assert.AreEqual(1, deserialized.Neighbors.Count);
            Assert.AreEqual("aSampleFaceId", deserialized.Neighbors.First().SourceFaceId);
            Assert.AreEqual("anotherSampleFaceId", deserialized.Neighbors.First().TargetFaceId);
            Assert.AreEqual(0.75, deserialized.Neighbors.First().Grade);
            Assert.AreEqual("someone", deserialized.CreatedBy);
            Assert.AreEqual(this.sampleDate, deserialized.CreatedOn);
            Assert.AreEqual(1, deserialized.Faces.Count);
            Assert.AreEqual("aSampleFaceId", deserialized.Faces.First().Id);
            Assert.AreEqual(10, deserialized.Faces.First().BoundingBox.TopLeft.X);
            Assert.AreEqual(20, deserialized.Faces.First().BoundingBox.DownRight.Y);
            Assert.AreEqual(0.3, deserialized.Faces.First().Features[2]);
            Assert.AreEqual(this.sampleDate, deserialized.LastUpdatedOn);
            Assert.AreEqual(9, deserialized.TotalSteps);
            Assert.AreEqual(8, deserialized.LastStepCompleted);

        }

        [TestMethod]
        public void EnrollImageCommand_serializes_properly()
        {
            // Arrange
            EnrollImageCommand sampleCommand = new EnrollImageCommand("aSampleToken");
            sampleCommand.CreatedBy = "someone";
            sampleCommand.CreatedOn = this.sampleDate;
            sampleCommand.Faces.Add(new FaceInCommand() { Id = "aSampleFaceId", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.1, 0.2, 0.3 } });
            sampleCommand.ImageRef.Id = "aSampleImageId";
            sampleCommand.ImageRef.RefType = ImageRefTypes.FILESYS;
            sampleCommand.LastUpdatedOn = this.sampleDate;
            sampleCommand.TotalSteps = 9;
            sampleCommand.LastStepCompleted = 8;
            string expected = this.enrollImageCommandJson;

            // Exec
            string json = JsonConvert.SerializeObject(sampleCommand);

            // Assert
            Assert.IsFalse(json.Contains("\"topN\":1"));
            Assert.IsTrue(json.Contains("\"faces\":[{\"id\":\"aSampleFaceId\""));
            Assert.IsTrue(json.Contains("\"imageRef\":{\"refType\":\"FILESYS\",\"imageId\":\"aSampleImageId\",\"imagePath\":null}"));
            Assert.IsTrue(json.Contains("\"lastUpdatedBy\":\""));
            Assert.IsTrue(json.Contains("\"lastUpdatedOn\":\"2017-01-02T18:42:37Z\""));
            Assert.IsTrue(json.Contains("\"totalSteps\":9"));
            Assert.IsTrue(json.Contains("\"lastStepCompleted\":8"));
            Assert.IsTrue(json.Contains("\"token\":\"aSampleToken\""));
            Assert.IsTrue(json.Contains("\"cmdType\":\"EnrollImageCommand\""));

        }

        [TestMethod]
        public void EnrollImageCommand_deserializes_properly()
        {
            // Arrange
            string expectedJson = this.enrollImageCommandJson;

            // Exec
            EnrollImageCommand deserialized = JsonConvert.DeserializeObject<EnrollImageCommand>(expectedJson);

            // Assert
            Assert.AreEqual("aSampleToken", deserialized.Token);
            Assert.AreEqual("someone", deserialized.CreatedBy);
            Assert.AreEqual(this.sampleDate, deserialized.CreatedOn);
            Assert.AreEqual(1, deserialized.Faces.Count);
            Assert.AreEqual("aSampleFaceId", deserialized.Faces.First().Id);
            Assert.AreEqual(10, deserialized.Faces.First().BoundingBox.TopLeft.X);
            Assert.AreEqual(20, deserialized.Faces.First().BoundingBox.DownRight.Y);
            Assert.AreEqual(0.3, deserialized.Faces.First().Features[2]);
            Assert.AreEqual(this.sampleDate, deserialized.LastUpdatedOn);
            Assert.AreEqual(9, deserialized.TotalSteps);
            Assert.AreEqual(8, deserialized.LastStepCompleted);

        }

        [TestMethod]
        public void EnrollAndEvalImageCommand_serializes_properly()
        {
            // Arrange
            EnrollAndEvalImageCommand sampleCommand = new EnrollAndEvalImageCommand("aSampleToken");
            sampleCommand.TopN = 1;
            sampleCommand.Neighbors.Add(new FaceNeighbor() { SourceFaceId = "aSampleFaceId", TargetFaceId = "anotherSampleFaceId", Grade = 0.75 });
            sampleCommand.CreatedBy = "someone";
            sampleCommand.CreatedOn = this.sampleDate;
            sampleCommand.Faces.Add(new FaceInCommand() { Id = "aSampleFaceId", BoundingBox = new BoundingBox() { TopLeft = new Coord(10, 10), DownRight = new Coord(20, 20) }, Features = new double[] { 0.1, 0.2, 0.3 } });
            sampleCommand.ImageRef.Id = "aSampleImageId";
            sampleCommand.ImageRef.RefType = ImageRefTypes.FILESYS;
            sampleCommand.LastUpdatedOn = this.sampleDate;
            sampleCommand.TotalSteps = 9;
            sampleCommand.LastStepCompleted = 8;
            string expected = this.enrollAndEvalImageCommandJson;

            // Exec
            string json = JsonConvert.SerializeObject(sampleCommand);

            // Assert
            Assert.IsTrue(json.Contains("\"topN\":1"));
            Assert.IsTrue(json.Contains("\"faces\":[{\"id\":\"aSampleFaceId\""));
            Assert.IsTrue(json.Contains("\"imageRef\":{\"refType\":\"FILESYS\",\"imageId\":\"aSampleImageId\",\"imagePath\":null}"));
            Assert.IsTrue(json.Contains("\"lastUpdatedBy\":\""));
            Assert.IsTrue(json.Contains("\"lastUpdatedOn\":\"2017-01-02T18:42:37Z\""));
            Assert.IsTrue(json.Contains("\"totalSteps\":9"));
            Assert.IsTrue(json.Contains("\"lastStepCompleted\":8"));
            Assert.IsTrue(json.Contains("\"token\":\"aSampleToken\""));

            Assert.IsTrue(json.Contains("\"neighbours\":[{"));
            Assert.IsTrue(json.Contains("\"targetFaceId\":\"anotherSampleFaceId\""));
            Assert.IsTrue(json.Contains("\"grade\":0.75"));
            Assert.IsTrue(json.Contains("\"cmdType\":\"EnrollAndEvalImageCommand\""));

        }

        [TestMethod]
        public void EnrollAndEvalImageCommand_deserializes_properly()
        {
            // Arrange
            string expectedJson = this.evalImageCommandJson;

            // Exec
            EnrollAndEvalImageCommand deserialized = JsonConvert.DeserializeObject<EnrollAndEvalImageCommand>(expectedJson);

            // Assert
            Assert.AreEqual("aSampleToken", deserialized.Token);
            Assert.AreEqual(1, deserialized.TopN);
            Assert.AreEqual(1, deserialized.Neighbors.Count);
            Assert.AreEqual("aSampleFaceId", deserialized.Neighbors.First().SourceFaceId);
            Assert.AreEqual("anotherSampleFaceId", deserialized.Neighbors.First().TargetFaceId);
            Assert.AreEqual(0.75, deserialized.Neighbors.First().Grade);
            Assert.AreEqual("someone", deserialized.CreatedBy);
            Assert.AreEqual(this.sampleDate, deserialized.CreatedOn);
            Assert.AreEqual(1, deserialized.Faces.Count);
            Assert.AreEqual("aSampleFaceId", deserialized.Faces.First().Id);
            Assert.AreEqual(10, deserialized.Faces.First().BoundingBox.TopLeft.X);
            Assert.AreEqual(20, deserialized.Faces.First().BoundingBox.DownRight.Y);
            Assert.AreEqual(0.3, deserialized.Faces.First().Features[2]);
            Assert.AreEqual(this.sampleDate, deserialized.LastUpdatedOn);
            Assert.AreEqual(9, deserialized.TotalSteps);
            Assert.AreEqual(8, deserialized.LastStepCompleted);
        }
    }
}