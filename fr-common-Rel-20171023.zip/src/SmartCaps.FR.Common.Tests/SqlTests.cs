﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SmartCaps.FR.Common.Repos.SQLServer;
using SmartCaps.FR.Common.Model;
using System.Collections.Generic;

namespace SmartCaps.FR.Updater.Tests
{
    //[TestClass]
    //public class SqlTests
    //{
    //    [TestMethod]
    //    public void TempTest()
    //    {
    //        string connStr = @"Data Source=.\SQLEXPRESS;Initial Catalog=SmartCaps.FR;Integrated Security=True";
    //        SQLServerFaceRepository repo = new SQLServerFaceRepository(connStr, null);

    //        IList<ImageRef> images = new List<ImageRef>();
    //        images.Add(new ImageRef() { Id = "f9T1uxXQRGsXiS09RYkooQ2.jpg", RefType = ImageRefTypes.FILESYS });
    //        images.Add(new ImageRef() { Id = "QthQpOgzWPqdRun_kr9mPA2.jpg", RefType = ImageRefTypes.FILESYS }); // "8nNCDP-3J4Z_AY5b2Wy98A2.jpg"
    //        images.Add(new ImageRef() { Id = "8nNCDP-3J4Z_AY5b2Wy98A2.jpg", RefType = ImageRefTypes.FILESYS }); // "8nNCDP-3J4Z_AY5b2Wy98A2.jpg"

    //        IList<string> tags = new List<string>();
    //        tags.Add("TestTag3");
    //        tags.Add("TestTag1");

    //        var kk = repo.GetAllFaces(images, tags, null, 0, 100);
    //    }
    //}
}
