﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SmartCaps.FR.Common.MimeTypes;

namespace SmartCaps.FR.Updater.Tests
{
    [TestClass]
    public class MimeTypesTests
    {
        [TestMethod]
        public void GetMimeTypeByExtension_video_wmv_Success()
        {
            // Arrange
            var videoMimeTypes = new VideoMimeTypes();

            // Exec
            string result = videoMimeTypes.GetMimeTypeFromExtension("wmv");

            // Assert
            Assert.AreEqual("video/x-ms-wmv", result);
        }

        [TestMethod]
        public void GetMimeTypeByExtension_image_png_Success()
        {
            // Arrange
            var imageMimeTypes = new ImageMimeTypes();

            // Exec
            string result = imageMimeTypes.GetMimeTypeFromExtension("png");

            // Assert
            Assert.AreEqual("image/png", result);
        }

        [TestMethod]
        public void GetMimeTypeByExtension_image_png_withDot_Success()
        {
            // Arrange
            var imageMimeTypes = new ImageMimeTypes();

            // Exec
            string result = imageMimeTypes.GetMimeTypeFromExtension(".gif");

            // Assert
            Assert.AreEqual("image/gif", result);
        }

        [TestMethod]
        public void Helper_GetMimeTypeByExtension_image_and_video_Success()
        {
            // Arrange
            var mimeTypes = new MimeTypesHelper();

            // Exec
            string jpgResult = mimeTypes.GetMimeTypeFromExtension("jpg");
            string wmvResult = mimeTypes.GetMimeTypeFromExtension(".avi");

            // Assert
            Assert.AreEqual("image/jpeg", jpgResult);
            Assert.AreEqual("video/x-msvideo", wmvResult);
        }

    }
}
