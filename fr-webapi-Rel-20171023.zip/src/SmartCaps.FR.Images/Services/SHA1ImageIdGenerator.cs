﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace SmartCaps.FR.Images.Services
{
    public class SHA1ImageIdGenerator : IImageIdGenerator
    {
        private SHA1CryptoServiceProvider hashProvider;

        public SHA1ImageIdGenerator()
        {
            this.hashProvider = new SHA1CryptoServiceProvider();
        }

        public string GenerateImageId(byte[] image)
        {
            string hash = HttpServerUtility.UrlTokenEncode(this.hashProvider.ComputeHash(image));

            return hash;
        }
    }
}
