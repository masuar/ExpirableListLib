﻿using log4net;
using SmartCaps.FR.Images.Model;
using SmartCaps.FR.Images.Repositories;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace SmartCaps.FR.Images.Services
{
    public class ImageServices
    {
        private ImageRepositorySelector imageRepoSelector;
        private ILog log;

        public ImageServices(ImageRepositorySelector imageRepoSelector, ILog log)
        {
            this.imageRepoSelector = imageRepoSelector;
            this.log = log;
        }

        public bool ValidateImage(string imageId, string imageRefType)
        {
            IImageRepository imgRepo = this.imageRepoSelector.GetImageRepository(imageRefType);
            return imgRepo.IsValidImage(imageId);
        }

        public string SaveImage(string imageRefType, byte[] imageBytes, string originalFileName, ImageMetadata metadata)
        {
            IImageRepository imgRepo = this.imageRepoSelector.GetImageRepository(imageRefType);
            return imgRepo.SaveImage(imageBytes, originalFileName, metadata);
        }

        public string GetImagePath(string imageId, string imageRefType)
        {
            IImageRepository imgRepo = this.imageRepoSelector.GetImageRepository(imageRefType);
            return imgRepo.GetImagePath(imageId);
        }

        public void DropImage(string imageRefType, string imageId)
        {
            IImageRepository imgRepo = this.imageRepoSelector.GetImageRepository(imageRefType);
            imgRepo.DropImage(imageId);
        }

    }
}