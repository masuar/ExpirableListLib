﻿using log4net;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using SmartCaps.FR.Common.MimeTypes;
using SmartCaps.FR.Images.Model;
using SmartCaps.FR.Images.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Images.Repositories.FileSystem
{
    public class FileSystemImageRepository : IImageRepository
    {
        private string rootFolder;
        private IImageIdGenerator imageIdGenSvc;
        private ILog log;
        private MimeTypesHelper mimeTypesHelper = new MimeTypesHelper();

        public FileSystemImageRepository(string rootFolder, IImageIdGenerator imageIdGenSvc, ILog log)
        {
            this.rootFolder = rootFolder;
            this.imageIdGenSvc = imageIdGenSvc;
            this.log = log;
        }

        public bool IsValidImage(string id)
        {
            string thePath = this.GetRealPath(id);
            string extension = Path.GetExtension(thePath).ToLower();
            return this.mimeTypesHelper.IsExtensionSupported(extension);
        }

        public bool DoesImageExist(string id)
        {
            string thePath = this.GetRealPath(id);
            return File.Exists(thePath);
        }

        public byte[] GetImageFrom(string id)
        {
            byte[] result = null;
            if (this.DoesImageExist(id))
            {
                result = File.ReadAllBytes(this.GetRealPath(id));
            }

            return result;
        }

        public IDictionary<string, ImageMetadata> GetImagesFromMetadata(ImageMetadata metadata)
        {
            IDictionary<string, ImageMetadata> result = new Dictionary<string, ImageMetadata>();

            if (metadata!= null)
            {
                var kvpConverter = new KeyValuePairConverter();
                var allMetadataFiles = Directory.GetFiles(this.rootFolder, "*.json");
                foreach (string fileName in allMetadataFiles)
                {
                    try
                    {
                        string json = File.ReadAllText(Path.Combine(this.rootFolder, fileName));
                        var metadataRead = JsonConvert.DeserializeObject<ImageMetadata>(json, new KeyValuePairConverter());
                        if (metadataRead.Intersect(metadata).Count() == metadata.Count)
                        {
                            result.Add(metadataRead["ImageId"], metadataRead);
                        }
                    }
                    catch (Exception ex)
                    {
                        this.log.Warn("Metadata error", ex);
                    }
                }
            }

            return result;
        }

        public ImageMetadata GetMetadataFrom(string id)
        {
            ImageMetadata result = new ImageMetadata();
            if (this.DoesImageExist(id))
            {
                string thePath = this.GetRealPath(id);
                thePath = Path.ChangeExtension(thePath, ".json");
                if (File.Exists(thePath))
                {
                    string json = File.ReadAllText(thePath);
                    result = new ImageMetadata();

                    try
                    {
                        var temp = JsonConvert.DeserializeObject<ImageMetadata>(json, new KeyValuePairConverter());
                        foreach (var item in temp)
                        {
                            result.Add(item.Key, item.Value);
                        }
                    }
                    catch (Exception ex)
                    {
                        this.log.Warn("Exception happen when retrieving metadata from FileSys.", ex);
                    }
                }
            }

            return result;
        }

        public string SaveImage(byte[] image, string originalFileName, ImageMetadata metadata)
        {
            string extension = Path.GetExtension(originalFileName).ToLower();
            string imageId = Path.ChangeExtension(this.imageIdGenSvc.GenerateImageId(image), extension);

            if (!this.DoesImageExist(imageId) && this.IsValidImage(imageId))
            {
                string filePath = Path.Combine(this.rootFolder, imageId);
                try
                {
                    File.WriteAllBytes(filePath, image);
                    // this.AddMetadataTo(imageId, new ImageMetadata(new string[] {"First upload:","" }))
                }
                catch(Exception ex)
                {
                    this.log.Error(ex);
                }
            }

            this.AddMetadataTo(imageId, this.GenerateFileMetadata(originalFileName, imageId));
            this.AddMetadataTo(imageId, metadata);

            return imageId;
        }

        public ImageMetadata AddMetadataTo(string imageId, ImageMetadata metadata)
        {
            if (!this.DoesImageExist(imageId))
            {
                throw new ArgumentException("Image does not exist.");
            }

            var kvpConv = new KeyValuePairConverter();
            ImageMetadata oldMetadata = this.GetMetadataFrom(imageId);
            oldMetadata.AddOrUpdate(metadata);

            string newMetadata = JsonConvert.SerializeObject(oldMetadata, Formatting.Indented, kvpConv);
            string filePath = Path.Combine(this.rootFolder, imageId);
            filePath = Path.ChangeExtension(filePath, "json");
            File.WriteAllText(filePath, newMetadata);

            return oldMetadata;
        }

        public string GetImagePath(string id)
        {
            return this.GetRealPath(id);
        }

        private string GetRealPath(string id)
        {
            return Path.Combine(this.rootFolder, id);
        }

        private ImageMetadata GenerateFileMetadata(string originalFileName, string imageId)
        {
            ImageMetadata metadata = new ImageMetadata();
            metadata.Add("Stored in", "FILESYS");
            metadata.Add("Image id", imageId);
            metadata.Add("Original file name", originalFileName);

            return metadata;
        }

        public void DropImage(string imageId)
        {
            string filePath = Path.Combine(this.rootFolder, imageId);

            File.Delete(filePath);
            File.Delete(Path.ChangeExtension(filePath, "json"));
        }

        public bool IsMissingRepository()
        {
            return false;
        }
    }
}
