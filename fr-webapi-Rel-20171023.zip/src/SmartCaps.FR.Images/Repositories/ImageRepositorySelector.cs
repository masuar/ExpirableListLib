﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Images.Repositories
{
    public class ImageRepositorySelector 
    {
        private ILog log;
        private IDictionary<string, IImageRepository> repos;

        public ImageRepositorySelector(IDictionary<string, IImageRepository> repos, ILog log)
        {
            this.repos = repos;
            this.log = log;
        }

        public IImageRepository GetImageRepository(string imageRefType)
        {
            if (!this.repos.ContainsKey(imageRefType))
            {
                log.Error(string.Format("Invalid '{0}' image reference type.", imageRefType));
                return new MissingImageRepository(imageRefType);
            }

            return this.repos[imageRefType];
        }

        public IDictionary<string, IImageRepository> GetAllImageRepositories()
        {
            return this.repos;
        }

    }
}
