﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmartCaps.FR.Images.Model;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using Newtonsoft.Json.Converters;
using log4net;
using SmartCaps.FR.Common.MimeTypes;

namespace SmartCaps.FR.Images.Repositories.Ivas
{
    public class IvasImageRepository : IImageRepository
    {
        private string connString;
        private ILog log;
        private string basePath;
        private ImageMimeTypes mimeTypes = new ImageMimeTypes();
        
        // TODO: A lot of room for improvement here!
        private readonly string baseMetadataQuery = 
                        "SELECT T1.Id as FileId, T2.Id as EvidenceId, T2.MimeType, T2.FileType, T3.ImportPath + T1.OriginalDirectory + T1.FileName as FileName, " +
                            "T2.OffenderIdentified, T2.VictimIdentified, T2.ExifDateCreated, " +
                            "(SELECT TOP 1 ST.[Value] FROM Exif ST WHERE ST.ExifType = 31 AND ST.EvidenceId = T2.Id) AS ExifCameraMake, " +
                            "(SELECT TOP 1 ST.[Value] FROM Exif ST WHERE ST.ExifType = 32 AND ST.EvidenceId = T2.Id) AS ExifCameraModel, " +
                            "(SELECT TOP 1 ST.[Value] FROM Exif ST WHERE ST.ExifType = 33 AND ST.EvidenceId = T2.Id) AS ExifCameraSN, " +
                            "STUFF((SELECT ', ' + ST1.Identifier + ' (' + CAST(ST1.Id AS VARCHAR(10)) + ')'[text()] FROM [Case] ST1 JOIN CaseEvidence ST2 ON ST1.Id = ST2.CaseId WHERE ST2.EvidenceId = T2.Id FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,2,' ') Cases, " +
                            "STUFF((SELECT ', ' + ST3.[Name] [text()] FROM [Serie] ST3 JOIN EvidenceSerie ST4 ON ST3.Id = ST4.SerieId WHERE ST4.EvidenceId = T2.Id FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,2,' ') Series " +
                        "FROM ((EvidenceFile T1 JOIN Evidence T2 ON T1.EvidenceId = T2.Id) " +
                                "JOIN Source T3 ON T1.SourceId = T3.Id){0}";

        private class FileNameResult
        {
            public FileNameResult(string fileName, string mimeType)
            {
                this.FileName = fileName;
                this.MimeType = mimeType;
            }
            public string FileName { get; private set; }
            public string MimeType { get; private set; }
        }

        private class MetadataFilter
        {
            private IList<string> criteria;
            private IList<SqlParameter> parameters;

            public MetadataFilter()
            {
                this.criteria = new List<string>();
                this.parameters = new List<SqlParameter>();
            }

            public void AddFilter(string sqlCriteria, string paramName, object paramValue)
            {
                this.criteria.Add(sqlCriteria);
                this.parameters.Add(new SqlParameter(paramName, paramValue));
            }

            public string GetSqlWhereClause()
            {
                string whereClause = string.Empty;

                if (this.criteria.Count > 0)
                {
                    whereClause = " WHERE " + string.Join(" OR ", criteria);
                }

                return whereClause;
            }

            public IEnumerable<SqlParameter> Parameters
            {
                get
                {
                    return this.parameters;
                }
            }
        }

        public IvasImageRepository(string connString, string basePath, ILog log)
        {
            this.connString = connString;
            this.basePath = basePath;
            this.log = log;
        }

        public bool DoesImageExist(string id)
        {
            bool result = false;
            int intId = -1;

            if (int.TryParse(id, out intId))
            {
                FileNameResult fileResult = null;

                if (result)
                {
                    fileResult = this.GetFileName(intId);
                    result = fileResult != null;
                }

                if (result)
                {
                    result = File.Exists(fileResult.FileName);
                }
            }

            return result;
        }

        public byte[] GetImageFrom(string id)
        {
            byte[] result = null;
            int intId = -1;

            if (int.TryParse(id, out intId))
            {
                var fileNameResult = this.GetFileName(intId);
                if (fileNameResult != null)
                {
                    result = File.ReadAllBytes(fileNameResult.FileName);
                }
            }

            return result;
        }

        public IDictionary<string, ImageMetadata> GetImagesFromMetadata(ImageMetadata metadata)
        {
            IDictionary<string, ImageMetadata> result = new Dictionary<string, ImageMetadata>();

            if (metadata != null)
            {
                string metadataQuery = this.baseMetadataQuery;
                MetadataFilter filter = new MetadataFilter();

                int fileId = -1;
                if (metadata.ContainsKey("FileId") && !string.IsNullOrEmpty(metadata["FileId"]) && int.TryParse(metadata["FileId"], out fileId))
                {
                    filter.AddFilter("T2.Id = @FileId", "@FileId", fileId);
                }

                if (metadata.ContainsKey("MimeType") && !string.IsNullOrEmpty(metadata["MimeType"]))
                {
                    filter.AddFilter("T2.MimeType LIKE @MimeType", "@MimeType", metadata["MimeType"]);
                }

                if (metadata.ContainsKey("FileName") && !string.IsNullOrEmpty(metadata["FileName"]))
                {
                    filter.AddFilter("FileName LIKE @FileName", "@FileName", metadata["FileName"]);
                }

                if (metadata.ContainsKey("Cases") && !string.IsNullOrEmpty(metadata["Cases"]))
                {
                    filter.AddFilter("Cases LIKE @Cases", "@Cases", metadata["Cases"]);
                }

                if (metadata.ContainsKey("Series") && !string.IsNullOrEmpty(metadata["Series"]))
                {
                    filter.AddFilter("Series LIKE @Series", "@Series", metadata["Series"]);
                }

                metadataQuery = string.Format(metadataQuery, filter.GetSqlWhereClause());

                using (SqlConnection conn = new SqlConnection(this.connString))
                {
                    conn.Open();
                    using (SqlCommand theCommand = new SqlCommand(metadataQuery, conn))
                    {
                        if (filter.Parameters.Any())
                        {
                            theCommand.Parameters.AddRange(filter.Parameters.ToArray());
                        }

                        using (SqlDataReader reader = theCommand.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string fId = reader.GetSafeInt("FileId").ToString();
                                var meta = this.ComposeMetadataFromDataReader(reader);

                                result.Add(fId, meta);
                            }
                        }

                    }
                }
            }

            return result;
        }

        public ImageMetadata GetMetadataFrom(string id)
        {
            ImageMetadata result = new ImageMetadata();

            string metadataQuery = string.Format(this.baseMetadataQuery, " WHERE T2.Id = @FileId");

            using (SqlConnection conn = new SqlConnection(this.connString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(metadataQuery, conn))
                {
                    theCommand.Parameters.Add("@FileId", SqlDbType.Int).Value = id;
                    using (SqlDataReader reader = theCommand.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            result = this.ComposeMetadataFromDataReader(reader);
                        }
                    }

                }
            }

            return result;
        }

        public bool IsValidImage(string id)
        {
            bool result = false;
            int intId = -1;

            if (int.TryParse(id, out intId))
            {
                var fileResult = this.GetFileName(intId);
                if (fileResult != null)
                {
                    result = this.mimeTypes.IsSupported(fileResult.MimeType);
                }
            }

            return result;
        }

        public string GetImagePath(string id)
        {
            string result = null;
            int intId = -1;

            if (int.TryParse(id, out intId))
            {
                var fileResult = this.GetFileName(intId);
                if (fileResult != null)
                {
                    result = fileResult.FileName;
                }
            }

            return result;
        }

        #region Not supported operations
        public void DropImage(string imageId)
        {
            throw new NotSupportedException("This operation is not supported for Twins.");
        }

        public bool IsMissingRepository()
        {
            return false;
        }

        public ImageMetadata AddMetadataTo(string id, ImageMetadata metadata)
        {
            throw new NotSupportedException("This operation is not supported for Twins.");
        }

        public string SaveImage(byte[] image, string originalFileName, ImageMetadata metadata)
        {
            throw new NotSupportedException("This operation is not supported for Twins.");
        }
        #endregion

        private FileNameResult GetFileName(int id)
        {
            FileNameResult result = null;
            this.log.Debug("Starting to get the file name from IVAS...");

            string imageFileNameQuery = "SELECT T1.Id, " +
                                           "T1.SHA1, " +
                                           "T1.ExtensionOriginal, " +
                                           "T1.MimeType " +
                                       "FROM Evidence as T1 " +
                                       "WHERE T1.Id = @FileId";

            using (SqlConnection conn = new SqlConnection(this.connString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(imageFileNameQuery, conn))
                {
                    theCommand.Parameters.Add("@FileId", SqlDbType.Int).Value = id;
                    using (SqlDataReader reader = theCommand.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            try
                            {
                                string extension = reader.GetSafeString("ExtensionOriginal");
                                this.log.Debug("Getting SHA1 value from IVAS db...");
                                string shaHex = BitConverter.ToString(reader.GetSafeByteArray("SHA1")).Replace("-", string.Empty);
                                this.log.Debug("SHA1 value got.");
                                string theFilePath = this.GetFilePath(this.basePath, shaHex, extension);

                                result = new FileNameResult(theFilePath, reader.GetSafeString("MimeType"));
                            }
                            catch (Exception ex)
                            {
                                this.log.Warn(string.Format("Unable to get file from evidence id '{0}'", id), ex);
                            }


                            
                        }
                    }
                }
            }
            this.log.Debug("Name got from IVAS.");
            return result;
        }

        private string GetFilePath(string basePath, string shaHex, string extension)
        {
            string result = null;

            if (!string.IsNullOrEmpty(shaHex))
            {
                string folder1 = shaHex.Substring(0, 2);
                string folder2 = shaHex.Substring(2, 2);
                string folder3 = shaHex.Substring(4, 2);
                string folder4 = shaHex.Substring(6, 2);

                if (!string.IsNullOrEmpty(extension) && extension.Trim().Substring(0,1)!=".")
                {
                    extension = "." + extension.Trim();
                }

                result = Path.Combine(basePath, folder1, folder2, folder3, folder4, shaHex + extension);
            }

            return result;
        }

        private ImageMetadata ComposeMetadataFromDataReader(IDataReader reader)
        {
            ImageMetadata result = new Model.ImageMetadata();
            result.Add("Source system", "IVAS");
            result.Add("Stored in", "IVAS");

            try
            {
                result.Add("Evidence Id", reader.GetSafeInt("EvidenceId").ToString());
                result.Add("Mime type", reader.GetSafeString("MimeType"));
                result.Add("File name", reader.GetSafeString("FileName"));
                result.Add("Vic. / Off. identified", string.Format("{0}/{1}", reader.GetSafeBool("VictimIdentified").ToString(), reader.GetSafeBool("OffenderIdentified").ToString()));
                result.Add("Exif date created", reader.GetSafeDateTime("ExifDateCreated").ToString());
                result.Add("Exif cam. make / model", string.Format("{0}/{1}", reader.GetSafeString("ExifCameraMake"), reader.GetSafeString("ExifCameraModel")));
                result.Add("Exif cam. SN", reader.GetSafeString("ExifCameraSN"));
                result.Add("Cases", reader.GetSafeString("Cases"));
                result.Add("Series", reader.GetSafeString("Series"));
            }
            catch (Exception ex)
            {
                this.log.Warn("Exception happen when retrieving metadata from Twins.", ex);
            }

            return result;
        }
    }

    internal static class DataReaderExtensions
    {
        public static string GetSafeString(this IDataReader dr, string fieldName)
        {
            string result = "-";
            int index = dr.GetOrdinal(fieldName);

            if (!dr.IsDBNull(index))
            {
                result = dr.GetString(index);
            }

            return result;
        }

        public static bool GetSafeBool(this IDataReader dr, string fieldName)
        {
            bool result = false;

            int index = dr.GetOrdinal(fieldName);

            if (!dr.IsDBNull(index))
            {
                result = dr.GetBoolean(index);
            }

            return result;
        }

        public static DateTime GetSafeDateTime(this IDataReader dr, string fieldName)
        {
            DateTime result = new DateTime(1970, 1, 1);
            int index = dr.GetOrdinal(fieldName);

            if (!dr.IsDBNull(index))
            {
                result = dr.GetDateTime(index);
            }

            return result;
        }

        public static int GetSafeInt(this IDataReader dr, string fieldName)
        {
            int result = 0;
            int index = dr.GetOrdinal(fieldName);

            if (!dr.IsDBNull(index))
            {
                result = dr.GetInt32(index);
            }

            return result;
        }

        public static double GetSafeDouble(this IDataReader dr, string fieldName)
        {
            double result = 0d;
            int index = dr.GetOrdinal(fieldName);

            if (!dr.IsDBNull(index))
            {
                result = dr.GetDouble(index);
            }

            return result;
        }

        public static byte[] GetSafeByteArray(this IDataReader dr, string fieldName)
        {
            byte[] result = null;
            int index = dr.GetOrdinal(fieldName);

            if (!dr.IsDBNull(index))
            {
                result = (byte[])dr[fieldName];
            }

            return result;
        }


        public static bool ColumnExists(this IDataReader dr, string fieldName)
        {
            for (int i = 0; i < dr.FieldCount; i++)
            {
                if (dr.GetName(i).Equals(fieldName, StringComparison.InvariantCultureIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }
    }
}
