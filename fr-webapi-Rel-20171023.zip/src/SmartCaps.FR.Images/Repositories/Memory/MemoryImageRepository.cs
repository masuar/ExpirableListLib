﻿using log4net;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using SmartCaps.FR.Images.Model;
using SmartCaps.FR.Images.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Images.Repositories.Memory
{
    public class MemoryImageRepository : IImageRepository
    {
        private class MemImage
        {
            public string Id { get; set; }
            public byte[] Image { get; set; }
            public ImageMetadata Metadata { get; set; }
        }

        private IDictionary<string, MemImage> data;
        private IImageIdGenerator imageIdGen;
        private ILog log;

        public MemoryImageRepository(IImageIdGenerator imageIdGen, ILog log)
        {
            this.data = new Dictionary<string, MemImage>();
            this.imageIdGen = imageIdGen;
            this.log = log;
        }

        public bool IsValidImage(string id)
        {
            return true;
        }

        public bool DoesImageExist(string id)
        {
            return this.data.ContainsKey(id);
        }

        public byte[] GetImageFrom(string id)
        {
            byte[] result = null;
            if (this.data.ContainsKey(id))
            {
                result = this.data[id].Image;
            }
            return result;
        }

        public IDictionary<string, ImageMetadata> GetImagesFromMetadata(ImageMetadata metadata)
        {
            IDictionary<string, ImageMetadata> result = new Dictionary<string, ImageMetadata>();
            var list = this.data.Values.Where(mi => mi.Metadata.Intersect(metadata).Any()).Select(mi => new KeyValuePair<string,ImageMetadata>(mi.Id, mi.Metadata));

            foreach(var item in list)
            {
                result.Add(item);
            }

            return result;
        }

        public ImageMetadata GetMetadataFrom(string id)
        {
            ImageMetadata result = null;
            if (this.data.ContainsKey(id))
            {
                result = this.data[id].Metadata;
            }
            return result;
        }

        public string SaveImage(byte[] image, string originalFileName, ImageMetadata metadata)
        {
            string id = this.imageIdGen.GenerateImageId(image);
            ImageMetadata generatedMetadata = this.GenerateMetadata(id, originalFileName);
            generatedMetadata.AddOrUpdate(metadata);
            if (this.data.ContainsKey(id))
            {
                this.data[id].Image = image;
                this.data[id].Metadata.AddOrUpdate(generatedMetadata);
            }
            else
            {
                this.data.Add(id, new MemImage() { Id = id, Image = image, Metadata = generatedMetadata });
            }

            return id;
        }

        public ImageMetadata AddMetadataTo(string id, ImageMetadata metadata)
        {
            if (this.data.ContainsKey(id))
            {
                this.data[id].Metadata.AddOrUpdate(metadata);
            }
            else
            {
                this.data.Add(id, new MemImage() { Id = id, Metadata = metadata });
            }

            return metadata;
        }

        private ImageMetadata GenerateMetadata(string imageId, string originalFileName)
        {
            ImageMetadata metadata = new ImageMetadata();

            metadata.Add("ImageId", imageId);
            metadata.Add("OriginalFileName", originalFileName);

            return metadata;
            // return JsonConvert.SerializeObject(metadata, new KeyValuePairConverter());
        }

        public void DropImage(string imageId)
        {
            this.data.Remove(imageId);
        }

        public bool IsMissingRepository()
        {
            return false;
        }

        public string GetImagePath(string id)
        {
            throw new NotSupportedException();
        }
    }
}
