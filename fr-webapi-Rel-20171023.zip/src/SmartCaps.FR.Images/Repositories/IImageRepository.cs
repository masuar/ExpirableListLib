﻿using SmartCaps.FR.Images.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Images.Repositories
{
    public interface IImageRepository
    {
        bool IsValidImage(string id);

        bool DoesImageExist(string id);

        byte[] GetImageFrom(string id);

        string GetImagePath(string id);

        IDictionary<string, ImageMetadata> GetImagesFromMetadata(ImageMetadata metadata);

        ImageMetadata GetMetadataFrom(string id);

        string SaveImage(byte[] image, string originalFileName, ImageMetadata metadata);

        ImageMetadata AddMetadataTo(string id, ImageMetadata metadata);

        void DropImage(string imageId);

        bool IsMissingRepository();
    }
}
