﻿using System.Collections.Generic;
using System.IO;
using System.Reflection;
using SmartCaps.FR.Images.Model;

namespace SmartCaps.FR.Images.Repositories
{
    public class MissingImageRepository : IImageRepository
    {
        private readonly string missingRepositoryName;

        public MissingImageRepository(string missingRepositoryName)
        {
            this.missingRepositoryName = missingRepositoryName;
        }

        public bool IsValidImage(string id)
        {
            return false;
        }

        public bool DoesImageExist(string id)
        {
            return  true;
        }

        public byte[] GetImageFrom(string id)
        {
            string path = System.Web.HttpContext.Current.Request.MapPath("../../bin/images/imageNotFound.png");
            return System.IO.File.ReadAllBytes(path);
        }

        public string GetImagePath(string id)
        {
            throw new System.NotImplementedException();
        }

        public IDictionary<string, ImageMetadata> GetImagesFromMetadata(ImageMetadata metadata)
        {
            IDictionary<string, ImageMetadata> result = new Dictionary<string, ImageMetadata>();
            var imageMetada =
                new ImageMetadata(new Dictionary<string, string>{{"Missing image repository", missingRepositoryName}});
            result.Add("ImageInfo", imageMetada);
            return result;
        }

        public ImageMetadata GetMetadataFrom(string id)
        {
            var imageMetada =
                new ImageMetadata(new Dictionary<string, string> { { "Missing image repository", missingRepositoryName } });
            return imageMetada;
        }

        public string SaveImage(byte[] image, string originalFileName, ImageMetadata metadata)
        {
            throw new System.NotImplementedException();
        }

        public ImageMetadata AddMetadataTo(string id, ImageMetadata metadata)
        {
            throw new System.NotImplementedException();
        }

        public void DropImage(string imageId)
        {
            throw new System.NotImplementedException();
        }

        public bool IsMissingRepository()
        {
            return true;
        }
    }
}