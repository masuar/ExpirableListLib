﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Images.Model
{
    public class ImageMetadata : SortedDictionary<string,string>
    {
        private readonly char splitChar = '|';

        public ImageMetadata(string[] from)
        {
            if (from != null)
            {
                foreach (string item in from)
                {
                    string[] kvp = item.Split(splitChar);
                    if (kvp.Length >= 2)
                    {
                        this.Add(WebUtility.UrlDecode(kvp[0]), WebUtility.UrlDecode(kvp[1]));
                    }
                }
            }
        }

        public ImageMetadata(IDictionary<string,string> from)
        {
            if (from != null)
            {
                foreach (var kvp in from)
                {
                    this.Add(kvp.Key, kvp.Value);
                }
            }
        }

        public ImageMetadata()
            : this((string[])null)
        {
        }

        public void AddOrUpdate(string key, string value)
        {
            if (this.ContainsKey(key))
            {
                this[key] = value;
            }
            else
            {
                this.Add(key, value);
            }
        }

        public void AddOrUpdate(ImageMetadata metadataToAdd)
        {
            foreach(var kvp in metadataToAdd)
            {
                this.AddOrUpdate(kvp.Key, kvp.Value);
            }
        }

    }
}
