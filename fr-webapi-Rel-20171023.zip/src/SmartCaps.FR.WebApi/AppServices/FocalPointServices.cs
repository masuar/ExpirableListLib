﻿using log4net;
using SmartCaps.FR.Common.Repos;
using SmartCaps.FR.WebApi.Cache;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SmartCaps.FR.WebApi.AppServices
{
    public class FocalPointServices
    {
        private ILog log;
        private IFocalPointRepository focalPointsRepo;
        private ICacheStore cache;

        public FocalPointServices(IFocalPointRepository focalPointsRepo, ICacheStore cache, ILog log)
        {
            this.focalPointsRepo = focalPointsRepo;
            this.cache = cache;
            this.log = log;
        }

        public IEnumerable<string> GetAllFocalPoints()
        {
            var focalPoints = this.cache.Get<IEnumerable<string>>("focalPoints");

            if (focalPoints == null)
            {
                focalPoints = this.focalPointsRepo.GetFocalPoints();
                this.cache.Add("focalPoints", focalPoints);
            }

            return focalPoints;
        }


    }
}