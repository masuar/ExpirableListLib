﻿using log4net;
using SmartCaps.FR.Common.Model;
using SmartCaps.FR.Common.Repos;
using SmartCaps.FR.Images.Model;
using SmartCaps.FR.Images.Repositories;
using SmartCaps.FR.WebApi.Cache;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Web;

namespace SmartCaps.FR.WebApi.AppServices
{
    public class FaceServices
    {
        private ILog log;
        private bool blurred = true;
        private IFaceRepository faceRepo;
        private ImageRepositorySelector imageRepoSelector;
        private ICacheStore dataCache;
        private ICacheStore imgCache;
        private static object locker = new object();

        public FaceServices(IFaceRepository faceRepo, ImageRepositorySelector imageRepoSelector, ICacheStore dataCache, ICacheStore imgCache, bool blurred, ILog log)
        {
            this.faceRepo = faceRepo;
            this.imageRepoSelector = imageRepoSelector;
            this.blurred = blurred;
            this.log = log;
            this.dataCache = dataCache;
            this.imgCache = imgCache;
        }

        public Face GetFaceDataById(string id, bool includeMetadata, bool includeFeatures)
        {
            Face theFace = this.faceRepo.GetFaceById(id, includeFeatures);
            if (theFace != null)
            {
                if (includeMetadata)
                {
                    ImageRef theRef = theFace.ImageRef;
                    IImageRepository theImageRepo = this.imageRepoSelector.GetImageRepository(theRef.RefType.ToString());
                    theFace.Metadata = theImageRepo.GetMetadataFrom(theRef.Id);
                }
            }

            return theFace;
        }

        public IEnumerable<Face> GetFacesData(ImageMetadata metadata, string owner, IEnumerable<string> tags, IEnumerable<string> sienaRefs, IEnumerable<string> focalPoints, bool? confirmed, bool includeMetadata, bool includeFeatures, int pageIndex, int pageSize)
        {
            List<Face> result = new List<Face>();
            IDictionary<ImageRef, IDictionary<string, string>> imagesInfo = new Dictionary<ImageRef, IDictionary<string, string>>();
            if (metadata != null && metadata.Count > 0)
            {
                foreach (var imgRepo in this.imageRepoSelector.GetAllImageRepositories())
                {
                    foreach (var kvp in imgRepo.Value.GetImagesFromMetadata(metadata))
                    {
                        imagesInfo.Add(new ImageRef() { Id = kvp.Key, RefType = (ImageRefTypes)Enum.Parse(typeof(ImageRefTypes), imgRepo.Key, ignoreCase: true) }, kvp.Value as IDictionary<string, string>);
                    }
                }

                if (imagesInfo != null && imagesInfo.Count() > 1000)
                {
                    throw new ArgumentException("Too many images satisfy the search criteria. Please narrow down the search.");
                }
            }

            if (metadata != null && metadata.Count > 0 && imagesInfo.Count > 0)
            {
                result.AddRange(this.faceRepo.GetFaces(imagesInfo, owner, tags, sienaRefs, focalPoints, confirmed, includeFeatures, pageIndex, pageSize));
            }
            else if (metadata == null || metadata.Count == 0)
            {
                result.AddRange(this.faceRepo.GetFaces(imagesInfo, owner, tags, sienaRefs, focalPoints, confirmed, includeFeatures, pageIndex, pageSize));
                if (includeMetadata)
                {
                    foreach (Face theFace in result)
                    {
                        ImageRef theRef = theFace.ImageRef;
                        IImageRepository theImageRepo = this.imageRepoSelector.GetImageRepository(theRef.RefType.ToString());
                        theFace.Metadata = theImageRepo.GetMetadataFrom(theRef.Id);
                    }
                }
            }

            return result;
        }

        public int GetFacesCount(ImageMetadata metadata, string owner, IEnumerable<string> tags, IEnumerable<string> sienaRefs, IEnumerable<string> focalPoints, bool? confirmed)
        {
            IList<ImageRef> images = new List<ImageRef>();

            if (metadata != null && metadata.Count > 0)
            {
                foreach (var imgRepo in this.imageRepoSelector.GetAllImageRepositories())
                {
                    foreach (var kvp in imgRepo.Value.GetImagesFromMetadata(metadata))
                    {
                        images.Add(new ImageRef() { Id = kvp.Key, RefType = (ImageRefTypes)Enum.Parse(typeof(ImageRefTypes), imgRepo.Key, ignoreCase: true) });
                    }
                }

                if (images != null && images.Count() > 1000)
                {
                    throw new ArgumentException("Too many images satisfy the search criteria. Please narrow down the search.");
                }
            }


            return this.faceRepo.GetFacesCount(images, owner, tags, sienaRefs, focalPoints, confirmed);
        }

        public byte[] GetFaceImageById(string id, bool full)
        {
            byte[] result = null;

            Face theFace = this.faceRepo.GetFaceById(id, includeFeatures: false);
            if (theFace != null)
            {
                Image target = null;
                bool isDefault = false;
                Rectangle faceRect;
                Bitmap original = this.GetOriginalImage(theFace.ImageRef, out isDefault);

                if (!isDefault)
                {
                    faceRect = this.GetFaceRectangle(theFace);
                }
                else
                {
                    this.SetDefaultImage(out original, out faceRect);
                }

                if (full)
                {
                    target = this.DrawRectangleInFullImage(original, faceRect, this.blurred);
                }
                else
                {
                    target = this.DrawSmallImage(original, faceRect, this.blurred);
                }
                result = this.ImageToByteArray(target);
            }

            return result;
        }

        private byte[] GetFullImage(string id)
        {
            byte[] result = null;

            Face theFace = this.faceRepo.GetFaceById(id, includeFeatures: false);
            if (theFace != null)
            {
                Image target = null;
                bool isDefault = false;
                Rectangle faceRect;
                Bitmap original = this.GetOriginalImage(theFace.ImageRef, out isDefault);

                if (!isDefault)
                {
                    faceRect = this.GetFaceRectangle(theFace);
                }
                else
                {
                    this.SetDefaultImage(out original, out faceRect);
                }

                target = this.DrawRectangleInFullImage(original, faceRect, this.blurred);
                result = this.ImageToByteArray(target);
            }

            return result;

        }

        private Rectangle GetFaceRectangle(Face theFace)
        {
            string rectCacheKey = string.Format("rect_{0}", theFace.Id);
            Rectangle faceRect = this.imgCache.Get<Rectangle>(rectCacheKey);

            if (faceRect.IsEmpty)
            {
                try
                {
                    faceRect = new Rectangle(
                                theFace.BoundingBox.TopLeft.X,
                                theFace.BoundingBox.TopLeft.Y,
                                theFace.BoundingBox.Height,
                                theFace.BoundingBox.Width);
                    this.imgCache.Add(rectCacheKey, faceRect);
                }
                catch (Exception ex)
                {
                    this.log.Warn("Unable to get image rectangle.", ex);
                }
            }

            return faceRect;
        }

        private Bitmap GetOriginalImage(ImageRef imageRef, out bool isDefault)
        {

            string imgCacheKey = string.Format("img_{0}", imageRef.Id);
            Bitmap original = this.imgCache.Get<Bitmap>(imgCacheKey);
            isDefault = false;

            if (original == null)
            {
                IImageRepository theImageRepo = this.imageRepoSelector.GetImageRepository(imageRef.RefType.ToString());
                var resultingBytes = theImageRepo.GetImageFrom(imageRef.Id);
                if (theImageRepo.IsMissingRepository() || resultingBytes == null)
                {
                    isDefault = true;
                }
                else
                {
                    try
                    {
                        original = new Bitmap(Image.FromStream(new MemoryStream(resultingBytes)));
                        this.imgCache.Add(imgCacheKey, original);
                    }
                    catch (Exception ex)
                    {
                        this.log.Warn("Unable to load original image.", ex);
                        isDefault = true;
                    }
                }
            }

            return original;
        }

        public bool SetFaceOwner(string id, string owner)
        {
            return this.faceRepo.SetFaceOwner(id, owner);
        }

        public bool SetFaceConfirmation(string id, bool confirmed)
        {
            return this.faceRepo.SetFaceConfirmation(id, confirmed);
        }

        public bool SetFaceTags(string id, IList<string> tags)
        {
            return this.faceRepo.SetFaceTags(id, tags.Where(t => !string.IsNullOrEmpty(t)).Select(t => t.Trim().ToLower()).Distinct().ToList());
        }

        public bool SetSienaRefs(string id, IList<string> sienaRefs)
        {
            return this.faceRepo.SetFaceSienaRefs(id, sienaRefs.Where(s => !string.IsNullOrEmpty(s)).Select(s => s.Trim().ToLower()).Distinct().ToList());
        }

        public bool SetFocalPoints(string id, IList<string> focalPoints)
        {
            return this.faceRepo.SetFaceFocalPoints(id, focalPoints.Where(fp => !string.IsNullOrEmpty(fp)).Select(fp => fp.Trim().ToLower()).Distinct().ToList());
        }

        public IDictionary<string, string> SetFaceMetadata(string id, IDictionary<string, string> metadata)
        {
            IDictionary<string, string> result = null;
            var face = this.faceRepo.GetFaceById(id, false);
            if (face != null)
            {
                ImageRef imgRef = face.ImageRef;
                IImageRepository imgRepo = this.imageRepoSelector.GetImageRepository(imgRef.RefType.ToString());
                result = imgRepo.AddMetadataTo(imgRef.Id, new ImageMetadata(metadata));
            }

            return result;
        }

        public bool RemoveFaceById(string id)
        {
            bool result = this.faceRepo.RemoveFaceById(id);

            return result;
        }

        public IEnumerable<string> GetSienaRefsFromFaces()
        {
            var sienaRefs = this.dataCache.Get<IEnumerable<string>>("sienaRefs");

            if (sienaRefs == null)
            {
                sienaRefs = this.faceRepo.GetSienaRefsFromFaces();
                this.dataCache.Add("sienaRefs", sienaRefs);
            }

            return sienaRefs;
        }

        public IEnumerable<string> GetTagsFromFaces()
        {
            var tags = this.dataCache.Get<IEnumerable<string>>("tags");

            if (tags == null)
            {
                tags = this.faceRepo.GetTagsFromFaces();
                this.dataCache.Add("tags", tags);
            }

            return tags;
        }

        public IEnumerable<string> GetOwnersFromFaces()
        {
            var owners = this.dataCache.Get<IEnumerable<string>>("owners");

            if (owners == null)
            {
                owners = this.faceRepo.GetOwnersFromFaces();
                this.dataCache.Add("owners", owners);
            }

            return owners;
        }


        private byte[] ImageToByteArray(Image image)
        {
            ImageConverter converter = new ImageConverter();
            return (byte[])converter.ConvertTo(image, typeof(byte[]));
        }

        private Image DrawSmallImage(Image original, Rectangle faceRect, bool blurred)
        {
            lock (locker)
            {
                Bitmap target = new Bitmap(faceRect.Width, faceRect.Height);
                using (Graphics g = Graphics.FromImage(target))
                {
                    g.DrawImage(original, new Rectangle(0, 0, target.Width, target.Height), faceRect, GraphicsUnit.Pixel);
                }

                if (blurred)
                {
                    target = target.ImageBlurFilter();
                }
                return target;
            }
        }

        private Image DrawRectangleInFullImage(Bitmap original, Rectangle faceRect, bool blurred)
        {
            lock (locker)
            {
                Bitmap target = new Bitmap(original, original.Width, original.Height);
                using (Graphics g = Graphics.FromImage(target))
                {
                    g.DrawRectangle(new Pen(Color.Red, 2), faceRect);
                }

                if (blurred)
                {
                    target = target.ImageBlurFilter();
                }

                return target;
            }
        }

        private void SetDefaultImage(out Bitmap original, out Rectangle faceRect)
        {
            string defaultImagePath = System.Web.HttpContext.Current.Request.MapPath("~/Images/imageNotAvailable.jpg");
            original = new Bitmap(Image.FromFile(defaultImagePath));
            faceRect = new Rectangle(0, 0, original.Width, original.Height);
        }

    }
}