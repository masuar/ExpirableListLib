﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.WebApi.AppServices
{
    public interface IRequestingUserServices
    {
        string GetRequestingUserName(HttpRequestMessage request);
    }
}
