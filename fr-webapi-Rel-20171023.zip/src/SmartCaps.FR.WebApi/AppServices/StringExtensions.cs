﻿using System.Linq;

namespace SmartCaps.FR.WebApi.AppServices
{
    using System.Collections.Generic;
    using System.Text.RegularExpressions;

    public static class StringExtensions
    {
        public static bool ContainsHtml(this IEnumerable<string> sourceStringList)
        {
            Regex tagRegex = new Regex(@"<\s*([\/?)w+]*)");
            return sourceStringList.ToList().Any(x => !string.IsNullOrEmpty(x) && tagRegex.IsMatch(x));
        }

        public static bool ContainsHtml(this string sourceString)
        {
            Regex tagRegex = new Regex(@"<\s*([\/?)w+]*)");
            return tagRegex.IsMatch(sourceString);
        }
    }
}