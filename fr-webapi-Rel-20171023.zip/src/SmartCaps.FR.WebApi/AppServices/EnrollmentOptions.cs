﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SmartCaps.FR.WebApi.AppServices
{
    public class EnrollOptions
    {
        public EnrollOptions()
        {
            this.Confirm = false;
            this.Tags = null;
        }

        /// <summary>
        /// RequestedBy value. You can provide the name of the entity who requested the enrollment operation. This entity will be set as owner of the
        /// enrolled face/s for future reference. Default is the process name.
        /// </summary>
        public string RequestedBy { get; set; }

        /// <summary>
        /// Confirmation value. True to mark the faces in the images as 'confirmed'. Default is False.
        /// </summary>
        public bool Confirm { get; set; }

        /// <summary>
        /// Tag value. You can provide a Tag (case sensitive) to set to the face/s at insertion. Also, you can provide several
        /// tags by providing several times the parameter in the query string. If not indicated, face/s will not be tagged.
        /// </summary>
        public string[] Tags { get; set; }

        /// <summary>
        /// Siena reference. You can provide a Siena number to set to the face/s at insertion. Also, you can provide several
        /// Siena numbers by providing several times the parameter in the query string. If not indicated, face/s will not be assigned to any Siena reference.
        /// </summary>
        public string[] SienaRefs { get; set; }

        /// <summary>
        /// Focal Point. You can provide a Focal Point to set to the face/s at insertion. Also, you can provide several
        /// Focal Points by providing several times the parameter in the query string. If not indicated, face/s will not be assigned to any Focal Point.
        /// </summary>
        public string[] FocalPoints { get; set; }

        /// <summary>
        /// Metadata associated to the face/s. You can provide a set of key/value pairs to be set to the face/s at insertion by providing several times the parameter in the query string. Use a pipe ('|') to separate key from value. 
        /// If not no key value pairs are indicated, face/s will not be having any Metadata.
        /// </summary>
        public string[] Metadata { get; set; }

        /// <summary>
        /// Faces which quality score is under this value won't be enrolled. Default is 0.85.
        /// </summary>
        public double FaceQualityScoreThreshold { get; set; }
    }

}