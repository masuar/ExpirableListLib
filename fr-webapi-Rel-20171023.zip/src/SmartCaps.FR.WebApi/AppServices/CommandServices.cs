﻿using log4net;
using Newtonsoft.Json;
using SmartCaps.FR.Common.Model;
using SmartCaps.FR.Common.Model.Commands;
using SmartCaps.FR.Common.Repos;
using SmartCaps.FR.Images.Services;
using SmartCaps.FR.NetMessaging.Services;
using SmartCaps.FR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;

namespace SmartCaps.FR.WebApi.AppServices
{
    public class CommandServices
    {
        private ICommandRepository commandsRepo;
        private IFaceRepository faceRepo;
        private IPublisherService publisher;
        private ImageServices imageServices;
        private int pollingTimeInMs;
        private string forbiddenChars; 
        private ILog log;

        public CommandServices(ICommandRepository commandsRepo, IFaceRepository faceRepo, IPublisherService publisher, ImageServices imageServices, int pollingTimeInMs, double defaultFaceQualityThreshold, string forbiddenChars, ILog log)
        {
            this.commandsRepo = commandsRepo;
            this.faceRepo = faceRepo;
            this.publisher = publisher;
            this.imageServices = imageServices;
            this.pollingTimeInMs = pollingTimeInMs;
            this.DefaultFaceQualityScoreThreshold = defaultFaceQualityThreshold;
            this.log = log;
            this.forbiddenChars = forbiddenChars;
        }

        public double DefaultFaceQualityScoreThreshold { get; private set; }

        public ICommand GetCommandByToken(string token)
        {
            return this.commandsRepo.GetCommandByToken(token);
        }

        public EvalImageCommand PublishEvalFaceCommand(string faceId, ImageRef imageRef, int topn)
        {
            string token = null;
            Face theFace = this.faceRepo.GetFaceById(faceId, true);

            if (theFace == null)
            {
                throw new ArgumentException("Invalid or non-existent face.");
            }

            // Construct the command object    
            token = this.CreateToken();
            EvalImageCommand cmd = new EvalImageCommand(token);
            cmd.Faces.Add(new FaceInCommand(theFace));
            cmd.ImageRef.RefType = theFace.ImageRef.RefType;
            cmd.ImageRef.Id = theFace.ImageRef.Id;
            cmd.TopN = topn;

            // Save the command object
            this.commandsRepo.InsertOrUpdateCommand(cmd);

            // Send it to the bus
            this.SendCommand(cmd, "SmartCaps.FR.EvalImage.FacesExtracted");

            // return token
            return cmd;
        }

        public EvalImageCommand PublishEvalImageCommand(ImageRef imageRef, double faceQualityScoreThreshold, int topn)
        {
            string token = null;

            // Verify image is accesible
            if (!this.imageServices.ValidateImage(imageRef.Id, imageRef.RefType.ToString()))
            {
                throw new ArgumentException("Invalid or non-existent image.");
            }

            // Construct the command object    
            token = this.CreateToken();
            EvalImageCommand cmd = new EvalImageCommand(token);
            cmd.FaceQualityScoreThreshold = faceQualityScoreThreshold;
            cmd.ImageRef.RefType = imageRef.RefType;
            cmd.ImageRef.Id = imageRef.Id;
            cmd.ImageRef.Path = this.imageServices.GetImagePath(imageRef.Id, imageRef.RefType.ToString());
            cmd.TopN = topn;

            // Save the command object
            this.commandsRepo.InsertOrUpdateCommand(cmd);

            // Send it to the bus
            this.SendCommand(cmd, "SmartCaps.FR.EvalImage");

            return cmd;
        }

        public ICommand PublishEnrollImageCommand(ImageRef imageRef, string originalFileName, EnrollOptions options)
        {
            string token = null;

            // Verify image is accesible
            if (!this.imageServices.ValidateImage(imageRef.Id, imageRef.RefType.ToString()))
            {
                throw new ArgumentException("Invalid or non-existent image.");
            }
            
            // Construct the command object    
            token = this.CreateToken();
            EnrollAndEvalImageCommand cmd = new EnrollAndEvalImageCommand(token);
            cmd.FaceQualityScoreThreshold = options.FaceQualityScoreThreshold;
            cmd.CreatedBy = options.RequestedBy;
            cmd.ImageRef.RefType = imageRef.RefType;
            cmd.ImageRef.Id = imageRef.Id;
            cmd.ImageRef.Path = this.imageServices.GetImagePath(imageRef.Id, imageRef.RefType.ToString());
            cmd.Autoconfirm = options.Confirm;
            cmd.Tags = options.Tags != null ? RemoveForbiddenChars(options.Tags.Distinct().ToList()) : null;
            cmd.SienaRefs = options.SienaRefs != null ? RemoveForbiddenChars(options.SienaRefs.Distinct().ToList()) : null;
            cmd.FocalPoints = options.FocalPoints != null ? RemoveForbiddenChars(options.FocalPoints.Distinct().ToList()) : null;
            cmd.OriginalFileName = originalFileName;
            
            // Save the command object
            this.commandsRepo.InsertOrUpdateCommand(cmd);

            // Send it to the bus
            this.SendCommand(cmd, "SmartCaps.FR.EnrollAndEvalImage");

            return cmd;
        }

        public ICommand PublishBatchEnrollImageCommand(ImageRef imageRef, string originalFileName, EnrollOptions options)
        {
            string token = null;

            // Verify image is accesible
            if (!this.imageServices.ValidateImage(imageRef.Id, imageRef.RefType.ToString()))
            {
                throw new ArgumentException("Invalid or non-existent image.");
            }

            // Construct the command object    
            token = this.CreateToken();
            ICommand theCommand = null;

            BatchEnrollImageCommand cmd = new BatchEnrollImageCommand(token);
            cmd.FaceQualityScoreThreshold = options.FaceQualityScoreThreshold;
            cmd.CreatedBy = options.RequestedBy;
            cmd.ImageRef.RefType = imageRef.RefType;
            cmd.ImageRef.Id = imageRef.Id;
            cmd.ImageRef.Path = this.imageServices.GetImagePath(imageRef.Id, imageRef.RefType.ToString());
            cmd.Autoconfirm = options.Confirm;
            cmd.Tags = options.Tags != null ? RemoveForbiddenChars(options.Tags.Distinct().ToList()) : null;
            cmd.SienaRefs = options.SienaRefs != null ? RemoveForbiddenChars(options.SienaRefs.Distinct().ToList()) : null;
            cmd.FocalPoints = options.FocalPoints != null ? RemoveForbiddenChars(options.FocalPoints.Distinct().ToList()) : null;
            cmd.OriginalFileName = originalFileName;

            // Save the command object
            this.commandsRepo.InsertOrUpdateCommand(cmd);

            // Send it to the bus
            this.SendCommand(cmd, "SmartCaps.FR.BatchEnrollImage");

            // return token
            theCommand = cmd;

            return theCommand;
        }

        public EnrollImagesFromVideoCommand PublishEnrollImagesFromVideoCommand(ImageRef videoRef, string originalFileName, EnrollOptions options)
        {
            string token = null;

            // Verify image is accesible
            if (!this.imageServices.ValidateImage(videoRef.Id, videoRef.RefType.ToString()))
            {
                throw new ArgumentException("Invalid or non-existent video.");
            }

            // Construct the command object    
            token = this.CreateToken();

            EnrollImagesFromVideoCommand cmd = new EnrollImagesFromVideoCommand(token);
            cmd.FaceQualityScoreThreshold = options.FaceQualityScoreThreshold;
            cmd.CreatedBy = options.RequestedBy;
            cmd.ImageRef.RefType = videoRef.RefType;
            cmd.ImageRef.Id = videoRef.Id;
            cmd.ImageRef.Path = this.imageServices.GetImagePath(videoRef.Id, videoRef.RefType.ToString());
            cmd.Autoconfirm = options.Confirm;
            cmd.Tags = options.Tags != null ? RemoveForbiddenChars(options.Tags.Distinct().ToList()) : null;
            cmd.SienaRefs = options.SienaRefs != null ? RemoveForbiddenChars(options.SienaRefs.Distinct().ToList()) : null;
            cmd.FocalPoints = options.FocalPoints != null ? RemoveForbiddenChars(options.FocalPoints.Distinct().ToList()) : null;
            cmd.OriginalFileName = originalFileName;
            cmd.Metadata = options.Metadata;

            // Save the command object
            this.commandsRepo.InsertOrUpdateCommand(cmd);

            // Send it to the bus
            this.SendCommand(cmd, "SmartCaps.FR.EnrollImagesFromVideo");

            return cmd;
        }

        public RemoveFacesCommand PublishRemoveFacesCommand(string[] faceIds)
        {
            string token = this.CreateToken();
            RemoveFacesCommand cmd = new RemoveFacesCommand(token);
            foreach (var faceId in faceIds)
            {
                cmd.Faces.Add(new FaceInCommand() { Id = faceId });
            }

            this.commandsRepo.InsertOrUpdateCommand(cmd);
            this.SendCommand(cmd, "SmartCaps.FR.RemoveFaces");

            return cmd;
        }

        public StatusCommand PublishStatusCommand()
        {
            string token = this.CreateToken();
            StatusCommand cmd = new StatusCommand(token);

            // Save the command object
            //this.commandsRepo.InsertOrUpdateCommand((ICommand)cmd);

            this.SendCommand(cmd, "SmartCaps.FR.Status");

            return cmd;
        }

        public async Task<IAmAlive> GetServiceStatus()
        {
            IAmAlive alive = new IAmAlive()
            {
                ActiveMQImplementation = this.publisher.GetType().ToString(),
                FRWebApiVersion = typeof(Controllers.FacesController).Assembly.GetName().Version.ToString(),
                FRLibVersion = typeof(SmartCaps.FR.Common.Model.Face).Assembly.GetName().Version.ToString(),
                MsgLibVersion = typeof(SmartCaps.FR.NetMessaging.MessagesProcessor).Assembly.GetName().Version.ToString(),
                Service = "UNKNOWN",
                FaceEngine = "UNKNOWN",
                KnnEngine = "UNKNOWN",
                VideoEngine = "UNKNOWN",
                DbUpdater = "UNKNOWN",
                FRWebApiRelease = System.Configuration.ConfigurationManager.AppSettings["ReleaseName"]
            };

            try
            {
                Stopwatch sw = new Stopwatch();
                sw.Start();

                // Publish and wait until the command is finished, or timeout at 5s
                var statusCommand = this.PublishStatusCommand();
                var results = await this.GetCommandsResult(new ICommand[] { statusCommand }, true, 10);
                sw.Stop();

                if (results.Success.Count == 1)
                {
                    alive.Service = sw.Elapsed.TotalSeconds < 3 ? "GREEN" : "YELLOW";
                    alive.Message = sw.Elapsed.TotalSeconds < 3 ? "Service is running OK." : "Service is busy or is having performance issues.";
                    alive.FaceEngine = "OK";
                    alive.KnnEngine = "OK";
                    alive.DbUpdater = "OK";
                    alive.VideoEngine = "OK";
                }
                else
                {
                    alive.Service = "RED";
                    alive.Message = "At least one critical component is down.";
                    ICommand theItem = null;
                    if (results.Failed.Count > 0)
                    {
                        theItem = results.Failed.First();
                    }
                    else if (results.NotFinished.Count > 0)
                    {
                        theItem = this.GetCommandByToken(results.NotFinished.First().Token);
                        if (theItem == null)
                        {
                            theItem = new StatusCommand(statusCommand.Token);
                            theItem.LastStepCompleted = -1;
                        }
                    }
                    if (theItem.StepsCompleted.HasFlag(ComponentSteps.Updater))
                    { 
                        alive.DbUpdater =  "OK";
                        if (!theItem.StepsCompleted.HasFlag(ComponentSteps.FaceEngine) || !theItem.StepsCompleted.HasFlag(ComponentSteps.Video))
                        {
                            alive.Service = "ORANGE";
                            alive.Message = "At least one not critical component is down.";
                        }

                        alive.FaceEngine = theItem.StepsCompleted.HasFlag(ComponentSteps.FaceEngine) ? "OK" : "FAIL";
                        alive.KnnEngine = theItem.StepsCompleted.HasFlag(ComponentSteps.Knn) ? "OK" : "FAIL";
                        alive.VideoEngine = theItem.StepsCompleted.HasFlag(ComponentSteps.Video) ? "OK" : "FAIL";
                    }
                    else
                    {
                        alive.DbUpdater = "FAIL";
                    }
                }

            }
            catch (Exception ex)
            {
                alive.Service = "RED";
                alive.Message = ex.Message;
            }

            return alive;
        }

        public Task<OpResults<ICommand>> GetCommandsResult(IEnumerable<ICommand> commands, bool removeAfterSuccess, int timeoutInSecs = 20)
        {
            // Wait until all the commands are finished, or timeout
            return Task.Run(() =>
            {
                this.log.Debug("Waiting for command/s to finish...");
                DateTime startTime = DateTime.Now;
                DateTime timeOut = startTime.AddSeconds(timeoutInSecs);
                bool timedOut = false;
                OpResults<ICommand> commandsResults = new OpResults<ICommand>();
                IList<ICommand> remainingCommands = new List<ICommand>(commands);
                int pollNo = 0;
                do
                {
                    foreach (ICommand command in remainingCommands.ToList())
                    {
                        var cmd = this.commandsRepo.GetCommandByToken(command.Token);
                        if (cmd != null && cmd.LastStepCompleted == cmd.TotalSteps)
                        {
                            remainingCommands.Remove(command);
                            commandsResults.Success.Add(cmd);
                            if (removeAfterSuccess)
                            {
                                this.commandsRepo.DeleteCommandByToken(cmd.Token);
                            }
                        }
                        else if (cmd != null && !string.IsNullOrEmpty(cmd.ErrorMessage))
                        {
                            remainingCommands.Remove(command);
                            commandsResults.Failed.Add(cmd);
                        }
                    }

                    System.Threading.Thread.Sleep(this.pollingTimeInMs);
                    timedOut = DateTime.Now >= timeOut;
                    pollNo++;
                }
                while (!timedOut && remainingCommands.Count > 0);

                commandsResults.NotFinished.AddRange(remainingCommands);
                this.log.DebugFormat("Command/s finished ({0} succeeded, {1} failed, {2} remaining, {3} polls done).", commandsResults.Success.Count, commandsResults.Failed.Count, commandsResults.NotFinished.Count, pollNo);
                return commandsResults;
            });
        }

        private IEnumerable<string> RemoveForbiddenChars(List<string> tags)
        {
            return tags.Select(x => Regex.Replace(x, this.forbiddenChars, ""));
        }

        private string CreateToken()
        {
            return Guid.NewGuid().ToString();
        }

        private void SendCommand(ICommand cmd, string routingKey)
        {
            Dictionary<string, string> props = new Dictionary<string, string>();
            string json = JsonConvert.SerializeObject(cmd);
            this.publisher.Publish(routingKey, json);
        }
    }

    public class IAmAlive
    {
        public string ActiveMQImplementation { get; set; }
        public string FRWebApiVersion { get; set; }
        public string FRLibVersion { get; set; }
        public string MsgLibVersion { get; set; }
        public string FaceEngine { get; set; }
        public string KnnEngine { get; set; }
        public string VideoEngine { get; set; }
        public string DbUpdater { get; set; }
        public string Service { get; set; }
        public string Message { get; set; }
        public string FRWebApiRelease { get; set; }
    }


}