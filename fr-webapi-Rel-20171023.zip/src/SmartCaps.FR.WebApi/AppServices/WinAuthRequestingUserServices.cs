﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;

namespace SmartCaps.FR.WebApi.AppServices
{
    public class WinAuthRequestingUserServices : IRequestingUserServices
    {
        public string GetRequestingUserName(HttpRequestMessage request)
        {
            string result = "unknown";

            string loggedUser = request.GetRequestContext().Principal.Identity.Name;
            if (!string.IsNullOrEmpty(loggedUser))
            {
                result = loggedUser;
            }

            return result;
        }
    }
}