﻿using System;
using System.Web;

namespace SmartCaps.FR.WebApi.Cache
{
    public class HttpContextCache : ICacheStore
    {
        private readonly int cacheExpirationTime;

        /// <summary>
        /// Create an instance of the class.
        /// </summary>
        /// <param name="cacheExpirationTime">In seconds.</param>
        public HttpContextCache(int cacheExpirationTime)
        {
            this.cacheExpirationTime = cacheExpirationTime;
        }
         
        public void Add(string key, object data)
        {
            HttpContext.Current.Cache.Add(key, data, null, System.Web.Caching.Cache.NoAbsoluteExpiration, new TimeSpan(0, 0, this.cacheExpirationTime), System.Web.Caching.CacheItemPriority.Normal, null);
        }
        
        public T Get<T>(string key)
        {
            try
            {
                return (T)HttpContext.Current.Cache.Get(key);
            }
            catch (Exception ex)
            {
                return default(T);
            }
        }


        public void Remove(string key)
        {
            HttpContext.Current.Cache.Remove(key);
        }
    }
}