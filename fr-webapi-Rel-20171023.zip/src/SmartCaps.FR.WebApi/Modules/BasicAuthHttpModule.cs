﻿//using log4net;
//using System;
//using System.Collections.Generic;
//using System.Configuration;
//using System.Linq;
//using System.Net.Http.Headers;
//using System.Security.Principal;
//using System.Text;
//using System.Threading;
//using System.Web;

//namespace SmartCaps.FR.WebApi.Modules
//{
//    public class BasicAuthHttpModule : IHttpModule
//    {
//        private static ILog log;
//        public void Dispose()
//        {
//        }

//        public void Init(HttpApplication context)
//        {
//            log = log4net.LogManager.GetLogger("SmartCaps.FR.WebApi");
//            log4net.Config.XmlConfigurator.Configure();

//            context.AuthenticateRequest += OnApplicationAuthenticateRequest;
//            context.EndRequest += OnApplicationEndRequest;
//        }

//        private static void SetPrincipal(IPrincipal principal)
//        {
//            Thread.CurrentPrincipal = principal;
//            if(HttpContext.Current != null)
//            {
//                HttpContext.Current.User = principal;
//            }
//        }

//        private static bool ValidateUserAndPassword(string username, string password)
//        {
//            return username == ConfigurationManager.AppSettings["BasicAuthUser"] && password ==ConfigurationManager.AppSettings["BasicAuthPw"];
//        }

//        private static void AuthenticateUser(string credentials)
//        {
//            try
//            {
//                var encoding = Encoding.GetEncoding("iso-8859-1");
//                credentials = encoding.GetString(Convert.FromBase64String(credentials));

//                int separator = credentials.IndexOf(':');
//                string user = credentials.Substring(0, separator);
//                string password = credentials.Substring(separator + 1);
//                log.DebugFormat("Trying user {0} and pwd {1}", user, password);
//                if (ValidateUserAndPassword(user, password))
//                {
//                    var identity = new GenericIdentity(user);
//                    SetPrincipal(new GenericPrincipal(identity, null));
//                }
//                else
//                {
//                    log.Debug("Validation of usr and pwd failed!");
//                    HttpContext.Current.Response.StatusCode = 401;
//                }
//            }
//            catch (FormatException)
//            {
//                log.Debug("Validation of usr and pwd failed cos format exception!");
//                HttpContext.Current.Response.StatusCode = 401;
//            }
//        }

//        private static void OnApplicationAuthenticateRequest(object sender, EventArgs e)
//        {
//            var request = HttpContext.Current.Request;
//            var authHeader = request.Headers["Authorization"];
//            log.DebugFormat("Received this Auth header: {0}", authHeader);
//            if(authHeader != null)
//            {
//                var authHeaderVal = AuthenticationHeaderValue.Parse(authHeader);
//                log.DebugFormat("Auth header scheme: {0}", authHeaderVal.Scheme);
//                if (authHeaderVal.Scheme.Equals("basic", StringComparison.OrdinalIgnoreCase) && authHeaderVal.Parameter != null)
//                {
//                    AuthenticateUser(authHeaderVal.Parameter);
//                }
//                else if (authHeaderVal.Scheme.Equals("negotiate", StringComparison.OrdinalIgnoreCase))
//                {
//                    log.Debug("Negotiate");
//                }
//            }
//            else
//            {
//                log.Debug("Auth heather is null");
//            }
//        }

//        private static void OnApplicationEndRequest(object sender, EventArgs e)
//        {
//            var response = HttpContext.Current.Response;
//            if(response.StatusCode == 401)
//            {
//                response.Headers.Add("WWW-Authenticate", "Basic realm=\"realm\"");
//            }
//        }
//    }
//}