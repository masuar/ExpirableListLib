﻿using log4net;
using SmartCaps.FR.WebApi.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Dispatcher;

namespace SmartCaps.FR.WebApi.App_Start
{
    public class CompositionRoot : IHttpControllerActivator
    {
        private ILog log;

        public CompositionRoot(ILog log)
        {
            this.log = log;
        }

        public IHttpController Create(HttpRequestMessage request, HttpControllerDescriptor controllerDescriptor, Type controllerType)
        {
            IHttpController controller = null;

            DependenciesContainer dep = new DependenciesContainer(this.log);
            request.RegisterForDispose(dep);

            if (controllerType == typeof(FacesController))
            {
                controller = new FacesController(dep.FaceSvc, dep.CommandSvc, dep.ImageSvc, dep.UserSvc, this.log);
            }
            else if (controllerType == typeof(CommandsController))
            {
                controller = new CommandsController(dep.CommandSvc, dep.ImageSvc, dep.UserSvc, this.log);
            }
            else if (controllerType == typeof(MiscController))
            {
                controller = new MiscController(dep.CommandSvc, dep.Settings, dep.FocalPointSvc, this.log);
            }

            return controller;
        }
    }
}