﻿using Apache.NMS;
using log4net;
using SmartCaps.FR.Common.Model;
using SmartCaps.FR.Common.Repos;
using SmartCaps.FR.Common.Repos.SQLServer;
using SmartCaps.FR.Images.Repositories;
using SmartCaps.FR.Images.Repositories.FileSystem;
using SmartCaps.FR.Images.Services;
using SmartCaps.FR.NetMessaging.Services;
using SmartCaps.FR.NetMessaging.Services.ActiveMQ;
using SmartCaps.FR.WebApi.AppServices;
using SmartCaps.FR.WebApi.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using Microsoft.Ajax.Utilities;
using Apache.NMS.ActiveMQ;
using SmartCaps.FR.WebApi.Cache;

namespace SmartCaps.FR.WebApi.App_Start
{
    internal class DependenciesContainer : IDisposable
    {
        private ILog log;
        public DependenciesContainer(ILog log)
        {
            this.log = log;
            this.InitializeDependencies();
        }

        public FaceServices FaceSvc { get; private set; }

        public FocalPointServices FocalPointSvc { get; private set; }

        public CommandServices CommandSvc { get; private set; }

        public ImageServices ImageSvc { get; private set; }

        public IConnection AMQConnection { get; private set; }

        public ISession AMQSession { get; private set; }

        public IPublisherService PublisherSvc { get; private set; }

        public IRequestingUserServices UserSvc { get; private set; }

        public FaceRecognitionSettings Settings { get; private set; }

        public void Dispose()
        {
            if (this.AMQSession != null)
            {
                this.AMQSession.Dispose();
            }

            if (this.AMQConnection != null)
            {
                this.AMQConnection.Dispose();
            }
        }

        protected virtual void InitializeDependencies()
        {
            string sqlConnectionString = ConfigurationManager.ConnectionStrings["SmartCaps.FR"].ConnectionString;
            string amqConnectionString = ConfigurationManager.AppSettings["AmqConnectionString"];
            string amqUser = ConfigurationManager.AppSettings["AmqUser"];
            string amqPwd = ConfigurationManager.AppSettings["AmqPwd"];
            string topicName = ConfigurationManager.AppSettings["AmqTopicNameToPublishTo"];
            string imagesRootFolder = ConfigurationManager.AppSettings["ImagesRootFolder"];
            string disconnectedMode = ConfigurationManager.AppSettings["DisconnectedMode"];
            string blurredStr = ConfigurationManager.AppSettings["Blurred"];
            int syncCommandsPollingTimeInMs = int.Parse(ConfigurationManager.AppSettings["SyncCommandsPollingTimeInMs"]);
            string forbiddenChars = ConfigurationManager.AppSettings["ForbiddenChars"];
            int faceDbCommandstimeOut = int.Parse(ConfigurationManager.AppSettings["FaceDbCommandstimeOut"]);
            int cmdDbCommandstimeOut = int.Parse(ConfigurationManager.AppSettings["CmdDbCommandstimeOut"]);
            int cacheTimeOut = int.Parse(ConfigurationManager.AppSettings["cacheTimeOut"]);
            int imgCacheTimeOut = int.Parse(ConfigurationManager.AppSettings["imageCacheTimeOut"]);

            this.Settings = this.GetDefaultSettings();
            this.OverrideSettingsWithConfigFileValues(this.Settings);

            if (string.IsNullOrEmpty(imagesRootFolder))
            {
                imagesRootFolder = @"C:\SmartCapsFRImages";
            }

            bool blurred = true;
            if (!string.IsNullOrEmpty(blurredStr) && blurredStr.ToLower()=="off")
            {
                blurred = false;
            }

            ICacheStore dataCacheStore = new HttpContextCache(cacheTimeOut); 
            ICacheStore imgCacheStore = new HttpContextCache(imgCacheTimeOut); 
            IFaceRepository faceRepo = new SQLServerFaceRepository(sqlConnectionString, faceDbCommandstimeOut, this.log);
            IFocalPointRepository focalPointRepo = new SQLServerFocalPointRepository(sqlConnectionString, this.log);
            ICommandRepository cmdRepo = new SQLServerCommandRepository(sqlConnectionString, cmdDbCommandstimeOut, this.log);
            IDictionary<string, IImageRepository> imageRepos = new Dictionary<string, IImageRepository>();
            IImageIdGenerator imageIdGenerator = new SHA1ImageIdGenerator();
            imageRepos.Add("FILESYS", new FileSystemImageRepository(imagesRootFolder, imageIdGenerator , this.log));

            if (ConfigurationManager.ConnectionStrings["Ivas.DB"] != null && ConfigurationManager.AppSettings["IvasBasePath"] != null)
            {
                string twinsBasePath = ConfigurationManager.AppSettings["IvasBasePath"];
                string sqlConnectionStringToTwins = ConfigurationManager.ConnectionStrings["Ivas.DB"].ConnectionString;
                imageRepos.Add("IVAS", new Images.Repositories.Ivas.IvasImageRepository(sqlConnectionStringToTwins, twinsBasePath, this.log));
            }
            
            ImageRepositorySelector imageRepoSelector = new ImageRepositorySelector(imageRepos, this.log);

            if (disconnectedMode != "ON")
            {
                IConnectionFactory connectionFactory = new ConnectionFactory(new Uri(amqConnectionString));
                this.AMQConnection = connectionFactory.CreateConnection(amqUser, amqPwd);
                this.AMQSession = this.AMQConnection.CreateSession(AcknowledgementMode.AutoAcknowledge);
                this.PublisherSvc = new ActiveMQPublisherService(this.AMQSession, topicName, this.log);
            }
            else
            {
                this.log.Warn("Going into disconnected mode!");
                var memStore = new List<NetMessaging.Services.Memory.MessageInMemory>();
                this.PublisherSvc = new SmartCaps.FR.NetMessaging.Services.Memory.MemoryPublisherService(memStore);
            }

            this.FaceSvc = new FaceServices(faceRepo, imageRepoSelector, dataCacheStore, imgCacheStore, blurred, this.log);
            this.FocalPointSvc = new FocalPointServices(focalPointRepo, dataCacheStore, log);
            this.ImageSvc = new ImageServices(imageRepoSelector, this.log);
            this.CommandSvc = new CommandServices(cmdRepo, faceRepo, this.PublisherSvc, this.ImageSvc, syncCommandsPollingTimeInMs, this.Settings.FaceQualityThreshold.Default, forbiddenChars, this.log);
            this.UserSvc = new WinAuthRequestingUserServices();
        }

        protected FaceRecognitionSettings GetDefaultSettings()
        {
            FaceRecognitionSettings result = new Model.FaceRecognitionSettings();

            result.FaceQualityThreshold.Max = 0.9999;
            result.FaceQualityThreshold.Min = 0.8000;
            result.FaceQualityThreshold.Default = 0.9900;

            result.AutoMatch.Threshold = 0.45;
            result.AutoMatch.TagString = "POSSIBLE MATCH";
            result.DefaultTopNOptions = "10,30,50";
            result.DefaultPageSize = 12;

            return result;
        }

        protected void OverrideSettingsWithConfigFileValues(FaceRecognitionSettings settings)
        {
            double min = 0;
            if (double.TryParse(System.Configuration.ConfigurationManager.AppSettings["FaceQualityScoreThresholdMin"], out min))
                settings.FaceQualityThreshold.Min = min;

            double max = 0;
            if (double.TryParse(System.Configuration.ConfigurationManager.AppSettings["FaceQualityScoreThresholdMax"], out max))
                settings.FaceQualityThreshold.Max = max;

            double def = 0;
            if (double.TryParse(System.Configuration.ConfigurationManager.AppSettings["FaceQualityScoreThreshold"], out def))
                settings.FaceQualityThreshold.Default = def;

            double matchThreshold = 0;
            if (double.TryParse(System.Configuration.ConfigurationManager.AppSettings["MatchThreshold"], out matchThreshold))
                settings.AutoMatch.Threshold = matchThreshold;

            string tagString = System.Configuration.ConfigurationManager.AppSettings["MatchTagString"];
            if (!string.IsNullOrEmpty(tagString))
                settings.AutoMatch.TagString = tagString;

            int defaultPageSize = 0;
            if (int.TryParse(System.Configuration.ConfigurationManager.AppSettings["DefaultPageSize"], out defaultPageSize))
                settings.DefaultPageSize = defaultPageSize;

            string defaultTopNOptions = System.Configuration.ConfigurationManager.AppSettings["DefaultTopNOptions"];
            if (!string.IsNullOrEmpty(defaultTopNOptions))
                settings.DefaultTopNOptions = defaultTopNOptions;

        }
    }
}