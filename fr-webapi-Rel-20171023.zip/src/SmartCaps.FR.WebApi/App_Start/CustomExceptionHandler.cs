﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.ExceptionHandling;

namespace SmartCaps.FR.WebApi.App_Start
{
    public class CustomExceptionHandler : System.Web.Http.ExceptionHandling.ExceptionHandler
    {
        private ILog log;
        public CustomExceptionHandler(ILog log)
        {
            this.log = log;
        }

        public override void Handle(ExceptionHandlerContext context)
        {
            this.log.Error("Exception handled by custom handler.", context.Exception);
            base.Handle(context);
        }
    }
}