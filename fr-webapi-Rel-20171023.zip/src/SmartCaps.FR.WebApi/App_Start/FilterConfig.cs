﻿using System.Web;
using System.Web.Mvc;

namespace SmartCaps.FR.WebApi
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            //filters.Add(new Filters.CustomHttpAuthorizeAttribute());
            filters.Add(new HandleErrorAttribute());
        }
    }
}
