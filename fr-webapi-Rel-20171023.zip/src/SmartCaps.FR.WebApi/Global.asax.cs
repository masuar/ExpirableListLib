﻿using log4net;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Http;
using System.Web.Http.Dispatcher;
using System.Web.Http.ExceptionHandling;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace SmartCaps.FR.WebApi
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            ILog log = log4net.LogManager.GetLogger("SmartCaps.FR.WebApi");
            log4net.Config.XmlConfigurator.Configure();

            string appVersion = typeof(SmartCaps.FR.WebApi.Controllers.FacesController).Assembly.GetName().Version.ToString();
            string frLibVersion = typeof(SmartCaps.FR.Common.Model.Face).Assembly.GetName().Version.ToString();
            string msgLibVersion = typeof(SmartCaps.FR.NetMessaging.MessagesProcessor).Assembly.GetName().Version.ToString();

            log.InfoFormat("SmartCaps.FR.WebApi started! App. version {0}; FR Lib version: {1}; Msg Lib version: {2}", appVersion, frLibVersion, msgLibVersion);

            GlobalConfiguration.Configuration.Services.Replace(typeof(IExceptionHandler), new App_Start.CustomExceptionHandler(log));
            GlobalConfiguration.Configuration.Services.Replace(typeof(IHttpControllerActivator), new App_Start.CompositionRoot(log));
            var jsonFormatter = GlobalConfiguration.Configuration.Formatters.JsonFormatter;
            jsonFormatter.SupportedMediaTypes.Add(new MediaTypeHeaderValue("text/html"));
            jsonFormatter.SerializerSettings.Formatting = Formatting.Indented;
            //serializerSettings.NullValueHandling = NullValueHandling.Ignore;
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
        }

        protected void Application_PreSendRequestHeader()
        {
            Response.Headers.Remove("Server");
        }
    }
}
