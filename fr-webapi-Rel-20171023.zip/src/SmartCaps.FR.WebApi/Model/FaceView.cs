﻿using Newtonsoft.Json;
using SmartCaps.FR.Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Collections;

namespace SmartCaps.FR.WebApi.Model
{
    public class FaceView
    {
        public FaceView(string faceId, string errorMessage)
        {
            this.ErrorMessage = errorMessage;
        }

        public FaceView(Face face, HttpRequestMessage request)
        {
            if (face != null)
            {
                this.Id = face.Id;
                this.ImageRef = face.ImageRef;
                this.Owner = face.Owner;
                this.QualityScore = face.QualityScore;
                this.InsertedOn = face.InsertedOn;
                this.LastUpdatedOn = face.LastUpdatedOn;
                this.Confirmed = face.Confirmed;
                this.Tags = face.Tags;
                this.SienaRefs = face.SienaRefs;
                this.WatchListed = face.WatchListed;
                this.FocalPoints = face.FocalPoints;
                this.Metadata = face.Metadata;
                this.Links = new FaceLinks(face.Id, request);
            }
        }

        [JsonProperty(PropertyName = "id", Order = 1)]
        public string Id { get; private set; }

        [JsonProperty(PropertyName = "owner", Order = 2)]
        public string Owner { get; private set; }

        [JsonProperty(PropertyName = "qualityScore", Order = 3)]
        public double QualityScore { get; private set; }

        [JsonProperty(PropertyName = "confirmed", Order = 4)]
        public bool Confirmed { get; private set; }

        [JsonProperty(PropertyName = "watchListed", Order = 5)]
        public bool WatchListed { get; private set; }

        [JsonProperty(PropertyName = "insertedOn", Order = 6)]
        public DateTime InsertedOn { get; private set; }

        [JsonProperty(PropertyName = "lastUpdatedOn", Order = 7)]
        public DateTime LastUpdatedOn { get; private set; }

        [JsonProperty(PropertyName = "imageRef", Order = 8)]
        public ImageRef ImageRef { get; private set; }

        [JsonProperty(PropertyName = "tags", Order = 9)]
        public IList<string> Tags { get; private set; }

        [JsonProperty(PropertyName = "sienaRefs", Order = 10)]
        public IList<string> SienaRefs { get; private set; }

        [JsonProperty(PropertyName = "focalPoints", Order = 11)]
        public IList<string> FocalPoints { get; private set; }

        [JsonProperty(PropertyName = "metadata", Order = 12)]
        public IDictionary<string, string> Metadata { get; private set; }

        [JsonProperty(PropertyName = "links", Order = 13)]
        public FaceLinks Links { get; private set; }

        [JsonProperty(PropertyName = "error", Order = 14)]
        public string ErrorMessage { get; set; }

    }

    public class FaceLinks 
    {

        public FaceLinks(string faceId, HttpRequestMessage request)
        {
            this.Face = new LinkView(new Uri(request.GetUrlHelper().Link("GetFaceData", new { id = faceId })));
            this.Image = new LinkView(new Uri(request.GetUrlHelper().Link("GetFaceImage", new { id = faceId })));
            this.FullImage = new LinkView(new Uri(request.GetUrlHelper().Link("GetFaceFullImage", new { id = faceId })));
            this.RecognizeFace = new LinkView(new Uri(request.GetUrlHelper().Link("RecognizeFace", new { faceid = faceId })));
            this.Features = new LinkView(new Uri(request.GetUrlHelper().Link("GetFaceFeatures", new { id = faceId })));
        }

        [JsonProperty(PropertyName = "face", Order = 1)]
        public LinkView Face { get; private set; }

        [JsonProperty(PropertyName = "image", Order = 2)]
        public LinkView Image { get; private set; }

        [JsonProperty(PropertyName = "fullImage", Order = 3)]
        public LinkView FullImage { get; private set; }

        [JsonProperty(PropertyName = "recognizeFace", Order = 4)]
        public LinkView RecognizeFace { get; private set; }

        [JsonProperty(PropertyName = "features", Order = 5)]
        public LinkView Features { get; private set; }


    }
}