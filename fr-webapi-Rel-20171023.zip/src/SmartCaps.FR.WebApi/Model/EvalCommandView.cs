﻿using Newtonsoft.Json;
using SmartCaps.FR.Common.Model;
using SmartCaps.FR.Common.Model.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;

namespace SmartCaps.FR.WebApi.Model
{
    public class EvalCommandView : CommandView
    {
        public EvalCommandView(string errorMessage)
            : base(errorMessage)
        {
        }

        public EvalCommandView(IEvalCommand cmd, HttpRequestMessage request)
            : base(cmd)
        {
            this.CommandLink = new Model.LinkView(new Uri(request.GetUrlHelper().Link("GetEvalCommand", new { token = cmd.Token })));
            this.Token = cmd.Token;
            this.OriginalFaces = cmd.Faces.Select(f => new FaceView(f, request)).ToList();
            this.EvalResultsView = cmd.Neighbors.Select(n => new EvalResultView(n, request)).ToList();
        }

        [JsonProperty(PropertyName = "originalFaces", Order = 5)]
        public IEnumerable<FaceView> OriginalFaces { get; private set; }

        [JsonProperty(PropertyName = "evalResults", Order = 6)]
        public IEnumerable<EvalResultView> EvalResultsView { get; private set; }

    }

    public class EvalResultView
    {
        public EvalResultView(FaceNeighbor neighbor, HttpRequestMessage request)
        {
            if (neighbor != null)
            {
                this.SourceFaceId = neighbor.SourceFaceId;
                this.TargetFaceId = neighbor.TargetFaceId;
                this.Grade = neighbor.Grade;
                this.SourceFaceLinks = new Model.FaceLinks(neighbor.SourceFaceId, request);
                this.TargetFaceLinks = new Model.FaceLinks(neighbor.TargetFaceId, request);
            }
        }

        [JsonProperty(PropertyName = "sourceFaceLinks", Order = 1)]
        public FaceLinks SourceFaceLinks { get; private set; }

        [JsonProperty(PropertyName = "targetFaceLinks", Order = 2)]
        public FaceLinks TargetFaceLinks { get; private set; }

        [JsonProperty(PropertyName = "sourceFaceId", Order = 3)]
        public string SourceFaceId { get; private set; }

        [JsonProperty(PropertyName = "targetFaceId", Order = 4)]
        public string TargetFaceId { get; private set; }

        [JsonProperty(PropertyName = "grade", Order = 5)]
        public double Grade { get; private set; }



    }
}