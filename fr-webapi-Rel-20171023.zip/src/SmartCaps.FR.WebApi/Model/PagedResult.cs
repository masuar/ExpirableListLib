﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;

namespace SmartCaps.FR.WebApi.Model
{
    /// <summary>
    /// Represents a set of results in a page.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class PagedResult<T>
    {
        public PagedResult( HttpRequestMessage request,
            string pagingRouteName,
            IQueryStringFilter filter,
            IEnumerable<T> data,
            int pageIndex,
            int pageSize,
            int totalPages)
        {
            this.Initialize(request, pagingRouteName, filter, data, pageIndex, pageSize, totalPages);
        }

        /// <summary>
        /// Gets the total number of items.
        /// </summary>
        [JsonProperty(PropertyName = "totalItems", Order = 1)]
        public long TotalItems { get; private set; }

        /// <summary>
        /// Gets the size of the page.
        /// </summary>
        [JsonProperty(PropertyName = "pageSize", Order = 2)]
        public long PageSize { get; private set; }

        /// <summary>
        /// Gets the total number of pages.
        /// </summary>
        [JsonProperty(PropertyName = "totalPages", Order = 3)]
        public long TotalPages { get; private set; }

        /// <summary>
        /// Gets the current page number.
        /// </summary>
        [JsonProperty(PropertyName = "currentPage", Order = 4)]
        public long CurrentPage { get; private set; }

        /// <summary>
        /// Gets the zero-based index of the first item returned in this page.
        /// </summary>
        [JsonProperty(PropertyName = "fromItemIndex", Order = 5)]
        public long FromItemIndex { get; private set; }

        /// <summary>
        /// Gets the zero-based index of the last item returned in this page.
        /// </summary>
        [JsonProperty(PropertyName = "toItemIndex", Order = 6)]
        public long ToItemIndex { get; private set; }

        /// <summary>
        /// Holds the data results.
        /// </summary>
        [JsonProperty(PropertyName = "data", Order = 7)]
        public IEnumerable<T> Data { get; private set; }

        /// <summary>
        /// Gets the link for the next page of this query. 
        /// </summary>
        [JsonProperty(PropertyName = "nextPageLink", Order = 8)]
        public LinkView NextPageLink { get; private set; }

        /// <summary>
        /// Gets the link for the next page of this query. 
        /// </summary>
        [JsonProperty(PropertyName = "prevPageLink", Order = 9)]
        public LinkView PrevPageLink { get; private set; }

        private void Initialize(HttpRequestMessage request, string pagingRouteName, IQueryStringFilter filter, IEnumerable<T> data, int pageIndex, int pageSize, int totalItems)
        {
            long startingItem = pageIndex * pageSize;
            long endingItem = startingItem + (data.Count() == 0 ? 0 : (data.Count() - 1));

            long lastPageIndex = (totalItems / pageSize);
            long nextPageIndex = pageIndex == lastPageIndex ? -1 : pageIndex + 1;
            Uri nextUrl = null;
            if (nextPageIndex >= 0)
            {
                nextUrl = new Uri(request.GetUrlHelper().Link(pagingRouteName, new { pageIndex = nextPageIndex, pageSize = pageSize }) + filter.ToQueryString());
            }

            long prevPageIndex = pageIndex == 0 ? -1 : pageIndex - 1;
            Uri prevUrl = null;
            if (prevPageIndex >= 0)
            {
                prevUrl = new Uri(request.GetUrlHelper().Link(pagingRouteName, new { pageIndex = prevPageIndex, pageSize = pageSize }) + filter.ToQueryString());
            }

            this.TotalPages = lastPageIndex + 1;
            this.CurrentPage = pageIndex;
            this.PageSize = pageSize;
            this.TotalItems = totalItems;
            this.FromItemIndex = startingItem;
            this.ToItemIndex = endingItem;
            if (nextUrl != null)
            {
                this.NextPageLink = new LinkView(nextUrl);
            }
            if (prevUrl != null)
            {
                this.PrevPageLink = new LinkView(prevUrl);
            }

            this.Data = data;
        }

    }
}