﻿using SmartCaps.FR.Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SmartCaps.FR.WebApi.Model
{
    public class UploadImagesResult
    {
        public UploadImagesResult()
        {
            this.Errors = new Dictionary<string, string>();
            this.OriginalFileNames = new Dictionary<string, string>();
            this.ImageRefs = new List<ImageRef>();
        }

        public IDictionary<string, string> Errors { get; private set; }

        public IList<ImageRef> ImageRefs { get; private set; }

        public IDictionary<string, string> OriginalFileNames { get; private set; }
    }

    
}