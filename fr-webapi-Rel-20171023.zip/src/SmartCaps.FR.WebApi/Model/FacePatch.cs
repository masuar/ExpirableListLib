﻿using Newtonsoft.Json;
using SmartCaps.FR.Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SmartCaps.FR.WebApi.Model
{
    public class FacePatch
    {
        [JsonProperty(PropertyName = "id", Order = 1)]
        public string Id { get; set; }

        [JsonProperty(PropertyName = "owner", Order = 2)]
        public string Owner { get; set; }

        [JsonProperty(PropertyName = "confirmed", Order = 3)]
        public bool? Confirmed { get; set; }

        [JsonProperty(PropertyName = "tags", Order = 4)]
        public IList<string> Tags { get; set; }

        [JsonProperty(PropertyName = "sienaRefs", Order = 5)]
        public IList<string> SienaRefs { get; set; }

        [JsonProperty(PropertyName = "focalPoints", Order = 6)]
        public IList<string> FocalPoints { get; set; }

        [JsonProperty(PropertyName = "metadata", Order = 7)]
        public IDictionary<string, string> Metadata { get; set; }

    }
}