﻿using SmartCaps.FR.Images;
using SmartCaps.FR.Images.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SmartCaps.FR.WebApi.Model
{
    /// <summary>
    /// Provides filtering properties for querying Faces
    /// </summary>
    public class FacesFilter : IQueryStringFilter
    {
        /// <summary>
        /// Tag value. You can provide a Tag (case sensitive) to filter by it. Also, you can provide several
        /// tags by providing several times the parameter in the query string. If not indicated, results will not be filtered
        /// by tag.
        /// </summary>
        public string[] Tags { get; set; }

        /// <summary>
        /// Siena reference. You can provide a Siena number to set to the face/s at insertion. Also, you can provide several
        /// Siena numbers by providing several times the parameter in the query string. If not indicated, face/s will not be assigned to any Siena reference.
        /// </summary>
        public string[] SienaRefs { get; set; }

        /// <summary>
        /// Focal Point. You can provide a Focal Point to set to the face/s at insertion. Also, you can provide several
        /// Focal Points by providing several times the parameter in the query string. If not indicated, face/s will not be assigned to any Focal Point.
        /// </summary>
        public string[] FocalPoints { get; set; }

        /// <summary>
        /// Metadata value. You can provide a metadata name and value (in the format metadataname|metadatavalue') to filter by them. Also, you can provide several
        /// metadata values by providing several times the parameter in the query string. If not indicated, results will not be filtered by metadata values.
        /// </summary>
        public string[] Metadata { get; set; }

        /// <summary>
        /// Confirmation value. You can provide the confirmation value of the faces you want to retrieve. If not indicated, 
        /// results will not be filtered by confirmation value.
        /// </summary>
        public bool? Confirmed { get; set; }

        /// <summary>
        /// Confirmation value. You can provide the confirmation value of the faces you want to retrieve. If not indicated, 
        /// results will not be filtered by confirmation value.
        /// </summary>
        public bool? WatchListed { get; set; }

        /// <summary>
        /// Owner value. You can ask only for faces the calling user is the owner of.
        /// </summary>
        //public bool? Mine { get; set; }

        /// <summary>
        /// Owner value.
        /// </summary>
        public string Owner { get; set; }

        public ImageMetadata GetMetadata()
        {
            ImageMetadata result = new ImageMetadata();
            if (this.Metadata != null)
            {
                foreach (var metadataValue in this.Metadata)
                {
                    string[] split = metadataValue.Split('|');
                    if (split.Length == 2)
                    {
                        if (result.ContainsKey(split[0]))
                        {
                            result[split[0]] = split[1];
                        }
                        else
                        {
                            result.Add(split[0], split[1]);
                        }
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Converts a Face filter into a query string.
        /// </summary>
        public string ToQueryString()
        {
            string result = string.Empty;
            IList<string> components = new List<string>();

            if (this.Confirmed != null)
            {
                string confVal = (bool)this.Confirmed ? "true" : "false";
                components.Add("confirmed=" + confVal);
            }

            //if (this.Mine != null)
            //{
            //    string mineVal = (bool)this.Mine ? "true" : "false";
            //    components.Add("mine=" + mineVal);
            //}

            if (!string.IsNullOrEmpty(this.Owner))
            {
                components.Add("owner=" + this.Owner);
            }


            if (this.Tags != null)
            {
                foreach (string tag in this.Tags)
                {
                    components.Add("tag=" + Uri.EscapeUriString(tag));
                }
            }

            if (this.Metadata != null)
            {
                foreach (string metadataValue in this.Metadata)
                {
                    components.Add("metadata=" + Uri.EscapeUriString(metadataValue));
                }
            }

            if (components.Count > 0)
            {
                result = "&" + string.Join("&", components);
            }

            return result;
        }
    }
}
