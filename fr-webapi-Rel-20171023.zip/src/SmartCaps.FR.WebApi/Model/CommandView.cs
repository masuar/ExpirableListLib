﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using SmartCaps.FR.Common.Model.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SmartCaps.FR.WebApi.Model
{
    public abstract class CommandView
    {
        protected CommandView(string errorMessage)
        {
            this.ErrorMessage = errorMessage;
        }

        protected CommandView(ICommand cmd)
        {
            this.CommandStatus = this.CalculateCommandStatus(cmd);
        }

        [JsonProperty(PropertyName = "command", Order = 1)]
        public LinkView CommandLink { get; protected set; }

        [JsonProperty(PropertyName = "token", Order = 2)]
        public string Token { get; protected set; }

        [JsonProperty(PropertyName = "errorMessage", Order = 3)]
        public string ErrorMessage { get; protected set; }

        [JsonConverter(typeof(StringEnumConverter))]
        [JsonProperty(PropertyName = "commandStatus", Order = 4)]
        public CommandStatus CommandStatus { get; private set; }

        protected CommandStatus CalculateCommandStatus(ICommand cmd)
        {
            CommandStatus status = CommandStatus.NotApplicable;

            if (cmd != null)
            {
                if (!string.IsNullOrEmpty(cmd.ErrorMessage))
                {
                    status = CommandStatus.Failed;
                }
                else if (cmd.TotalSteps > cmd.LastStepCompleted)
                {
                    status = CommandStatus.NotFinished;
                }
                else
                {
                    status = CommandStatus.Succeeded;
                }
            }

            return status;
        }

    }
}