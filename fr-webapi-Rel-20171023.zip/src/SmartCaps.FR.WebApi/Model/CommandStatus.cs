﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SmartCaps.FR.WebApi.Model
{
    public enum CommandStatus
    {
        NotApplicable,
        Succeeded,
        Failed,
        NotFinished
    }
}