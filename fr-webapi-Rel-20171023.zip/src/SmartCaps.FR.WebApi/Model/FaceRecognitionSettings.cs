﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SmartCaps.FR.WebApi.Model
{
    public class FaceRecognitionSettings
    {
        public FaceRecognitionSettings()
        {
            this.FaceQualityThreshold = new FaceQualityScoreThresholdSettings();
            this.AutoMatch = new MatchSettings();

        }

        [JsonProperty(PropertyName = "faceQualityThreshold", Order = 1)]
        public FaceQualityScoreThresholdSettings FaceQualityThreshold { get; set; }

        [JsonProperty(PropertyName = "autoMatch", Order = 2)]
        public MatchSettings AutoMatch { get; set; }

        [JsonProperty(PropertyName = "defaultPageSize", Order = 3)]
        public int DefaultPageSize { get; set; }

        [JsonProperty(PropertyName = "defaultTopNOptions", Order = 3)]
        public string DefaultTopNOptions { get; set; }
        

    }

    public class FaceQualityScoreThresholdSettings
    {
        [JsonProperty(PropertyName = "min", Order = 1)]
        public double Min { get; set; }

        [JsonProperty(PropertyName = "default", Order = 2)]
        public double Default { get; set; }


        [JsonProperty(PropertyName = "max", Order = 3)]
        public double Max { get; set; }

    }

    public class MatchSettings
    {
        private string tagString;

        [JsonProperty(PropertyName = "threshold", Order = 1)]
        public double Threshold { get; set; }

        [JsonProperty(PropertyName = "tagString", Order = 2)]
        public string TagString
        {
            get
            {
                return this.tagString;
            }

            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    this.tagString = value.ToLower();
                }
                else
                {
                    this.tagString = value;
                }
                
            }
        }
    }


}