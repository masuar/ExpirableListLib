﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SmartCaps.FR.WebApi.Model
{
    public class CommandsResultsView<C> : OpResults<C> where C:CommandView
    {
        [JsonProperty(PropertyName = "message", Order = 4)]
        public override string Message
        {
            get
            {
                int total = this.Success.Count + this.Failed.Count + this.NotFinished.Count;
                int processed = this.Success.Count + this.Failed.Count;
                if (total == 0)
                {
                    processed = total = 1;
                }

                return string.Format("{0}/{1} commands where processed, {2} were successful, {3} were failed.", processed, total, this.Success.Count, this.Failed.Count);

            }
        }

    }
}