﻿using Newtonsoft.Json;
using SmartCaps.FR.Common.Model.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;

namespace SmartCaps.FR.WebApi.Model
{
    public class EnrollCommandView : CommandView
    {
        public EnrollCommandView(string errorMessage)
            : base(errorMessage)
        {
        }

        public EnrollCommandView(IFacesCommand cmd, HttpRequestMessage request)
            : base(cmd)
        {
            this.CommandLink = new Model.LinkView(new Uri(request.GetUrlHelper().Link("GetEnrollCommand", new { token = cmd.Token })));
            this.Token = cmd.Token;
            this.EnrolledFaces = cmd.Faces.Where(f => f.AlreadyExisting == false).Select(f => new FaceLinks(f.Id, request)).ToList();
            this.AlreadyExistingFaces = cmd.Faces.Where(f => f.AlreadyExisting == true).Select(f => new FaceLinks(f.Id, request)).ToList();
            this.FaceQualityScoreThreshold = cmd.FaceQualityScoreThreshold;
        }

        [JsonProperty(PropertyName = "enrolledFaces", Order = 5)]
        public IEnumerable<FaceLinks> EnrolledFaces { get; private set; }

        [JsonProperty(PropertyName = "alreadyExistingFaces", Order = 6)]
        public IEnumerable<FaceLinks> AlreadyExistingFaces { get; private set; }

        [JsonProperty(PropertyName = "faceQualityScoreThreshold", Order = 7)]
        public double FaceQualityScoreThreshold { get; private set; }

    }
}