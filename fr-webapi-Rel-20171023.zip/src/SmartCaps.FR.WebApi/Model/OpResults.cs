﻿using Newtonsoft.Json;
using SmartCaps.FR.Common.Model.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SmartCaps.FR.WebApi.Model
{
    public class OpResults<T>
    {
        public OpResults()
        {
            this.Success = new List<T>();
            this.Failed = new List<T>();
            this.NotFinished = new List<T>();
        }

        [JsonProperty(PropertyName = "success", Order = 1)]
        public List<T> Success { get; set; }

        [JsonProperty(PropertyName = "failed", Order = 2)]
        public List<T> Failed { get; set; }

        [JsonProperty(PropertyName = "notFinished", Order = 3)]
        public List<T> NotFinished { get; set; }

        [JsonProperty(PropertyName = "message", Order = 4)]
        public virtual string Message
        {
            get
            {
                int total = this.Success.Count + this.Failed.Count + this.NotFinished.Count;
                int processed = this.Success.Count + this.Failed.Count;
                if (total == 0)
                {
                    processed = total = 1;
                }

                return string.Format("{0}/{1} items where processed, {2} were successful, {3} were failed.", processed, total, this.Success.Count, this.Failed.Count);

            }
        }
    }
}