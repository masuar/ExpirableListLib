﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SmartCaps.FR.WebApi.Model
{
    public class LinkView
    {
        public LinkView(Uri href)
        {
            this.Href = href;
        }

        [JsonProperty(PropertyName = "href", Order = 1)]
        public Uri Href { get; private set; }

    }
}