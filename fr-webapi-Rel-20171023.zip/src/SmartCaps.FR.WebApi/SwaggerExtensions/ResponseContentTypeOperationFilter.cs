﻿using Swashbuckle.Swagger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.Description;

namespace SmartCaps.FR.WebApi.SwaggerExtensions
{
    public class ResponseContentTypeOperationFilter : IOperationFilter
    {
        public void Apply(Operation operation, SchemaRegistry schemaRegistry, ApiDescription apiDescription)
        {
            var requestAttributtes = apiDescription.GetControllerAndActionAttributes<SwaggerResponseContentTypeAttribute>().FirstOrDefault();

            if (requestAttributtes != null)
            {
                if (requestAttributtes.Exclusive)
                {
                    operation.produces.Clear();
                    operation.consumes.Clear();
                }

                operation.produces.Add(requestAttributtes.ResponseType);
                operation.consumes.Add(requestAttributtes.ResponseType);
            }
        }
    }
}