﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SmartCaps.FR.WebApi.SwaggerExtensions
{
    [AttributeUsage(AttributeTargets.Method)]
    public sealed class SwaggerResponseContentTypeAttribute : Attribute
    {
        public SwaggerResponseContentTypeAttribute(string responseType)
        {
            this.ResponseType = responseType;
        }

        public string ResponseType { get; private set; }

        public bool Exclusive { get; set; }
    }
}