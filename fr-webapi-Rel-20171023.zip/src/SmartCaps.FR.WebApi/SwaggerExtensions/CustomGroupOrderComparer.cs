﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SmartCaps.FR.WebApi.SwaggerExtensions
{
    // TODO: Find a better way of doing this
    public class CustomGroupOrderComparer : IComparer<string>
    {
        public int Compare(string x, string y)
        {
            if (x == y)
            {
                return 0;
            }
            else if (x.ToLower().Contains("face"))
            {
                return 1;
            }
            else if (x.ToLower().Contains("commands") && y.ToLower().Contains("face"))
            {
                return 1;
            }
            else if (x.ToLower().Contains("commands") && y.ToLower().Contains("misc"))
            {
                return -1;
            }
            else if (x.ToLower().Contains("misc"))
            {
                return -1;
            }
            else
            {
                return x.CompareTo(y);
            }

        }
    }
}