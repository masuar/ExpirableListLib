﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SmartCaps.FR.WebApi.SwaggerExtensions
{
    public class HideInDocsAttribute : Attribute
    {
    }
}