﻿using log4net;
using SmartCaps.FR.Common.Model;
using SmartCaps.FR.Common.Model.Commands;
using SmartCaps.FR.Images.Model;
using SmartCaps.FR.Images.Services;
using SmartCaps.FR.WebApi.AppServices;
using SmartCaps.FR.WebApi.Filters;
using SmartCaps.FR.WebApi.Model;
using SmartCaps.FR.WebApi.SwaggerExtensions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;

namespace SmartCaps.FR.WebApi.Controllers
{
    [IdentityBasicAuthentication]
    [Authorize]
    public class CommandsController : ApiController
    {
        private CommandServices cmdSvc;
        private ImageServices imgSvc;
        private IRequestingUserServices userSvc;
        private ILog log;

        public CommandsController(CommandServices cmdSvc, ImageServices imgSvc, IRequestingUserServices userSvc, ILog log)
        {
            this.cmdSvc = cmdSvc;
            this.imgSvc = imgSvc;
            this.userSvc = userSvc;
            this.log = log;
        }

        /// <summary>
        /// Post a command to find similar faces to those contained in the specified referenced image/s.
        /// </summary>
        /// <param name="imageRefs">Image references to evaluate.</param>
        /// <param name="faceQualityScoreThreshold">Faces which quality score is under this value won't be extracted. Default is 0.85.</param>
        /// <param name="topn">The number of similar faces to return. Default is 10.</param>
        /// <param name="async">If false, waits until the completion of the command/s. Default is False.</param>
        /// <param name="timeout">When sync, indicates the timeout in seconds. Default is 20.</param>
        /// <returns></returns>
        /// <remarks>
        /// Find similar faces to those contained in the specified referenced image/s.
        /// </remarks>
        ///[HideInDocs]
        [HttpPost]
        [MethodGroup("Commands management")]
        [Route("commands/eval/imagerefs")]
        [ResponseType(typeof(CommandsResultsView<EvalCommandView>))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public async Task<HttpResponseMessage> RecognizeFacesInRefImages([FromBody]ImageRef[] imageRefs, double faceQualityScoreThreshold = 0.85, int topn = 10, bool async = false, int timeout = 20)
        {
            this.log.DebugFormat("Request to '{0}' arrived!", Request.RequestUri);
            HttpResponseMessage response = null;
            if (imageRefs == null || imageRefs.Length == 0)
            {
                response = Request.CreateResponse(HttpStatusCode.BadRequest);
            }
            else
            {
                topn = this.ValidateTopN(topn);
                IList<ICommand> commandsPublished = new List<ICommand>();
                CommandsResultsView<EvalCommandView> resultsView = new CommandsResultsView<EvalCommandView>();
                foreach (ImageRef imageRef in imageRefs)
                {
                    var cmd = this.cmdSvc.PublishEvalImageCommand(imageRef, faceQualityScoreThreshold, topn);
                    commandsPublished.Add(cmd);
                    resultsView.NotFinished.Add(new EvalCommandView(cmd, Request));
                }

                if (!async)
                {
                    var temp = await this.cmdSvc.GetCommandsResult(commandsPublished, true, timeout);

                    resultsView.NotFinished.Clear();
                    resultsView.Success.AddRange(temp.Success.Select(sc => new EvalCommandView(sc as IEvalCommand, Request)));
                    resultsView.Failed.AddRange(temp.Failed.Select(sc => new EvalCommandView(sc as IEvalCommand, Request)));
                    resultsView.NotFinished.AddRange(temp.NotFinished.Select(sc => new EvalCommandView(sc as IEvalCommand, Request)));
                }

                response = Request.CreateResponse(HttpStatusCode.Accepted, resultsView);
            }

            response.Headers.Add("Access-Control-Allow-Origin", "*");
            this.log.DebugFormat("Request to '{0}' processed.", Request.RequestUri);
            return response;
        }

        /// <summary>
        /// Post a command to find similar faces to those contained in the specified image/s.
        /// </summary>
        /// <param name="faceQualityScoreThreshold">Faces which quality score is under this value won't be extracted. Default is 0.85.</param>
        /// <param name="topn">The number of similar faces to return. Default is 10.</param>
        /// <param name="async">If false, waits until the completion of the command/s. Default is False.</param>
        /// <param name="timeout">When sync, indicates the timeout in seconds. Default is 20.</param>
        /// <remarks>
        /// Find similar faces to those contained in the specified image/s. 
        /// </remarks>
        ///[HideInDocs]
        [HttpPost]
        [MethodGroup("Commands management")]
        [Route("commands/eval/images")]
        [ResponseType(typeof(CommandsResultsView<EvalCommandView>))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public async Task<HttpResponseMessage> RecognizeFacesInImages(double faceQualityScoreThreshold = 0.85, int topn = 10, bool async = false, int timeout = 20)
        {
            this.log.DebugFormat("Request to '{0}' arrived!", Request.RequestUri);
            HttpResponseMessage response = null;
            if (!Request.Content.IsMimeMultipartContent())
            {
                response = Request.CreateResponse(HttpStatusCode.BadRequest);
            }
            else
            {
                topn = this.ValidateTopN(topn);
                IList<ICommand> commandsPublished = new List<ICommand>();
                CommandsResultsView<EvalCommandView> resultsView = new CommandsResultsView<EvalCommandView>();

                var uploadResults = await this.UploadImagesInRequest(Request, ImageRefTypes.FILESYS, null);
                foreach (var imageRef in uploadResults.ImageRefs)
                {
                    var cmd = this.cmdSvc.PublishEvalImageCommand(imageRef, faceQualityScoreThreshold, topn);
                    commandsPublished.Add(cmd);
                    resultsView.NotFinished.Add(new EvalCommandView(cmd, Request));
                }

                foreach (var error in uploadResults.Errors)
                {
                    resultsView.Failed.Add(new EvalCommandView(string.Format("{0}: {1}", error.Key, error.Value)));
                }

                if (!async)
                {
                    var temp = await this.cmdSvc.GetCommandsResult(commandsPublished, true, timeout);

                    resultsView.NotFinished.Clear();
                    resultsView.Success.AddRange(temp.Success.Select(r => new EvalCommandView(r as IEvalCommand, Request)));
                    resultsView.Failed.AddRange(temp.Failed.Select(r => new EvalCommandView(r as IEvalCommand, Request)));
                    resultsView.NotFinished.AddRange(temp.NotFinished.Select(r => new EvalCommandView(r as IEvalCommand, Request)));
                }

                response = Request.CreateResponse(HttpStatusCode.Accepted, resultsView);
            }

            response.Headers.Add("Access-Control-Allow-Origin", "*");
            this.log.DebugFormat("Request to '{0}' processed.", Request.RequestUri);
            return response;
        }

        /// <summary>
        /// Post a command to find similar faces to the specified one.
        /// </summary>
        /// <param name="faceId">The face Id of the face to recognize.</param>
        /// <param name="topn">The number of similar faces to return. Default is 10.</param>
        /// <param name="async">If false, waits until the completion of the command/s. Default is False.</param>
        /// <param name="timeout">When sync, indicates the timeout in seconds. Default is 20.</param>
        /// <remarks>
        /// Find similar faces to the specified one. 
        /// </remarks>
        [HttpPost]
        [MethodGroup("Commands management")]
        [Route("commands/eval/faces/{faceId}", Name = "RecognizeFace")]
        [ResponseType(typeof(CommandsResultsView<EvalCommandView>))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public async Task<HttpResponseMessage> RecognizeStoredFace(string faceId, int topn = 10, bool async = false, int timeout = 20)
        {
            this.log.DebugFormat("Request to '{0}' arrived!", Request.RequestUri);
            HttpResponseMessage response = null;

            topn = this.ValidateTopN(topn);

            CommandsResultsView<EvalCommandView> resultsView = new CommandsResultsView<EvalCommandView>();
            var theCommand = this.cmdSvc.PublishEvalFaceCommand(faceId, null, topn);
            resultsView.NotFinished.Add(new EvalCommandView(theCommand, Request));

            if (!async)
            {
                var temp = await this.cmdSvc.GetCommandsResult(new ICommand[] { theCommand }, true, timeout);

                resultsView.NotFinished.Clear();
                resultsView.Success.AddRange(temp.Success.Select(r => new EvalCommandView(r as IEvalCommand, Request)));
                resultsView.Failed.AddRange(temp.Failed.Select(r => new EvalCommandView(r as IEvalCommand, Request)));
                resultsView.NotFinished.AddRange(temp.NotFinished.Select(r => new EvalCommandView(r as IEvalCommand, Request)));
            }

            response = Request.CreateResponse(HttpStatusCode.Accepted, resultsView);

            response.Headers.Add("Access-Control-Allow-Origin", "*");
            this.log.DebugFormat("Request to '{0}' processed.", Request.RequestUri);
            return response;

        }

        /// <summary>
        /// Post a command to enroll all the faces in the referenced image/s. 
        /// </summary>
        /// <param name="imageRefs">Image references to enroll.</param>
        /// <param name="options">The enroll operation parameters.</param>
        /// <param name="async">If false, waits until the completion of the enrollment/s. Default is False.</param>
        /// <param name="delayedEval">If true, indicates that the evaluation of the faces for tagging possible matches are run in a batch way, improving the performance of the system. Default is True.</param>
        /// <param name="timeout">When sync, indicates the timeout in seconds. Default is 20.</param>
        /// <remarks>
        /// Enrolls the faces contained in the referenced image into the face database. Can set confirmation, tags, and / or recognize faces within the operation.
        /// </remarks>
        ///[HideInDocs]
        [HttpPost]
        [MethodGroup("Commands management")]
        [Route("commands/enroll/imagerefs")]
        [ResponseType(typeof(CommandsResultsView<EnrollCommandView>))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public async Task<HttpResponseMessage> EnrollFacesInRefImages([FromBody]ImageRef[] imageRefs, [FromUri]EnrollOptions options, bool delayedEval = true, bool async = false, int timeout = 20)
        {
            this.log.DebugFormat("Request to '{0}' arrived!", Request.RequestUri);
            HttpResponseMessage response = null;
            IList<ICommand> commandsPublished = new List<ICommand>();
            CommandsResultsView<EnrollCommandView> commandsResults = new CommandsResultsView<EnrollCommandView>();

            if (imageRefs == null || imageRefs.Length == 0)
            {
                response = Request.CreateResponse(HttpStatusCode.BadRequest);
            }
            else
            {
                if (options == null)
                {
                    options = new EnrollOptions();
                }

                if (string.IsNullOrEmpty(options.RequestedBy))
                {
                    options.RequestedBy = this.userSvc.GetRequestingUserName(Request);
                }

                if (options.FaceQualityScoreThreshold <= 0)
                {
                    options.FaceQualityScoreThreshold = this.cmdSvc.DefaultFaceQualityScoreThreshold;
                }
                
                foreach (ImageRef imageRef in imageRefs)
                {
                    ICommand cmd = null;
                    if (delayedEval)
                    {
                        cmd = this.cmdSvc.PublishBatchEnrollImageCommand(imageRef, imageRef.Path, options);
                    }
                    else
                    {
                        cmd = this.cmdSvc.PublishEnrollImageCommand(imageRef, imageRef.Path, options);
                    }
                    
                    commandsPublished.Add(cmd);
                    commandsResults.NotFinished.Add(new EnrollCommandView((IFacesCommand)cmd, Request));
                }

                if (!async)
                {
                    var temp = await this.cmdSvc.GetCommandsResult(commandsPublished, true, timeout);

                    commandsResults.NotFinished.Clear();
                    commandsResults.Success.AddRange(temp.Success.Select(c => new EnrollCommandView((IFacesCommand)c, Request)));
                    commandsResults.Failed.AddRange(temp.Failed.Select(c => new EnrollCommandView((IFacesCommand)c, Request)));
                    commandsResults.NotFinished.AddRange(temp.NotFinished.Select(c => new EnrollCommandView((IFacesCommand)c, Request)));
                }

                response = Request.CreateResponse(HttpStatusCode.Created, commandsResults);

            }

            response.Headers.Add("Access-Control-Allow-Origin", "*");
            this.log.DebugFormat("Request to '{0}' processed.", Request.RequestUri);
            return response;
        }

        /// <summary>
        /// Post a command to uploads image/s and enrolls all the faces in them.
        /// </summary>
        /// <param name="imageRefType">Indicates the image storage to upload the image to. Default is FILESYS.</param>
        /// <param name="options">The enroll operation parameters.</param>
        /// <param name="delayedEval">If true, indicates that the evaluation of the faces for tagging possible matches are run in a batch way, improving the performance of the system. Default is True.</param>
        /// <param name="async">If false, waits until the completion of the enrollment/s. Default is False.</param>
        /// <param name="timeout">When sync, indicates the timeout in seconds. Default is 20.</param>
        /// <remarks>
        /// Enrolls the faces contained in the image/s into the face database, and uploads them to the image storage.
        /// Can set confirmation, tags and / or recognize faces within the operation.
        /// </remarks>
        [HttpPost]
        [MethodGroup("Commands management")]
        [Route("commands/enroll/images")]
        [ResponseType(typeof(CommandsResultsView<EnrollCommandView>))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public async Task<HttpResponseMessage> UploadAndEnrollFacesInImages([FromUri]EnrollOptions options, ImageRefTypes imageRefType = ImageRefTypes.FILESYS, bool delayedEval = true, bool async = false, int timeout = 20)
        {
            this.log.DebugFormat("Request to '{0}' arrived!", Request.RequestUri);
            HttpResponseMessage response = null;
            IList<ICommand> commandsPublished = new List<ICommand>();
            CommandsResultsView<EnrollCommandView> results = new CommandsResultsView<EnrollCommandView>();

            if (options == null)
            {
                options = new EnrollOptions();
            }

            if (!Request.Content.IsMimeMultipartContent() || (options.Tags != null && options.Tags.ContainsHtml()) || (options.SienaRefs != null && options.SienaRefs.ContainsHtml()) || (options.FocalPoints != null && options.FocalPoints.ContainsHtml()))
            {
                response = Request.CreateResponse(HttpStatusCode.BadRequest);
            }
            else
            {
                if (string.IsNullOrEmpty(options.RequestedBy))
                {
                    options.RequestedBy = this.userSvc.GetRequestingUserName(Request);
                }

                if (options.FaceQualityScoreThreshold <= 0)
                {
                    options.FaceQualityScoreThreshold = this.cmdSvc.DefaultFaceQualityScoreThreshold;
                }

                var uploadResults = await this.UploadImagesInRequest(Request, imageRefType, options);
                foreach (var imageRef in uploadResults.ImageRefs)
                {
                    string originalFileName = uploadResults.OriginalFileNames.ContainsKey(imageRef.Id) ? uploadResults.OriginalFileNames[imageRef.Id] : imageRef.Path;
                    ICommand cmd = null;
                    if (delayedEval)
                    {
                        cmd = this.cmdSvc.PublishBatchEnrollImageCommand(imageRef, originalFileName, options);
                    }
                    else
                    {
                        cmd = this.cmdSvc.PublishEnrollImageCommand(imageRef, originalFileName, options);
                    }

                    commandsPublished.Add(cmd);
                    results.NotFinished.Add(new EnrollCommandView((IFacesCommand)cmd, Request));
                }

                foreach (var error in uploadResults.Errors)
                {
                    results.Failed.Add(new EnrollCommandView(string.Format("{0}: {1}", error.Key, error.Value)));
                }

                if (!async)
                {
                    var temp = await this.cmdSvc.GetCommandsResult(commandsPublished, true, timeout);

                    results.NotFinished.Clear();
                    results.Success.AddRange(temp.Success.Select(c => new EnrollCommandView((IFacesCommand)c, Request)));
                    results.Failed.AddRange(temp.Failed.Select(c => new EnrollCommandView((IFacesCommand)c, Request)));
                    results.NotFinished.AddRange(temp.NotFinished.Select(c => new EnrollCommandView((IFacesCommand)c, Request)));
                }

                response = Request.CreateResponse(HttpStatusCode.Created, results);
            }

            response.Headers.Add("Access-Control-Allow-Origin", "*");
            this.log.DebugFormat("Request to '{0}' processed.", Request.RequestUri);
            return response;

        }

        /// <summary>
        /// Post a command to uploads video/s and enrolls all the faces contained in them.
        /// </summary>
        /// <param name="imageRefType">Indicates the image storage to upload the images to. Default is FILESYS.</param>
        /// <param name="options">The enroll operation parameters.</param>
        /// <param name="async">If false, waits until the completion of the enrollment/s. Default is False.</param>
        /// <param name="timeout">When sync, indicates the timeout in seconds. Default is 20.</param>
        /// <remarks>
        /// Enrolls the faces contained in the video/s into the face database, and uploads them to the image storage.
        /// Can set confirmation, tags and other information within the operation.
        /// </remarks>
        [HttpPost]
        [MethodGroup("Commands management")]
        [Route("commands/enroll/videos")]
        [ResponseType(typeof(CommandsResultsView<EnrollCommandView>))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public async Task<HttpResponseMessage> UploadAndEnrollFacesInVideos([FromUri]EnrollOptions options, ImageRefTypes imageRefType = ImageRefTypes.FILESYS, bool async = false, int timeout = 20)
        {
            this.log.DebugFormat("Request to '{0}' arrived!", Request.RequestUri);
            HttpResponseMessage response = null;
            IList<ICommand> commandsPublished = new List<ICommand>();
            CommandsResultsView<EnrollCommandView> results = new CommandsResultsView<EnrollCommandView>();

            if (options == null)
            {
                options = new EnrollOptions();
            }

            if (!Request.Content.IsMimeMultipartContent() || (options.Tags != null && options.Tags.ContainsHtml()) || (options.SienaRefs != null && options.SienaRefs.ContainsHtml()) || (options.FocalPoints != null && options.FocalPoints.ContainsHtml()))
            {
                response = Request.CreateResponse(HttpStatusCode.BadRequest);
            }
            else
            {
                if (string.IsNullOrEmpty(options.RequestedBy))
                {
                    options.RequestedBy = this.userSvc.GetRequestingUserName(Request);
                }

                if (options.FaceQualityScoreThreshold <= 0)
                {
                    options.FaceQualityScoreThreshold = this.cmdSvc.DefaultFaceQualityScoreThreshold;
                }

                var uploadResults = await this.UploadImagesInRequest(Request, imageRefType, options); // Well, this thing also uploads videos
                foreach (var videoRef in uploadResults.ImageRefs)
                {
                    string originalFileName = uploadResults.OriginalFileNames.ContainsKey(videoRef.Id) ? uploadResults.OriginalFileNames[videoRef.Id] : videoRef.Path;
                    ICommand cmd = this.cmdSvc.PublishEnrollImagesFromVideoCommand(videoRef, originalFileName, options);
                    commandsPublished.Add(cmd);
                    results.NotFinished.Add(new EnrollCommandView((IFacesCommand)cmd, Request));
                }

                foreach (var error in uploadResults.Errors)
                {
                    results.Failed.Add(new EnrollCommandView(string.Format("{0}: {1}", error.Key, error.Value)));
                }

                if (!async)
                {
                    var temp = await this.cmdSvc.GetCommandsResult(commandsPublished, true, timeout);

                    results.NotFinished.Clear();
                    results.Success.AddRange(temp.Success.Select(c => new EnrollCommandView((IFacesCommand)c, Request)));
                    results.Failed.AddRange(temp.Failed.Select(c => new EnrollCommandView((IFacesCommand)c, Request)));
                    results.NotFinished.AddRange(temp.NotFinished.Select(c => new EnrollCommandView((IFacesCommand)c, Request)));
                }

                response = Request.CreateResponse(HttpStatusCode.Created, results);
            }

            response.Headers.Add("Access-Control-Allow-Origin", "*");
            this.log.DebugFormat("Request to '{0}' processed.", Request.RequestUri);
            return response;

        }

        /// <summary>
        /// Gets the result of an enrollment command using its token.
        /// </summary>
        /// <param name="token">The token of the command to get.</param>
        /// <remarks>
        /// Use this endpoint to get the result of an enrollment.
        /// </remarks>
        [HttpGet]
        [MethodGroup("Commands management")]
        [Route("commands/enroll/{token}", Name = "GetEnrollCommand")]
        [ResponseType(typeof(EnrollCommandView))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public HttpResponseMessage GetEnrollCommandResult(string token)
        {
            this.log.DebugFormat("Request to '{0}' arrived!", Request.RequestUri);
            HttpResponseMessage response = null;
            EnrollCommandView result = null;
            if (string.IsNullOrEmpty(token))
            {
                response = Request.CreateResponse(HttpStatusCode.BadRequest);
            }
            else
            {
                var cmd = this.cmdSvc.GetCommandByToken(token);
                if (cmd == null)
                {
                    response = Request.CreateResponse(HttpStatusCode.NoContent);
                }
                else if (!(cmd is IFacesCommand))
                {
                    response = Request.CreateResponse(HttpStatusCode.BadRequest);
                }
                else
                {
                    result = new EnrollCommandView((IFacesCommand)cmd, Request);
                    response = Request.CreateResponse(HttpStatusCode.OK, result);
                }
            }

            response.Headers.Add("Access-Control-Allow-Origin", "*");
            this.log.DebugFormat("Request to '{0}' processed.", Request.RequestUri);
            return response;
        }

        /// <summary>
        /// Gets the result of an recognition command using its token.
        /// </summary>
        /// <param name="token">The token of the command to get.</param>
        /// <remarks>
        /// Use this endpoint to get the result of a recognition.
        /// </remarks>
        [HttpGet]
        [MethodGroup("Commands management")]
        [Route("commands/eval/{token}", Name = "GetEvalCommand")]
        [ResponseType(typeof(EvalCommandView))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public HttpResponseMessage GetEvalCommandResult(string token)
        {
            this.log.DebugFormat("Request to '{0}' arrived!", Request.RequestUri);
            HttpResponseMessage response = null;
            EvalCommandView result = null;
            if (!string.IsNullOrEmpty(token))
            {
                response = Request.CreateResponse(HttpStatusCode.BadRequest);
            }
            else
            {
                var cmd = this.cmdSvc.GetCommandByToken(token);
                if (cmd == null)
                {
                    response = Request.CreateResponse(HttpStatusCode.NoContent);
                }
                else if (!(cmd is IEvalCommand))
                {
                    response = Request.CreateResponse(HttpStatusCode.BadRequest);
                }
                else
                {
                    result = new EvalCommandView((IEvalCommand)cmd, Request);
                    response = Request.CreateResponse(HttpStatusCode.OK, result);
                }
            }

            response.Headers.Add("Access-Control-Allow-Origin", "*");
            this.log.DebugFormat("Request to '{0}' processed.", Request.RequestUri);
            return response;
        }

        private async Task<UploadImagesResult> UploadImagesInRequest(HttpRequestMessage request, ImageRefTypes imageRefType, EnrollOptions options)
        {
            UploadImagesResult result = new Model.UploadImagesResult();
            try
            {
                var filesReadToProvider = await request.Content.ReadAsMultipartAsync();
                int i = 0;
                foreach (var stream in filesReadToProvider.Contents)
                {
                    string filename = HttpContext.Current.Request.Files[i++].FileName;
                    try
                    {
                        ImageMetadata meta = new ImageMetadata(options.Metadata);
                        meta.Add("Uploaded on", DateTime.UtcNow.ToString());
                        meta.Add("Uploaded by", options.RequestedBy);

                        // Go for the file
                        byte[] imageBytes = await stream.ReadAsByteArrayAsync();
                        string imageId = this.imgSvc.SaveImage(imageRefType.ToString(), imageBytes, filename, meta);
                        var imageRef = new ImageRef() { Id = imageId, RefType = imageRefType };
                        result.ImageRefs.Add(imageRef);
                        result.OriginalFileNames.Add(imageId, filename);
                        this.log.DebugFormat("File '{0}' uploaded as '{1}'.", filename, imageId);
                    }
                    catch (Exception ex)
                    {
                        result.Errors.Add(filename, string.Format("{0} - {1}", ex.GetType().ToString(), ex.Message));
                    }
                }
            }
            catch (IOException ex)
            {
                string message = string.Format("{0} - {1}", ex.GetType().ToString(), ex.Message);
                if (ex.InnerException != null)
                {
                    message = string.Format("{0} - {1}", ex.InnerException.GetType().ToString(), ex.InnerException.Message);
                }
                result.Errors.Add("Error during upload", message);
            }

            return result;

        }

        private int ValidateTopN(int topn)
        {
            if (topn < 0 || topn > 100)
            {
                topn = 10;
                this.log.Warn("Invalid value for TopN. Setting it to 10.");
            }

            return topn;
        }
    }
}
