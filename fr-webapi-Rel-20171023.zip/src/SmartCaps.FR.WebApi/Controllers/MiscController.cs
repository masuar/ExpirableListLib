﻿using log4net;
using SmartCaps.FR.WebApi.AppServices;
using SmartCaps.FR.WebApi.Filters;
using SmartCaps.FR.WebApi.Model;
using SmartCaps.FR.WebApi.SwaggerExtensions;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;

namespace SmartCaps.FR.WebApi.Controllers
{
    //[Filters.CustomHttpAuthorizeAttribute(Roles = "face_admin")]
    [IdentityBasicAuthentication]
    [Authorize]
    public class MiscController : ApiController
    {
        private CommandServices cmdSvc;
        private FaceRecognitionSettings settings;
        private FocalPointServices focalPointsSvc;
        private ILog log;

        public MiscController(CommandServices cmdSvc, FaceRecognitionSettings settings, FocalPointServices focalPointsSvc, ILog log)
        {
            this.cmdSvc = cmdSvc;
            this.focalPointsSvc = focalPointsSvc;
            this.settings = settings;
            this.log = log;
        }

        /// <summary>
        /// Checks the health of the service.
        /// </summary>
        /// <remarks>
        /// Use this endpoint to check if the Face Recognition service is up and running. Service could be GREEN (all OK), YELLOW (performance issues), or RED (vital components down).
        /// </remarks>
        [HttpGet]
        [AllowAnonymous]
        [MethodGroup("Misc")]
        [Route("status")]
        [ResponseType(typeof(IAmAlive))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public async Task<HttpResponseMessage> IAmAlive()
        {
            HttpResponseMessage response = null;

            var alive = await this.cmdSvc.GetServiceStatus();
            response = Request.CreateResponse(HttpStatusCode.OK, alive);
            response.Headers.Add("Access-Control-Allow-Origin", "*");
            return response;
        }

        /// <summary>
        /// Gets the face recognition settings of the service.
        /// </summary>
        /// <remarks>
        /// Use this endpoint to get the Face Recognition settings.
        /// </remarks>
        [HttpGet]
        [MethodGroup("Misc")]
        [Route("settings")]
        [ResponseType(typeof(FaceRecognitionSettings))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public async Task<HttpResponseMessage> GetSettings()
        {
            HttpResponseMessage response = null;

            response = Request.CreateResponse(HttpStatusCode.OK, this.settings);
            response.Headers.Add("Access-Control-Allow-Origin", "*");
            return response;
        }
        

        /// <summary>
        /// All the focal point names of Europol (cached).
        /// </summary>
        /// <remarks>
        /// Returns a list of focal point names.
        /// </remarks>
        [HttpGet]
        [MethodGroup("Misc")]
        [Route("focalpoints", Name = "GetExistingFocalPoints")]
        [ResponseType(typeof(List<string>))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public HttpResponseMessage GetFocalPoints()
        {
            HttpResponseMessage response = null;
            var focalPoints = this.focalPointsSvc.GetAllFocalPoints();
            if (focalPoints != null)
            {
                response = Request.CreateResponse(HttpStatusCode.OK, focalPoints);
            }
            else
            {
                response = Request.CreateResponse(HttpStatusCode.NoContent);
            }

            return response;
        }


    }

}
