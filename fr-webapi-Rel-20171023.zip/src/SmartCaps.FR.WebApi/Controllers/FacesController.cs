﻿using log4net;
using SmartCaps.FR.Common.Model;
using SmartCaps.FR.WebApi.Model;
using SmartCaps.FR.WebApi.AppServices;
using SmartCaps.FR.WebApi.SwaggerExtensions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using System.Threading.Tasks;
using SmartCaps.FR.Common.Model.Commands;
using System.Web;
using SmartCaps.FR.Images.Services;
using SmartCaps.FR.WebApi.Filters;

namespace SmartCaps.FR.WebApi.Controllers
{
    [IdentityBasicAuthentication]
    [Authorize]
    public class FacesController : ApiController
    {
        private ILog log;
        private FaceServices faceSvc;
        private CommandServices cmdSvc;
        private ImageServices imgSvc;
        private IRequestingUserServices userSvc;

        public FacesController(FaceServices faceSvc, CommandServices cmdSvc, ImageServices imgSvc, IRequestingUserServices userSvc, ILog log)
        {
            this.faceSvc = faceSvc;
            this.cmdSvc = cmdSvc;
            this.imgSvc = imgSvc;
            this.userSvc = userSvc;
            this.log = log;
        }

        /// <summary>
        /// Retrieves faces data by several criteria including confirmation info, tags, or metadata.
        /// </summary>
        /// <param name="filter">The filter object.</param>
        /// <param name="withMetadata">if False, the face data metadata will not be retrieved. Default is True.</param>
        /// <param name="pageIndex">For paging purposes, the desired index page.</param>
        /// <param name="pageSize">For paging purposes, the desired page size.</param>
        /// <remarks>
        /// Returns a set of faces by criteria. Returns NoContent (204) no faces satisfies the criteria.
        /// </remarks>
        [HttpGet]
        [MethodGroup("Face management")]
        [Route("faces", Name = "GetFaces")]
        [ResponseType(typeof(PagedResult<FaceView>))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public HttpResponseMessage GetFaces([FromUri] FacesFilter filter, bool withMetadata = true, int pageIndex = 0, int pageSize = 100)
        {
            HttpResponseMessage response = null;
            if (filter == null)
            {
                filter = new FacesFilter();
            }

            if ((filter.SienaRefs != null && filter.SienaRefs.ContainsHtml()) ||
                (filter.Tags != null && filter.Tags.ContainsHtml()) ||
                (filter.FocalPoints != null && filter.FocalPoints.ContainsHtml()))
            {
                response = Request.CreateResponse(HttpStatusCode.BadRequest);
            }
            else
            {
                int totalFaces = this.faceSvc.GetFacesCount(filter.GetMetadata(), filter.Owner, filter.Tags, filter.SienaRefs, filter.FocalPoints, filter.Confirmed);
                IEnumerable<FaceView> facesData = this.faceSvc.GetFacesData(filter.GetMetadata(), filter.Owner, filter.Tags, filter.SienaRefs, filter.FocalPoints, filter.Confirmed, withMetadata, false, pageIndex, pageSize)
                    .Select(f => new FaceView(f, Request));

                var result = new PagedResult<FaceView>(Request, "GetFaces", filter, facesData, pageIndex, pageSize, totalFaces);

                response = Request.CreateResponse(HttpStatusCode.OK, result);
            }

            response.Headers.Add("Access-Control-Allow-Origin", "*");
            return response;
        }

        /// <summary>
        /// Distinct Siena numbers that are assigned to any face in the FACE system (cached).
        /// </summary>
        /// <remarks>
        /// Returns a list of Siena references.
        /// </remarks>
        [HttpGet]
        [MethodGroup("Face management")]
        [Route("faces/sienarefs", Name = "GetExistingSienaRefs")]
        [ResponseType(typeof(List<string>))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public HttpResponseMessage GetSienaRefs()
        {
            HttpResponseMessage response = null;
            var sienaRefs = this.faceSvc.GetSienaRefsFromFaces();
            if (sienaRefs != null)
            {
                response = Request.CreateResponse(HttpStatusCode.OK, sienaRefs);
            }
            else
            {
                response = Request.CreateResponse(HttpStatusCode.NoContent);
            }

            return response;
        }

        /// <summary>
        /// Distinct tags that are assigned to any face in the FACE system (cached).
        /// </summary>
        /// <remarks>
        /// Returns a list of tags.
        /// </remarks>
        [HttpGet]
        [MethodGroup("Face management")]
        [Route("faces/tags", Name = "GetExistingTags")]
        [ResponseType(typeof(List<string>))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public HttpResponseMessage GetTags()
        {
            HttpResponseMessage response = null;
            var sienaRefs = this.faceSvc.GetTagsFromFaces();
            if (sienaRefs != null)
            {
                response = Request.CreateResponse(HttpStatusCode.OK, sienaRefs);
            }
            else
            {
                response = Request.CreateResponse(HttpStatusCode.NoContent);
            }

            return response;
        }

        /// <summary>
        /// All usernames present in the database
        /// </summary>
        /// <remarks>
        /// Returns a list of usernames.
        /// </remarks>
        [HttpGet]
        [MethodGroup("Face management")]
        [Route("faces/owners", Name = "GetUsernames")]
        [ResponseType(typeof(List<string>))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public HttpResponseMessage GetOwners()
        {
            HttpResponseMessage response = null;
            var users = this.faceSvc.GetOwnersFromFaces();
            if (users != null)
            {
                response = Request.CreateResponse(HttpStatusCode.OK, users);
            }
            else
            {
                response = Request.CreateResponse(HttpStatusCode.NoContent);
            }

            return response;
        }

        /// <summary>
        /// Retrieves face data using its Id.
        /// </summary>
        /// <param name="id">The face unique identifier.</param>
        /// <param name="withMetadata">if False, the face data metadata will not be retrieved. Default is True.</param>
        /// <remarks>
        /// Returns face data by its Id. Returns NoContent (204) if the face is not found.
        /// </remarks>
        [HttpGet]
        [MethodGroup("Face management")]
        [Route("faces/{id}", Name = "GetFaceData")]
        [ResponseType(typeof(FaceView))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public HttpResponseMessage GetFaceDataById(string id, bool withMetadata = true)
        {
            HttpResponseMessage response = null;
            Face theFace = this.faceSvc.GetFaceDataById(id, withMetadata, includeFeatures: false);

            if (theFace != null)
            {
                FaceView faceView = new FaceView(theFace, Request);
                response = Request.CreateResponse(HttpStatusCode.OK, faceView);
            }
            else
            {
                response = Request.CreateResponse(HttpStatusCode.NoContent);
            }

            response.Headers.Add("Access-Control-Allow-Origin", "*");
            return response;
        }

        /// <summary>
        /// Retrieves the face features using its Id.
        /// </summary>
        /// <param name="id">The face unique identifier.</param>
        /// <remarks>
        /// Returns the face features by its Id. Returns NoContent (204) if the face is not found.
        /// </remarks>
        [HttpGet]
        [MethodGroup("Face management")]
        [Route("faces/{id}/features", Name = "GetFaceFeatures")]
        [ResponseType(typeof(Face))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public HttpResponseMessage GetFaceFeaturesById(string id)
        {
            HttpResponseMessage response = null;
            Face face = this.faceSvc.GetFaceDataById(id, includeMetadata: false, includeFeatures: true);

            if (face != null)
            {
                response = Request.CreateResponse(HttpStatusCode.OK, face);
            }
            else
            {
                response = Request.CreateResponse(HttpStatusCode.NoContent);
            }

            response.Headers.Add("Access-Control-Allow-Origin", "*");
            return response;
        }

        /// <summary>
        /// Retrieves a face image using its Id.
        /// </summary>
        /// <param name="id">The face unique identifier.</param>
        /// <returns></returns>
        /// <remarks>
        /// Returns a face image by its Id. Returns NoContent (204) if the face is not found.
        /// </remarks>
        [HttpGet]
        [MethodGroup("Face management")]
        [Route("faces/{id}/image", Name = "GetFaceImage")]
        [ResponseType(typeof(System.Drawing.Bitmap))]
        [SwaggerResponseContentType("image/jpg", Exclusive = true)]
        public HttpResponseMessage GetFaceImageById(string id)
        {
            HttpResponseMessage response = null;
            byte[] img = this.faceSvc.GetFaceImageById(id, full: false);
            if (img != null)
            {
                response = Request.CreateResponse(HttpStatusCode.OK);
                response.Content = new StreamContent(new MemoryStream(img));
                response.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
                response.Content.Headers.ContentDisposition.FileName = string.Format("{0}.jpg", id); // TODO: Fix this
                response.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("image/jpg");
            }
            else
            {
                response = Request.CreateResponse(HttpStatusCode.NoContent);
            }

            response.Headers.Add("Access-Control-Allow-Origin", "*");
            return response;
        }

        /// <summary>
        /// Retrieves a face full image using its Id.
        /// </summary>
        /// <param name="id">The face unique identifier.</param>
        /// <returns></returns>
        /// <remarks>
        /// Returns a face image by its Id. Returns NoContent (204) if the face is not found.
        /// </remarks>
        [HttpGet]
        [MethodGroup("Face management")]
        [Route("faces/{id}/fullimage", Name = "GetFaceFullImage")]
        [ResponseType(typeof(System.Drawing.Bitmap))]
        [SwaggerResponseContentType("image/jpg", Exclusive = true)]
        public HttpResponseMessage GetFaceFullImageById(string id)
        {
            HttpResponseMessage response = null;
            byte[] img = this.faceSvc.GetFaceImageById(id, full: true);
            if (img != null)
            {
                response = Request.CreateResponse(HttpStatusCode.OK);
                response.Content = new StreamContent(new MemoryStream(img));
                response.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
                response.Content.Headers.ContentDisposition.FileName = string.Format("{0}.jpg", id); // TODO: Fix this
                response.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("image/jpg");
            }
            else
            {
                response = Request.CreateResponse(HttpStatusCode.NoContent);
            }

            response.Headers.Add("Access-Control-Allow-Origin", "*");
            return response;
        }

        /// <summary>
        /// Removes a face using its Id.
        /// </summary>
        /// <param name="id">The face unique identifier.</param>
        /// <remarks>
        /// Removes a face by its Id. Returns NoContent (204) if the face is not found.
        /// </remarks>
        [HttpDelete]
        [MethodGroup("Face management")]
        [Route("faces/{id}")]
        [ResponseType(typeof(OpResults<string>))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public async Task<HttpResponseMessage> RemoveFaceById(string id)
        {
            HttpResponseMessage response = null;
            var result = new OpResults<string>();

            var cmd = this.cmdSvc.PublishRemoveFacesCommand(new string[] { id });
            var temp = await this.cmdSvc.GetCommandsResult(new ICommand[] { cmd }, true, 20);

            foreach (var successCmd in temp.Success)
            {
                foreach (var faceId in ((RemoveFacesCommand)successCmd).Faces.Select(f => f.Id))
                {
                    result.Success.Add(faceId);
                }
            }

            foreach (var failedCmd in temp.Failed)
            {
                foreach (var faceId in ((RemoveFacesCommand)failedCmd).Faces.Select(f => f.Id))
                {
                    result.Failed.Add(faceId);
                }
            }

            response = Request.CreateResponse(HttpStatusCode.OK, result);
            response.Headers.Add("Access-Control-Allow-Origin", "*");

            return response;
        }

        /// <summary>
        /// Removes faces using their Ids.
        /// </summary>
        /// <param name="ids">The set of unique identifiers of faces that will be deleted.</param>
        /// <remarks>
        /// Removes a set of faces by their Ids.
        /// </remarks>
        [HttpDelete]
        [MethodGroup("Face management")]
        [Route("faces")]
        [ResponseType(typeof(OpResults<string>))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public async Task<HttpResponseMessage> RemoveFacesById([FromBody]string[] ids)
        {
            HttpResponseMessage response = null;
            var result = new OpResults<string>();

            var cmd = this.cmdSvc.PublishRemoveFacesCommand(ids);
            var temp = await this.cmdSvc.GetCommandsResult(new ICommand[] { cmd }, true, 20);

            foreach (var successCmd in temp.Success)
            {
                foreach (var faceId in ((RemoveFacesCommand)successCmd).Faces.Select(f => f.Id))
                {
                    result.Success.Add(faceId);
                }
            }

            foreach (var failedCmd in temp.Failed)
            {
                foreach (var faceId in ((RemoveFacesCommand)failedCmd).Faces.Select(f => f.Id))
                {
                    result.Failed.Add(faceId);
                }
            }

            response = Request.CreateResponse(HttpStatusCode.OK, result);
            response.Headers.Add("Access-Control-Allow-Origin", "*");

            return response;
        }

        /// <summary>
        /// Patches (modifies) the specified face/s. Can modify confirmation info, tags or metadata.
        /// </summary>
        /// <param name="facePatches">A set of face properties to be patched (confirmation, tags, metadata).</param>
        /// <remarks>
        /// Modifies the specified faces. Use this endpoints to confirm, add or remove tags or metadata.
        /// </remarks>
        [HttpPatch]
        [MethodGroup("Face management")]
        [Route("faces")]
        [ResponseType(typeof(OpResults<FaceView>))]
        [SwaggerResponseContentType("application/json", Exclusive = true)]
        public HttpResponseMessage PatchFaces(IEnumerable<FacePatch> facePatches)
        {
            HttpResponseMessage response = null;
            OpResults<FaceView> results = new OpResults<FaceView>();
            foreach (FacePatch facePatch in facePatches)
            {
                Face oldFace = this.faceSvc.GetFaceDataById(facePatch.Id, false, false);
                if (oldFace != null)
                {
                    bool isOk = true;
                    if (facePatch.Owner != null)
                    {
                        isOk = isOk && this.faceSvc.SetFaceOwner(oldFace.Id, facePatch.Owner);
                        oldFace.Owner = facePatch.Owner;
                    }

                    if (facePatch.Confirmed != null)
                    {
                        isOk = isOk && this.faceSvc.SetFaceConfirmation(oldFace.Id, (bool)facePatch.Confirmed);
                        oldFace.Confirmed = (bool)facePatch.Confirmed;
                    }

                    if (facePatch.Tags != null)
                    {
                        if (!facePatch.Tags.ContainsHtml())
                        {
                            isOk = isOk && this.faceSvc.SetFaceTags(oldFace.Id, facePatch.Tags);
                            oldFace.Tags = facePatch.Tags;
                        }
                        else
                        {
                            isOk = false;
                        }
                    }

                    if (facePatch.SienaRefs != null)
                    {
                        if (!facePatch.SienaRefs.ContainsHtml())
                        {
                            isOk = isOk && this.faceSvc.SetSienaRefs(oldFace.Id, facePatch.SienaRefs);
                            oldFace.SienaRefs = facePatch.SienaRefs;
                        }
                        else
                        {
                            isOk = false;
                        }
                    }

                    if (facePatch.FocalPoints != null)
                    {
                        if (!facePatch.FocalPoints.ContainsHtml())
                        {
                            isOk = isOk && this.faceSvc.SetFocalPoints(oldFace.Id, facePatch.FocalPoints);
                            oldFace.FocalPoints = facePatch.FocalPoints;
                        }
                        else
                        {
                            isOk = false;
                        }
                    }

                    if (facePatch.Metadata != null)
                    {
                        facePatch.Metadata = this.faceSvc.SetFaceMetadata(oldFace.Id, facePatch.Metadata);
                        isOk = isOk && facePatch.Metadata != null;
                        // Merge dicts
                        oldFace.Metadata = oldFace.Metadata.Concat(facePatch.Metadata).GroupBy(d => d.Key).ToDictionary(d => d.Key, d => d.First().Value);
                    }

                    var faceView = new FaceView(oldFace, Request);
                    if (isOk)
                    {
                        results.Success.Add(faceView);
                    }
                    else
                    {
                        faceView.ErrorMessage = "There was a problem patching the face.";
                        results.Failed.Add(faceView);
                    }
                }
                else
                {
                    results.Failed.Add(new FaceView(facePatch.Id, "Face not existing."));
                }
            }

            response = Request.CreateResponse(HttpStatusCode.OK, results);
            response.Headers.Add("Access-Control-Allow-Origin", "*");
            return response;
        }

    }
}