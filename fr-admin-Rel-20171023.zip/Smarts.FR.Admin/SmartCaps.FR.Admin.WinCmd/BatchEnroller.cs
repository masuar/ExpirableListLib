﻿using log4net;
using Newtonsoft.Json;
using SmartCaps.FR.Admin.FileReader;
using SmartCaps.FR.Admin.Model;
using SmartCaps.FR.Common.MimeTypes;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;

namespace SmartCaps.FR.Admin.WinCmd
{
    public class BatchEnroller
    {
        private Uri faceApiServer;
        private ILog log;
        private string basicAuthUser;
        private string basicAuthPwd;
        private MimeTypesHelper mimeTypesHelper = new MimeTypesHelper();

        public BatchEnroller(Uri faceApiServer, string basicAuthUser, string basicAuthPwd, ILog log)
        {
            this.faceApiServer = faceApiServer;
            this.basicAuthUser = basicAuthUser;
            this.basicAuthPwd = basicAuthPwd;
            this.log = log;
        }

        public void EnrollFrom(IFileReader imagesReader, EnrollOptions options)
        {
            var files = imagesReader.GetFileNames(options.FromDate, options.ToDate, options.Skip, options.Take);
            var originalEndpoint = this.GetEndpointFromOptions(options);
            var sienaNumsFromParams = this.GetSienaNumsFromOptions(options);
            var focalPointsFromParams = this.GetFocalPointsFromOptions(options);

            using (var client = new HttpClient(new HttpClientHandler() { UseDefaultCredentials = true }))
            {
                client.Timeout = TimeSpan.FromMinutes(options.EnrollTimeOut);
                var userPwString = string.Format("{0}:{1}", this.basicAuthUser, this.basicAuthPwd);
                var userPwArray = Encoding.ASCII.GetBytes(userPwString);
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(userPwArray));

                int filesCount = 0;
                foreach (var file in files)
                {
                    string endpoint = originalEndpoint;
                    filesCount++;
                    if (File.Exists(file.Path))
                    {
                        try
                        {
                            endpoint = this.GetCompleteEndpoint(sienaNumsFromParams, focalPointsFromParams, file, false, endpoint);

                            HttpContent fileStreamContent = new StreamContent(File.Open(file.Path, FileMode.Open, FileAccess.Read, FileShare.Read));
                            using (var formData = new MultipartFormDataContent())
                            {
                                formData.Add(fileStreamContent, "file", Path.GetFileName(file.Path));
                                this.log.DebugFormat("Calling {0}", endpoint);
                                var response = client.PostAsync(new Uri(this.faceApiServer, endpoint), formData).Result;
                                this.log.Debug("Call done.");
                                if (!response.IsSuccessStatusCode)
                                {
                                    this.log.ErrorFormat("File {0} - ({1}) {2} failed to enroll. Error '{3}'.", filesCount, file.Id, file.Path, response.StatusCode);
                                }
                                else
                                {
                                    try
                                    {
                                        string responseBody = response.Content.ReadAsStringAsync().Result;
                                        EnrollmentResponse enrollmentResponse = JsonConvert.DeserializeObject<EnrollmentResponse>(responseBody);
                                        string successLogMsg = this.ComposeSuccessLogMsg(filesCount, file, enrollmentResponse);
                                        this.log.Info(successLogMsg);
                                    }
                                    catch (Exception ex)
                                    {
                                        this.log.Warn("Unable to parse response.", ex);
                                        this.log.InfoFormat("File {0} - ({1}) {2} was successfully enrolled.", filesCount, file.Id, Path.GetFileName(file.Path));
                                    }

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            this.log.Error(String.Format("An error ocurred while processing file {0} - ({1}) {2}.", filesCount, file.Id, file.Path), ex);
                        }
                    }
                    else
                    {
                        this.log.WarnFormat("Unable to enroll file {0} - ({1}) {2}. File not found.", filesCount, file.Id, file.Path);
                    }
                }
            }

        }

        public void EnrollReferenceFrom(IFileReader imagesReader, EnrollOptions options)
        {
            var files = imagesReader.GetFileNames(options.FromDate, options.ToDate, options.Skip, options.Take);
            this.log.InfoFormat("{0} files to process.", files != null ? files.Count() : -1);
            var endpoint = this.GetEndpointFromOptions(options);
            var sienaNumsFromParams = this.GetSienaNumsFromOptions(options);
            var focalPointsFromParams = this.GetFocalPointsFromOptions(options);

            using (var client = new HttpClient(new HttpClientHandler() { UseDefaultCredentials = true }))
            {
                var userPwString = string.Format("{0}:{1}", this.basicAuthUser, this.basicAuthPwd);
                var userPwArray = Encoding.ASCII.GetBytes(userPwString);
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(userPwArray));
                int totalFiles = files.Count();
                int filesCount = 0;
                foreach (var file in files)
                {
                    filesCount++;
                    if (File.Exists(file.Path))
                    {
                        try
                        {
                            endpoint = this.GetCompleteEndpoint(sienaNumsFromParams, focalPointsFromParams, file, true, endpoint);
                            object[] imageRefs = new object[] { new { imageId = file.Id, imagePath = (string)null, refType = imagesReader.RefType } };
                            string body = JsonConvert.SerializeObject(imageRefs);
                            this.log.DebugFormat("Calling {0}", endpoint);
                            HttpContent bodyContent = new StringContent(body, Encoding.UTF8, "application/json");
                            var response = client.PostAsync(new Uri(this.faceApiServer, endpoint), bodyContent).Result;
                            this.log.Debug("Call done.");
                            if (!response.IsSuccessStatusCode)
                            {
                                this.log.ErrorFormat("File {0} - ({1}) {2} failed to enroll. Error '{3}'.", filesCount, file.Id, file.Path, response.StatusCode);
                            }
                            else
                            {
                                string responseBody = null;
                                try
                                {
                                    responseBody = response.Content.ReadAsStringAsync().Result;
                                    EnrollmentResponse enrollmentResponse = JsonConvert.DeserializeObject<EnrollmentResponse>(responseBody);
                                    string successLogMsg = this.ComposeSuccessLogMsg(filesCount, file, enrollmentResponse);
                                    this.log.Info(successLogMsg);
                                }
                                catch (Exception ex)
                                {
                                    this.log.WarnFormat("Unable to parse response.", ex);
                                    this.log.DebugFormat("Response: {0}", responseBody);
                                    this.log.InfoFormat("File {0} - ({1}) {2} was successfully enrolled.", filesCount, file.Id, Path.GetFileName(file.Path));
                                }
                                
                            }
                        }
                        catch (Exception ex)
                        {
                            this.log.Error(String.Format("An error ocurred while processing file {0} - ({1}) {2}.", filesCount, file.Id, file.Path), ex);
                        }
                    }
                    else
                    {
                        this.log.WarnFormat("Unable to enroll file {0} - ({1}) {2}. File not found.", filesCount, file.Id, file.Path);
                    }
                }

            }

        }

        private string ComposeSuccessLogMsg(int filesCount, FileResult file, EnrollmentResponse enrollmentResponse)
        {
            IList<string> partials = new List<string>();

            string basic = string.Format("File {0} - {1} - ", filesCount, this.GetShortenedString(Path.GetFileName(file.Path), 15));
            if (enrollmentResponse.EnrolledFaces > 0)
            {
                partials.Add(string.Format("{0} faces enrolled", enrollmentResponse.EnrolledFaces));
            }

            if (enrollmentResponse.AlreadyExistingFaces > 0)
            {
                partials.Add(string.Format("{0} faces updated", enrollmentResponse.AlreadyExistingFaces));
            }

            if (enrollmentResponse.Success.Count() > 0)
            {
                partials.Add(string.Format("{0} files processed", enrollmentResponse.Success.Count()));
            }

            if (enrollmentResponse.NotFinished.Count() > 0)
            {
                partials.Add(string.Format("{0} files pending", enrollmentResponse.NotFinished.Count()));
            }

            if (enrollmentResponse.Failed.Count() > 0)
            {
                partials.Add(string.Format("{0} files failed", enrollmentResponse.Failed.Count()));
            }

            return basic + string.Join(", ", partials) + ".";
        }

        private string GetShortenedString(string original, int charNo)
        {
            string result = string.Empty;
            if (!string.IsNullOrEmpty(original))
            {
                if (original.Length > charNo)
                {
                    result = original.Substring(0, charNo - 1) + "...";
                }
                else
                {
                    result = original;
                }
            }
            return result;
        }

        private string GetEndpointFromOptions(EnrollOptions options)
        {
            string baseString = "commands/enroll/{0}";
            var endpoint = string.Format("?async={0}&confirm={1}&requestedby={2}&faceQualityScoreThreshold={3}&batchmode={4}",
                options.Async,
                options.Confirm,
                options.RequestedBy,
                options.FaceThreshold,
                options.Batch);

            if  (!string.IsNullOrEmpty(options.Tags))
            {
                var splittedTags = options.Tags.Split(',');
                foreach(string tag in splittedTags)
                {
                    endpoint += string.Format("&tags={0}", Uri.EscapeDataString(tag.Trim()));
                }
            }

            return baseString + endpoint;
        }

        private IEnumerable<string> GetFocalPointsFromOptions(EnrollOptions options)
        {
            List<string> focalPointsFromParams = new List<string>();

            if (!string.IsNullOrEmpty(options.FocalPoints))
            {
                focalPointsFromParams.AddRange(options.FocalPoints.Split(',').Select(fp => fp.Trim()).Distinct());
            }

            return focalPointsFromParams;
        }

        private IEnumerable<string> GetSienaNumsFromOptions(EnrollOptions options)
        {
            List<string> sienaNumsFromParams = new List<string>();

            if (!string.IsNullOrEmpty(options.SienaNums))
            {
                sienaNumsFromParams.AddRange(options.SienaNums.Split(',').Select(sn => sn.Trim()).Distinct());
            }

            return sienaNumsFromParams;
        }

        private string GetCompleteEndpoint(IEnumerable<string> sienaNumsFromParams, IEnumerable<string> focalPointsFromParams, FileResult file, bool asReference, string endpoint)
        {
            if (this.mimeTypesHelper.Videos.IsSupported(file.MimeType))
            {
                if (asReference)
                {
                    throw new NotSupportedException("Enrolling videos 'AsReference' is not supported.");
                }
                endpoint = string.Format(endpoint, "videos");
            }
            else
            {
                string imagesMode = "images";
                if (asReference)
                {
                    imagesMode = "imageRefs";
                }

                endpoint = string.Format(endpoint, imagesMode);
            }

            foreach (string sienaNum in file.SienaNums)
            {
                endpoint += string.Format("&sienarefs={0}", Uri.EscapeDataString(sienaNum));
            }

            foreach (string sienaNum in sienaNumsFromParams)
            {
                if (!file.SienaNums.Contains(sienaNum))
                {
                    endpoint += string.Format("&sienarefs={0}", Uri.EscapeDataString(sienaNum));
                }
            }

            foreach (string focalPoint in file.FocalPoints)
            {
                endpoint += string.Format("&focalpoints={0}", Uri.EscapeDataString(focalPoint));
            }

            foreach (string focalPoint in focalPointsFromParams)
            {
                if (!file.FocalPoints.Contains(focalPoint))
                {
                    endpoint += string.Format("&focalpoints={0}", Uri.EscapeDataString(focalPoint));
                }
            }

            foreach (var kvp in file.Metadata)
            {
                endpoint += string.Format("&metadata={0}|{1}", kvp.Key, Uri.EscapeDataString(kvp.Value));
            }


            return endpoint;
        }

    }
}
