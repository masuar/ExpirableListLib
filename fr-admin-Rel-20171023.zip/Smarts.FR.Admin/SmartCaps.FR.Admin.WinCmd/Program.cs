﻿using CLAP;
using log4net;
using System;

namespace SmartCaps.FR.Admin.WinCmd
{
    class Program
    {
        static void Main(string[] args)
        {
            ILog log = log4net.LogManager.GetLogger("SmartCaps.FR.Admin");
            log4net.Config.XmlConfigurator.Configure();

            string appVersion = typeof(CommandLine).Assembly.GetName().Version.ToString();

            Console.WriteLine("SmartCaps FR Admin console application.");
            Console.WriteLine("Version " + appVersion);
            Console.WriteLine("Europol, 2017.");
            Console.WriteLine("");
            log.InfoFormat("Application started! App. version {0}; Params: {1}", appVersion, string.Join(" ", args));

            CommandLine cl = new CommandLine(log);
            Parser.Run(args, cl);

            log.Info("Application exited!");
        }
    }
}
