﻿using System;

namespace SmartCaps.FR.Admin.WinCmd
{
    public class EnrollOptions
    {
        private string requestedBy;

        public string RequestedBy
        {
            get
            {
                string result = this.requestedBy;

                if (string.IsNullOrEmpty(result))
                {
                    result = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                }

                return result;
            }
            set
            {
                this.requestedBy = value;
            }
        }

        public bool Async { get; set; }

        public bool Confirm { get; set; }

        public bool Batch { get; set; }

        public string Tags { get; set; }

        public string SienaNums { get; set; }

        public string FocalPoints { get; set; }

        public int Skip { get; set; }

        public int Take { get; set; }

        public DateTime FromDate { get; set; }

        public DateTime ToDate { get; set; }

        public double FaceThreshold { get; set; }

        public int EnrollTimeOut { get; set; }
    }
}
