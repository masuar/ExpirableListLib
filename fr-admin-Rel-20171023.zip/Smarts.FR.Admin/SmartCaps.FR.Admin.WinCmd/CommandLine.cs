﻿using CLAP;
using log4net;
using SmartCaps.FR.Admin.FileReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Admin.WinCmd
{
    public class CommandLine
    {
        private ILog log;

        public CommandLine(ILog log)
        {
            if (log == null)
            {
                throw new ArgumentNullException("log");
            }

            this.log = log;
        }

        [Help(Aliases = "h,?"), Empty]
        public void Help(string help)
        {
            Console.WriteLine(help);
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }

        [Verb(Description = "Request the enrollment of images from a plugin.", IsDefault = false, Aliases = "ep")]
        public void EnrollFromPlugin(
        [Description("Plugin DLL file.")][Required] string pluginDll,
        [Description("Plugin DLL parameters for instantiation. Separated by '|'")] string pluginParams,
        [Description("Face Recognition API server.")][DefaultValue("http://localhost:34456")] string server,
        [Description("Only get the items count.")][DefaultValue(false)]bool onlyCount,
        [Description("Do not upload images, use them as reference.")][DefaultValue(false)]bool asReference,
        [Description("Number of images to skip from the start.")][DefaultValue(0)]int skip,
        [Description("Maximum number of images to request enrollment.")][DefaultValue(10)]int take,
        [Description("From date.")]DateTime fromDate,
        [Description("To date.")]DateTime toDate,
        [Description("Confirm the resulting faces.")][DefaultValue(false)]bool confirm,
        [Description("The owner of the resulting faces.")]string requestedBy,
        [Description("The threshold for extracting faces.")][DefaultValue(0.95d)]double faceThreshold,
        [Description("The user for the face service authentication.")][DefaultValue("erpl")]string user,
        [Description("The pwd for the face service authentication.")][DefaultValue("ABCabc123.")]string pwd,
        [Description("Comma-separated tags to add to the resulting faces.")]string tags,
        [Description("Comma-separated Siena numbers to add to the resulting faces.")]string sienaNums,
        [Description("Comma-separated focal points to add to the resulting faces.")]string focalPoints,
        [Description("Use SYNC process.")][DefaultValue(false)]bool sync,
        [Description("Use BATCH enrollment.")][DefaultValue(false)]bool batch,
        [Description("Enroll time out in minutes.")][DefaultValue(10)] int enrollTimeOut,
        [Description("Verbose mode.")][DefaultValue(false)] bool verbose)
        {
            try
            {

                this.BeVerbose(verbose);

                string[] ps = null;
                if (!string.IsNullOrEmpty(pluginParams))
                {
                    ps = pluginParams.Split('|');
                }

                PluginLoader loader = new WinCmd.PluginLoader(this.log);
                IFileReader imageFileReader = loader.GetImageReaderFromPlugin(pluginDll, ps);

                if (imageFileReader != null)
                {
                    var options = new EnrollOptions()
                    {
                        Async = !sync,
                        Confirm = confirm,
                        Batch = batch,
                        RequestedBy = requestedBy,
                        Tags = tags,
                        SienaNums = sienaNums,
                        FocalPoints = focalPoints,
                        Skip = skip,
                        Take = take,
                        FromDate = fromDate,
                        ToDate = toDate,
                        FaceThreshold = faceThreshold,
                        EnrollTimeOut = enrollTimeOut
                    };

                    var apiServer = new Uri(server);
                    if (onlyCount)
                    {
                        int howMany = imageFileReader.Count(options.FromDate, options.ToDate);
                        this.log.InfoFormat("COUNT: {0}", howMany);
                    }
                    else
                    {
                        var enroller = new BatchEnroller(apiServer, user, pwd, this.log);
                        if (asReference)
                        {
                            enroller.EnrollReferenceFrom(imageFileReader, options);
                        }
                        else
                        {
                            enroller.EnrollFrom(imageFileReader, options);
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                this.log.Error("Unexpected error", ex);

            }
#if DEBUG
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
#endif
        }

        private void BeVerbose(bool verbose)
        {
            if (verbose)
            {
                ((log4net.Repository.Hierarchy.Logger)this.log.Logger).Level = log4net.Core.Level.Debug;
            }
            else
            {
                ((log4net.Repository.Hierarchy.Logger)this.log.Logger).Level = log4net.Core.Level.Info;
            }
        }

        [Verb(Description = "Remove old commands from SmartCaps.FR", IsDefault = false, Aliases = "cc")]
        public void CleanCommands(
        [Description("CommandsDB conn string.")][DefaultValue(@"Data Source=.\SQLEXPRESS;Initial Catalog=SmartCaps.FR;Integrated Security=True")] string cmdDbConn,
        [Description("Delete comands older then.")][Required] int daysOlder,
        [Description("Include commands that didn't finish properly.")][Required] bool includeErrorCmds,
        [Description("Timeout for commands cleanup.")] [DefaultValue(120)] int timeout,
        [Description("Verbose mode.")][DefaultValue(false)] bool verbose)
        {
            this.BeVerbose(verbose);
            var cmdRepo = new Common.Repos.SQLServer.SQLServerCommandRepository(cmdDbConn, timeout, this.log);
            var deletedTokens = cmdRepo.DeleteOldCommands(daysOlder, includeErrorCmds);

            foreach (string token in deletedTokens)
            {
                this.log.DebugFormat("Command '{0}' has been expired (deleted).", token);
            }

            this.log.InfoFormat("{0} commands have been expired (deleted).", deletedTokens.Count());
        }
    }
}
