﻿using log4net;
using SmartCaps.FR.Admin.FileReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Admin.WinCmd
{
    public class PluginLoader
    {
        private ILog log;

        public PluginLoader(ILog log)
        {
            this.log = log;
        }

        public IFileReader GetImageReaderFromPlugin(string pluginFile, params string[] args)
        {
            if (File.Exists(pluginFile) && Path.GetExtension(pluginFile).ToLower() == ".dll")
            {
                AssemblyName an = AssemblyName.GetAssemblyName(pluginFile);
                Assembly assembly = Assembly.Load(an);
                if (assembly == null)
                {
                    throw new Exception(string.Format("Unable to load '{0}' plugin assembly.", pluginFile));
                }

                Type pluginType = typeof(IFileReader);
                Type[] types = assembly.GetTypes();
                foreach (Type type in types)
                {
                    if (type.IsInterface || type.IsAbstract)
                    {
                        continue;
                    }
                    else
                    {
                        if (type.GetInterface(pluginType.FullName) != null)
                        {
                            try
                            {
                                FieldInfo fieldInfo = type.GetFields().SingleOrDefault(fi => fi.Name == "Help");
                                if (fieldInfo != null)
                                {
                                    this.log.Info(string.Format("Plugin help: {0}", fieldInfo.GetValue(null)));
                                }


                                var result = (IFileReader)Activator.CreateInstance(type, args);

                                System.Diagnostics.FileVersionInfo fvi = System.Diagnostics.FileVersionInfo.GetVersionInfo(assembly.Location);
                                string version = fvi.FileVersion;
                                this.log.InfoFormat("Plugin class '{0}' from '{1}' (version {2}) instantiated successfully.", type.Name, pluginFile, version);

                                return result;
                            }
                            catch (Exception ex)
                            {
                                string msg = string.Format("Error when instantiating the class '{0}' from '{1}'.", type.Name, pluginFile);
                                FieldInfo fieldInfo = type.GetFields().SingleOrDefault(fi => fi.Name == "Help");
                                if (fieldInfo != null)
                                {
                                    this.log.Error(string.Format("{0}. {1}", msg, fieldInfo.GetValue(null)), ex);
                                }
                                else
                                {
                                    this.log.Error(msg, ex);
                                }
                            }
                        }
                    }
                }

                throw new Exception(string.Format("Invalid plugin file '{0}'. It does not contain a IImageFileReader implementation.", pluginFile));
            }
            else
            {
                throw new Exception(string.Format("Unable to find '{0}' plugin assembly.", pluginFile));
            }
        }
    }
}
