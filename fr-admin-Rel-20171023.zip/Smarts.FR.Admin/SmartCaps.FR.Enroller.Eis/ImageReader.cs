﻿using log4net;
using SmartCaps.FR.Admin.FileReader;
using SmartCaps.FR.Common.MimeTypes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Enroller.Eis
{
    public class ImageReader : IFileReader
    {
        private string connString;
        private string tempPath;
        private string eisServer;
        private string urlTemplate = "<a href='{0}/EntityView.aspx?EntityName=Attachment&EntityId={1}'>Attachment {1}</a>";
        private string mimeTypesFilter;
        private ImageMimeTypes imageMimeTypes = new ImageMimeTypes();
        private ILog log;

        private readonly string baseQuery = "SELECT " +
                                                "ATT.ATT_ID, " +
	                                            "ATT.PERSON_PRS_ID, " +
                                                "ATT.ATTACHMENT, " +
                                                "ATT.FILENAME, " +
                                                "ATT.FILE_TYPE, " +
                                                "ATT.SIZE, " +
                                                "PERSON.FILENUMBER," +
                                                "ATT.CREATION_DATE," +
                                                "SUBSTRING([RESOURCE_TAG],17,100) AS MEMBER_STATE_NAME, " +
                                                "ROW_NUMBER() OVER(ORDER BY PERSON.CREATION_DATE) ROW_NUM " +
                                              "FROM " +
                                                "[ATTACHMENT] AS ATT " +
                                                    "JOIN[PERSON] ON ATT.PERSON_PRS_ID = [PERSON].PRS_ID " +
                                                    "JOIN[LUV_MEMBER_STATE] AS[MEMBER] ON ATT.MEMBERSTATE_LUV_ID = [MEMBER].LUV_ID " +
                                              "WHERE " +
                                                "ATT.PERSON_PRS_ID IS NOT NULL AND " +
                                                "ATT.ATTACHMENT IS NOT NULL AND " +
                                                "LOWER(ATT.FILE_TYPE) LIKE 'image%' AND " +
                                                "ATT.SIZE > 372 AND LOWER(ATT.FILE_TYPE) IN ({0}){1}";

        public static string Help = "Provide the following parameters for the constructor: string connString, string tempPath, string eisServer";

        public ImageReader(string connString, string tempPath, string eisServer)
        {
            this.log = log4net.LogManager.GetLogger("SmartCaps.FR.Enroller");
            log4net.Config.XmlConfigurator.Configure();

            if (string.IsNullOrEmpty(eisServer))
            {
                eisServer = "http://unknownserver";
            }

            this.connString = connString;
            this.tempPath = tempPath;
            this.eisServer = eisServer;
            this.imageMimeTypes.Support(".xxx.jpg", "image/pjpeg"); // Add this pjpeg stuff...
            var mimeTypes = this.imageMimeTypes.GetMimeTypes(null);
            this.mimeTypesFilter = string.Join(",", mimeTypes.Select(e => "'" + e.ToLower().Replace(".", string.Empty) + "'"));
        }

        public string PluginName
        {
            get
            {
                return "EisEnroller";
            }
        }

        public string RefType
        {
            get
            {
                return "FILESYS";
            }
        }

        public int Count(DateTime fromDate, DateTime toDate)
        {
            int howMany = 0;

            IList<SqlParameter> optionals = new List<SqlParameter>();
            string dateFilter = string.Empty;
            if (fromDate != default(DateTime))
            {
                dateFilter = " AND ATT.CREATION_DATE >= @FromDate";
                optionals.Add(new SqlParameter("@FromDate", SqlDbType.DateTime) { Value = fromDate });
            }

            if (toDate != default(DateTime))
            {
                dateFilter += " AND ATT.CREATION_DATE <= @ToDate";
                optionals.Add(new SqlParameter("@ToDate", SqlDbType.DateTime) { Value = toDate });
            }

            string getPicturesCountSqlCmd = ";WITH theQuery AS " +
                                        "(" + string.Format(this.baseQuery, this.mimeTypesFilter, dateFilter) + ") " +
                                        "SELECT count(*) FROM theQuery";

            using (SqlConnection conn = new SqlConnection(this.connString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(getPicturesCountSqlCmd, conn))
                {
                    theCommand.CommandTimeout = 300;
                    theCommand.Parameters.AddRange(optionals.ToArray());
                    howMany = (int)theCommand.ExecuteScalar();
                }
            }

            return howMany;

        }

        public IEnumerable<FileResult> GetFileNames(DateTime fromDate, DateTime toDate, int skip, int take)
        {
            IList<FileResult> files = new List<FileResult>();

            IList<SqlParameter> optionals = new List<SqlParameter>();
            string dateFilter = string.Empty;
            if (fromDate != default(DateTime))
            {
                dateFilter = " AND ATT.CREATION_DATE >= @FromDate";
                optionals.Add(new SqlParameter("@FromDate", SqlDbType.DateTime) { Value = fromDate });
            }

            if (toDate != default(DateTime))
            {
                dateFilter += " AND ATT.CREATION_DATE <= @ToDate";
                optionals.Add(new SqlParameter("@ToDate", SqlDbType.DateTime) { Value = toDate });
            }

            string getPicturesSqlCmd = ";WITH theQuery AS " +
                                        "(" + string.Format(this.baseQuery, this.mimeTypesFilter, dateFilter) + ") " +
                                        "SELECT * FROM theQuery WHERE ROW_NUM BETWEEN @Skip AND (@Skip + @Take)";

            this.SetupTempDirectory(this.tempPath);

            using (SqlConnection conn = new SqlConnection(this.connString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(getPicturesSqlCmd, conn))
                {
                    theCommand.CommandTimeout = 300;
                    theCommand.Parameters.Add("@Skip", SqlDbType.Int).Value = skip;
                    theCommand.Parameters.Add("@Take", SqlDbType.Int).Value = take;
                    theCommand.Parameters.AddRange(optionals.ToArray());
                    using (SqlDataReader reader = theCommand.ExecuteReader(CommandBehavior.SequentialAccess))
                    {
                        while (reader.Read())
                        {
                            try
                            {
                                FileResult result = this.SaveImageFromDataReader(this.tempPath, reader);
                                files.Add(result);
                            }
                            catch (Exception ex)
                            {
                                this.log.Warn("Exception happen when retrieving image from Eis.", ex);
                            }
                        }
                    }

                }
            }

            return files;
        }

        private void SetupTempDirectory(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            else
            {
                DirectoryInfo dInfo = new DirectoryInfo(path);

                foreach (FileInfo file in dInfo.GetFiles("*.*", SearchOption.AllDirectories)) file.Delete();
                foreach (DirectoryInfo subDir in dInfo.GetDirectories("*.*", SearchOption.AllDirectories)) subDir.Delete();
            }
        }

        private FileResult SaveImageFromDataReader(string path, SqlDataReader reader, int bufferSize = 100)
        {
            string uniqueIdRead = reader.GetInt32(0).ToString();

            this.log.DebugFormat("Extracting image from Eis attachment '{0}'...", uniqueIdRead);

            MemoryStream stream = new MemoryStream();
            BinaryWriter writer = new BinaryWriter(stream);

            byte[] outByte = new byte[bufferSize];

            long startIndex = 0;
            long retVal = reader.GetBytes(2, startIndex, outByte, 0, bufferSize);

            while (retVal == bufferSize)
            {
                writer.Write(outByte);
                writer.Flush();

                startIndex += bufferSize;
                retVal = reader.GetBytes(2, startIndex, outByte, 0, bufferSize);
            }

            int remaining = (int)retVal - 1;
            if (remaining >= 0)
            {
                writer.Write(outByte, 0, remaining);
            }

            writer.Flush();

            this.log.Debug("Done!");

            string fileName = reader.GetString(3);
            string fullFileName = Path.Combine(this.tempPath, fileName);

            this.log.DebugFormat("Saving image to {0}...", fullFileName);
            using (Image img = Image.FromStream(stream))
            {
                img.Save(fullFileName);
            }

            writer.Close();
            stream.Close();

            FileResult result = new FileResult(uniqueIdRead, fullFileName, this.imageMimeTypes.GetMimeTypeFromFileName(fullFileName));
            result.Metadata.Add("Source system", "EIS DB");
            result.Metadata.Add("EIS reference", System.Net.WebUtility.UrlEncode(string.Format(this.urlTemplate, this.eisServer, uniqueIdRead)));
            this.log.DebugFormat("Done!");

            return result;
        }


    }
}
