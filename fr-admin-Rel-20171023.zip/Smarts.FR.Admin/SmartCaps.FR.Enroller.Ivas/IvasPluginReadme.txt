﻿Typical call:

ep -pluginDll="SmartCaps.FR.Enroller.Ivas.dll" -parameters="Data Source=EU-DA-SRV627,17050;Initial Catalog=NetClean_CS;User=facerec;Pwd=ABCabc123.|" -skip=0 -take=10 -confirm -verbose