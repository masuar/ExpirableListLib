﻿using SmartCaps.FR.Admin.FileReader;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.ServiceModel;
using System.Configuration;
using System.IO;
using SmartCaps.FR.Common.MimeTypes;

namespace SmartCaps.FR.Enroller.CTW
{
    public class VideoReader : IFileReader
    {
        private VideoMimeTypes mimeTypesHelper = new VideoMimeTypes();

        public string PluginName
        {
            get
            {
                return "CTWEnroller";
            }
        }

        public string RefType
        {
            get
            {
                return "CTW";
            }
        }


        public string CTW_SERVER;
        private Dictionary<string, string> ListColumns;

        public VideoReader(string CTW_SERVER)
        {
            this.CTW_SERVER = CTW_SERVER;
        }


        public int Count(DateTime fromDate, DateTime toDate)
        {
            XmlNodeList videos = GetVideoNodes("Terrorist Audio and Video", fromDate, toDate);
            return videos.Count;
        }

        public IEnumerable<FileResult> GetFileNames(DateTime fromDate, DateTime toDate, int skip, int take)
        {
            IList<FileResult> data = new List<FileResult>();
            int skipcnt = 0;
            int takecnt = 0;
            string listID = GetListID("Terrorist Audio and Video");
            foreach (XmlElement v in GetVideoNodes("Terrorist Audio and Video", fromDate, toDate))
            {
                if (skipcnt < skip)
                {
                    skipcnt++;
                }
                else
                {
                    if (takecnt <= take || take < 0)
                    {

                        takecnt++;
                        string title = v.Attributes["ows_Title"].InnerText;
                        string[] IDz = v.Attributes["ows_UniqueId"].InnerText.Split(new string[] { ";#", "{", "}" }, StringSplitOptions.RemoveEmptyEntries);
                        string vidID = IDz[0];
                        string vidGID = IDz[1].ToLower().Replace("-", "");

                        string ext = GetMetaDataPart(listID, vidID, "Type");

                        string ctwFullFilePath = GetMetaDataPart(listID, vidID, "ctwFilePath");
                        ctwFullFilePath = ctwFullFilePath.Replace("\\in\\", "\\original\\"); // for partialy transferred
                        string ctwURL = CTW_SERVER + "/c/7/DispForm.aspx?ID=" + vidID;

                        string mimeType = this.mimeTypesHelper.GetMimeTypeFromExtension(ext);
                        FileResult f = new FileResult(vidGID, ctwFullFilePath, mimeType);
                        string ctwTitle = GetMetaDataPart(listID, vidID, "Title");
                        f.Metadata.Add("Source system", "Check the Web");
                        f.Metadata.Add("CTW Title", ctwTitle);
                        f.Metadata.Add("CTW Reference", "<a href=\"" + ctwURL + "\">" + GetMetaDataPart(listID, vidID, "ctwItemRef") + "</a>");

                        #region other fields (commented)
                        //f.Metadata.Add("CTW Original File", "<a href=\"" + ctwFullFilePath + "\">Original CTW file</a>");
                        //f.Metadata.Add("CTW 1st contributor", GetMetaDataPart(listID, vidID, "ctw1stcontributor"));
                        //f.Metadata.Add("CTW contribution date", GetMetaDataPart(listID, vidID, "ctwDateOfContribution"));
                        //f.Metadata.Add("CTW 1st SIENA/InfoEx", GetMetaDataPart(listID, vidID, "ctw1stInfoEx"));
                        //string desc = GetMetaDataPart(listID, vidID, "ctwAVDescription");
                        //if (desc != "") f.Metadata.Add("CTW Video Description", desc);
                        //string duration = GetMetaDataPart(listID, vidID, "ctwAVDuration");
                        //if (duration != "") f.Metadata.Add("CTW Video Duration", duration);

                        //foreach (KeyValuePair<string,string> col in this.ListColumns)
                        //{
                        //    string meta = GetMetaDataPart(listID, vidID, col.Key);
                        //    if (meta != "")
                        //    {
                        //        Console.WriteLine(col.Value + ":" + meta);
                        //        Console.WriteLine("[[[[" + col.Key + "]]]]");
                        //    }
                        //}
                        #endregion

                        data.Add(f);
                    }
                    else
                        break;
                }
            }
            return data;
        }

        private static XElement ToXElement(XmlNode source)
        {
            XElement hmm = XElement.Parse(source.OuterXml);
            return hmm;
        }

        private static XmlDocument ToXmlDocument(XElement xml)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(xml.CreateReader());
            return doc;
        }

        private string GetListID(string ListName)
        {
            var binding = new BasicHttpBinding();
            binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Ntlm;
            var endpoint = new EndpointAddress(CTW_SERVER + "/_vti_bin/Lists.asmx");
            var client = new ServiceReference1.ListsSoapClient(binding, endpoint);
            client.ClientCredentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;

            XElement rl = client.GetList(ListName);
            string listID = ToXmlDocument(rl).DocumentElement.Attributes["ID"].InnerText;

            ListColumns = new Dictionary<string, string>();
            foreach (XmlNode i in ToXmlDocument(rl).DocumentElement.GetElementsByTagName("Field"))
            {
                try
                {
                    ListColumns.Add(i.Attributes["Name"].InnerText, i.Attributes["DisplayName"].InnerText);
                }
                catch (Exception)
                {
                }

            }
            return listID;
        }

        private XmlNodeList GetVideoNodes(string ListName, DateTime fromDate, DateTime toDate)
        {
            var binding = new BasicHttpBinding();
            binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Ntlm;
            var endpoint = new EndpointAddress(CTW_SERVER + "/_vti_bin/Lists.asmx");
            var client = new ServiceReference1.ListsSoapClient(binding, endpoint);
            client.ClientCredentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;

            XmlDocument xmlDoc = new XmlDocument();
            XmlNode ndQuery = xmlDoc.CreateNode(XmlNodeType.Element, "Query", "");
            XmlNode ndViewFields = xmlDoc.CreateNode(XmlNodeType.Element, "ViewFields", "");
            XmlNode ndQueryOptions = xmlDoc.CreateNode(XmlNodeType.Element, "QueryOptions", "");

            ndQueryOptions.InnerXml = "<IncludeMandatoryColumns>TRUE</IncludeMandatoryColumns>";
            ndViewFields.InnerXml = "<FieldRef Name='ContentType' /><FieldRef Name='ctwDateOfContribution' />";
            //CAML query
            if (fromDate == toDate && fromDate == new DateTime(1, 1, 1))
                ndQuery.InnerXml = "<Where><Contains><FieldRef Name='ContentType' /> <Value Type='Choice'>Video</Value> </Contains></Where>";
            else
                ndQuery.InnerXml = @" < Where>
 <And>
 <Contains>
  <FieldRef Name='ContentType' />
  <Value Type='Choice'>Video</Value>
 </Contains>
 <And>
   <Gt>
    <FieldRef Name='ctwDateOfContribution' />
    <Value IncludeTimeValue='False' Type='DateTime'>" + fromDate.ToString("yyyy-MM-dd") + @"</Value>
   </Gt>
   <Leq>
    <FieldRef Name='ctwDateOfContribution' />
    <Value IncludeTimeValue='False' Type='DateTime'>" + toDate.ToString("yyyy-MM-dd") + @"</Value>
   </Leq>
  </And>
 </And>
</Where>";

            XElement r = client.GetListItems(ListName, null, ToXElement(ndQuery), ToXElement(ndViewFields), null, ToXElement(ndQueryOptions), null);
            String aaaa = r.ToString();
            XmlDocument doc = new XmlDocument();
            doc.Load(r.CreateReader());
            var nsmgr = new XmlNamespaceManager(doc.NameTable);
            nsmgr.AddNamespace("rs", "urn:schemas-microsoft-com:rowset");
            nsmgr.AddNamespace("z", "#RowsetSchema");
            XmlNodeList vidiozzz = doc.FirstChild.SelectNodes("rs:data/*", nsmgr);
            return vidiozzz;
        }



        private string GetMetaDataPart(string listID, string videoID, string fieldname)
        {
            var binding = new BasicHttpBinding();
            binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Ntlm;
            var endpoint = new EndpointAddress(CTW_SERVER + "/_vti_bin/Lists.asmx");
            var client = new ServiceReference1.ListsSoapClient(binding, endpoint);
            client.ClientCredentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;


            string result = "";
            try
            {
                XElement vers = client.GetVersionCollection(listID, videoID, fieldname);
                result = ToXmlDocument(vers).FirstChild.FirstChild.Attributes[fieldname].InnerText;
            }
            catch (Exception)
            {

            }

            return result;
        }

    }
}
