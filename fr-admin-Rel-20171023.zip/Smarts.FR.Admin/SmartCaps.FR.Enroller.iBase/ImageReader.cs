﻿using log4net;
using SmartCaps.FR.Admin.FileReader;
using SmartCaps.FR.Common.MimeTypes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;

namespace SmartCaps.FR.Updater.iBase
{
    public class ImageReader : IFileReader
    {
        private string connString;
        private string tempPath;
        private string focalPoint;
        private string extensionsFilter;
        private IMimeTypesCollection imageMimeTypes = new ImageMimeTypes();
        private ILog log;

        private readonly string baseQuery = "SELECT Partial.Unique_ID, Partial.Picture__Binding, Partial.Picture_, Partial.Create_Date, Partial.Siena_Nums, Partial.Focal_Points, ROW_NUMBER() OVER(ORDER BY Create_Date) ROW_NUM FROM " +
                                    "(SELECT [Source].Unique_ID, [Source].Create_Date, [Source].Picture__Binding, [Source].Picture_, " +
                                        "STUFF((SELECT distinct(',' + [Doc].SIENA_Number) FROM [AWF_SOC].[dbo].[_LinkEnd] [Link] LEFT JOIN [AWF_SOC].[dbo].Admin_Document [Doc] ON [Link].Entity_ID2 = [Doc].Unique_ID WHERE [Link].Entity_ID1 = [Source].Unique_ID FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,' ') Siena_Nums, " +
                                        "STUFF((SELECT distinct(',' + [Doc].Focal_Point)  FROM [AWF_SOC].[dbo].[_LinkEnd] [Link] LEFT JOIN [AWF_SOC].[dbo].Admin_Document [Doc] ON [Link].Entity_ID2 = [Doc].Unique_ID WHERE [Link].Entity_ID1 = [Source].Unique_ID FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,' ') Focal_Points " +
                                      "FROM " +
                                        "(SELECT Unique_ID, Create_Date, Picture__Binding, Picture_ FROM [dbo].[Person_] WHERE Picture__Binding is not null " + 
                                            "UNION " +
                                         "SELECT Unique_ID, Create_Date, Picture__Binding, Picture_ FROM [dbo].[PDE_Person_Description] WHERE Picture__Binding is not null) AS [Source]) " +
                                    "AS [Partial] " +
                                    "WHERE LOWER([Partial].Picture__Binding) IN ({0}){1}{2}";


        public ImageReader(string connString, string tempPath, string focalPoint)
        {
            this.log = log4net.LogManager.GetLogger("SmartCaps.FR.Enroller");
            log4net.Config.XmlConfigurator.Configure();

            this.connString = connString;
            this.tempPath = tempPath;
            this.focalPoint = focalPoint;
            var extensions = this.imageMimeTypes.GetExtensions(null);
            this.extensionsFilter = string.Join(",", extensions.Select(e => "'" + e.ToLower().Replace(".", string.Empty) + "'"));
        }


        public string PluginName
        {
            get
            {
                return "iBaseEnroller";
            }
        }

        public string RefType
        {
            get
            {
                return "FILESYS";
            }
        }

        public static string Help = "Provide the following parameters for the constructor: string connString, string tempPath";

        public IEnumerable<FileResult> GetFileNames(DateTime fromDate, DateTime toDate, int skip, int take)
        {
            IList<FileResult> files = new List<FileResult>();

            IList<SqlParameter> optionals = new List<SqlParameter>();
            string dateFilter = string.Empty;
            if (fromDate != default(DateTime))
            {
                dateFilter = " AND Create_Date >= @FromDate";
                optionals.Add(new SqlParameter("@FromDate", SqlDbType.DateTime) { Value = fromDate });
            }

            if (toDate != default(DateTime))
            {
                dateFilter += " AND Create_Date <= @ToDate";
                optionals.Add(new SqlParameter("@ToDate", SqlDbType.DateTime) { Value = toDate } );
            }

            string focalPointFilter = string.Empty;
            if (!string.IsNullOrEmpty(this.focalPoint))
            {
                focalPointFilter = " AND Focal_Points LIKE @FocalPoint";
                optionals.Add(new SqlParameter("@FocalPoint", SqlDbType.NVarChar) { Value = string.Format("%{0}%", this.focalPoint) });
            }

            string getPicturesSqlCmd = ";WITH theQuery AS " + 
                                        "(" + string.Format(this.baseQuery, this.extensionsFilter, dateFilter, focalPointFilter) + ") " +
                                        "SELECT * FROM theQuery WHERE ROW_NUM BETWEEN @Skip AND (@Skip + @Take)";

            this.SetupTempDirectory(this.tempPath);

            using (SqlConnection conn = new SqlConnection(this.connString))
            {
                conn.Open();
                using (SqlCommand theCommand = new SqlCommand(getPicturesSqlCmd, conn))
                {
                    theCommand.CommandTimeout = 300;
                    theCommand.Parameters.Add("@Skip", SqlDbType.Int).Value = skip;
                    theCommand.Parameters.Add("@Take", SqlDbType.Int).Value = take;
                    theCommand.Parameters.AddRange(optionals.ToArray());
                    using (SqlDataReader reader = theCommand.ExecuteReader(CommandBehavior.SequentialAccess))
                    {
                        while (reader.Read())
                        {
                            try
                            {
                                FileResult result = this.SaveImageFromDataReader(this.tempPath, reader);
                                files.Add(result);
                            }
                            catch (Exception ex)
                            {
                                this.log.Warn("Exception happen when retrieving image from iBase.", ex);
                            }
                        }
                    }

                }
            }

            return files;
        }

        public int Count(DateTime fromDate, DateTime toDate)
        {
            int howMany = 0;
            string getPicturesCountSqlCmd = string.Empty;
            try
            {
                IList<SqlParameter> optionals = new List<SqlParameter>();
                string dateFilter = string.Empty;
                if (fromDate != default(DateTime))
                {
                    dateFilter = " AND Create_Date >= @FromDate";
                    optionals.Add(new SqlParameter("@FromDate", SqlDbType.DateTime) { Value = fromDate });
                }

                if (toDate != default(DateTime))
                {
                    dateFilter += " AND Create_Date <= @ToDate";
                    optionals.Add(new SqlParameter("@ToDate", SqlDbType.DateTime) { Value = toDate });
                }

                string focalPointFilter = string.Empty;
                if (!string.IsNullOrEmpty(this.focalPoint))
                {
                    focalPointFilter = " AND Focal_Points LIKE @FocalPoint";
                    optionals.Add(new SqlParameter("@FocalPoint", SqlDbType.NVarChar) { Value = string.Format("%{0}%", this.focalPoint) });
                }

                getPicturesCountSqlCmd = ";WITH theQuery AS " +
                                            "(" + string.Format(this.baseQuery, this.extensionsFilter, dateFilter, focalPointFilter) + ") " +
                                            "SELECT count(*) FROM theQuery";

                this.SetupTempDirectory(this.tempPath);

                using (SqlConnection conn = new SqlConnection(this.connString))
                {
                    conn.Open();
                    using (SqlCommand theCommand = new SqlCommand(getPicturesCountSqlCmd, conn))
                    {
                        theCommand.CommandTimeout = 300;
                        theCommand.Parameters.AddRange(optionals.ToArray());
                        howMany = (int)theCommand.ExecuteScalar();
                    }
                }

                return howMany;
            }
            catch(Exception)
            {
                this.log.ErrorFormat("Error! {0}", getPicturesCountSqlCmd);
                throw;
            }
        }

        private FileResult SaveImageFromDataReader(string path, SqlDataReader reader, int bufferSize = 100)
        {
            string uniqueIdRead = reader.GetString(0);
            string extRead = reader.GetString(1);

            string fileName = uniqueIdRead.Replace(@"\", "_");
            string extension = "." + extRead.ToLower();
            string fullFileName = Path.Combine(this.tempPath, fileName + extension);
            this.log.DebugFormat("Extracting image from {0}...", uniqueIdRead);

            MemoryStream stream = new MemoryStream();
            BinaryWriter writer = new BinaryWriter(stream);

            byte[] outByte = new byte[bufferSize];

            long startIndex = 0;
            long retVal = reader.GetBytes(2, startIndex, outByte, 0, bufferSize);

            while (retVal == bufferSize)
            {
                writer.Write(outByte);
                writer.Flush();

                startIndex += bufferSize;
                retVal = reader.GetBytes(2, startIndex, outByte, 0, bufferSize);
            }

            int remaining = (int)retVal - 1;
            if (remaining >= 0)
            {
                writer.Write(outByte, 0, remaining);
            }

            writer.Flush();

            this.log.Debug("Done!");
            this.log.DebugFormat("Saving image to {0}...", fullFileName);
            using (Image img = Image.FromStream(stream))
            {
                img.Save(fullFileName);
            }

            writer.Close();
            stream.Close();

            FileResult result = new FileResult(uniqueIdRead, fullFileName, this.imageMimeTypes.GetMimeTypeFromFileName(fullFileName));

            string sienaNumsString = this.GetNullableString(reader,4);
            result.SienaNums.AddRange(this.GetSienaNumsFromString(sienaNumsString));

            string focalPointsString = this.GetNullableString(reader, 5);
            result.FocalPoints.AddRange(this.GetFocalPointsFromString(focalPointsString));

            result.Metadata.Add("Source system", "iBase DB");


            this.log.DebugFormat("Done! (Siena nums: {0} Focal points: {1})", sienaNumsString, focalPointsString);

            return result;
        }

        private IEnumerable<string> GetFocalPointsFromString(string focalPointsString)
        {
            IEnumerable<string> fps = new List<string>();

            if (!string.IsNullOrEmpty(focalPointsString))
            {
                fps = focalPointsString.Split(',').Select(fp => fp.Replace('.', '-').Replace('_', '-'));
            }

            return fps;
        }

        private IEnumerable<string> GetSienaNumsFromString(string sienaNumsString)
        {
            IEnumerable<string> sienas = new List<string>();

            if (!string.IsNullOrEmpty(sienaNumsString))
            {
                sienas = sienaNumsString.Split(',').Select(s => this.FormatSienaNum(s));
            }

            this.log.DebugFormat("XXX: {0}", string.Join("|",sienas));
            return sienas;
        }

        private string FormatSienaNum(string sienaNumString)
        {
            string result = "unknown";

            if (!string.IsNullOrEmpty(sienaNumString))
            {
                try
                {
                    string theFormattedString = sienaNumString.Trim().ToUpper();
                    if (theFormattedString.StartsWith("SIENA"))
                    {
                        string firstPart = theFormattedString.Substring(6, 7);

                        string secondPart = theFormattedString.Substring(14, 4);
                        int secondPartInt = 0;
                        if (int.TryParse(secondPart, out secondPartInt))
                        {
                            secondPart = secondPartInt.ToString();
                        }

                        string thirdPart = theFormattedString.Substring(19, 4);
                        int thirdPartInt = 0;
                        if (int.TryParse(thirdPart, out thirdPartInt))
                        {
                            thirdPart = thirdPartInt.ToString();
                        }

                        result = string.Format("{0}-{1}-{2}", firstPart, secondPart, thirdPart);
                    }
                    else
                    {
                        result = sienaNumString.Replace('.', '-').Replace('_', '-');
                    }
                }
                catch(Exception)
                {
                    result = "invalid";
                }
            }

            return result;
        }

        private void SetupTempDirectory(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            else
            {
                DirectoryInfo dInfo = new DirectoryInfo(path);

                foreach (FileInfo file in dInfo.GetFiles("*.*", SearchOption.AllDirectories)) file.Delete();
                foreach (DirectoryInfo subDir in dInfo.GetDirectories("*.*", SearchOption.AllDirectories)) subDir.Delete();
            }
        }

        private string GetNullableString(SqlDataReader reader, int index)
        {
            string result = string.Empty;

            try
            {
                result = reader.GetString(index);
            }
            catch(System.Data.SqlTypes.SqlNullValueException)
            {
                // Null value!
            }

            return result;
        }
    }
}
