﻿Typical call:

ep -pluginDll="SmartCaps.FR.Updater.iBase.dll" -parameters="Data Source=EU-DA-SRV258,17050;Initial Catalog=AWF_SOC;Integrated Security=True|c:/temp/tempImages" -skip=0 -take=10 -confirm -verbose