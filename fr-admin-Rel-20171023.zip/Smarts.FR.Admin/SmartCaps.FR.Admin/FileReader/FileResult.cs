﻿using System.Collections.Generic;

namespace SmartCaps.FR.Admin.FileReader
{ 
    public class FileResult
    {
        public FileResult(string id, string filePath, string mimeType)
        {
            this.Id = id;
            this.Path = filePath;
            this.SienaNums = new List<string>();
            this.FocalPoints = new List<string>();
            this.Metadata = new Dictionary<string, string>();
            this.MimeType = mimeType;
        }

        public string Id { get; private set; }

        public string Path { get; private set; }

        public string MimeType { get; private set; }

        public List<string> SienaNums { get; private set; }

        public List<string> FocalPoints { get; private set; }

        public IDictionary<string, string> Metadata { get; private set; }
    }
}
