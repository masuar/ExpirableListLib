﻿using System;
using System.Collections.Generic;

namespace SmartCaps.FR.Admin.FileReader
{
    public interface IFileReader
    {
        string PluginName { get; }

        string RefType { get; }

        int Count(DateTime fromDate, DateTime toDate);

        IEnumerable<FileResult> GetFileNames(DateTime fromDate, DateTime toDate, int skip, int take);
    }
}
