﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Admin.Model
{
    public class FaceLinks
    {
        [JsonProperty(PropertyName = "face")]
        public Link Face { get; set; }

        [JsonProperty(PropertyName = "image")]
        public Link Image { get; set; }

        [JsonProperty(PropertyName = "fullImage")]
        public Link FullImage { get; set; }

        [JsonProperty(PropertyName = "recognizeFace")]
        public Link RecognizeFace { get; set; }

        [JsonProperty(PropertyName = "features")]
        public Link Features { get; set; }

    }
}
