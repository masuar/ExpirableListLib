﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Admin.Model
{
    public class EnrollmentCommand
    {
        [JsonProperty(PropertyName = "command")]
        public Link CommandLink { get; protected set; }

        [JsonProperty(PropertyName = "token")]
        public string Token { get; protected set; }

        [JsonProperty(PropertyName = "errorMessage")]
        public string ErrorMessage { get; protected set; }

        [JsonProperty(PropertyName = "commandStatus")]
        public string CommandStatus { get; private set; }

        [JsonProperty(PropertyName = "enrolledFaces")]
        public IEnumerable<FaceLinks> EnrolledFaces { get; private set; }

        [JsonProperty(PropertyName = "alreadyExitingFaces")]
        public IEnumerable<FaceLinks> AlreadyExistingFaces { get; private set; }

        [JsonProperty(PropertyName = "faceQualityScoreThreshold")]
        public double FaceQualityScoreThreshold { get; set; }
    }
}
