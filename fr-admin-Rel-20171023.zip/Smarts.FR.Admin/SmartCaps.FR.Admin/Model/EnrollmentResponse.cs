﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Admin.Model
{
    public class EnrollmentResponse
    {
        [JsonProperty(PropertyName = "success")]
        public IEnumerable<EnrollmentCommand> Success { get; set; }

        [JsonProperty(PropertyName = "failed")]
        public IEnumerable<EnrollmentCommand> Failed { get; set; }

        [JsonProperty(PropertyName = "notFinished")]
        public List<EnrollmentCommand> NotFinished { get; set; }

        [JsonProperty(PropertyName = "message")]
        public virtual string Message { get; set; }

        public int EnrolledFaces
        {
            get
            {
                int count = 0;
                foreach (var item in this.Success)
                {
                    if (item.EnrolledFaces != null)
                    {
                        count += item.EnrolledFaces.Count();
                    }
                }
                return count;
            }
        }

        public int AlreadyExistingFaces
        {
            get
            {
                int count = 0;
                foreach (var item in this.Success)
                {
                    if (item.AlreadyExistingFaces != null)
                    {
                        count += item.AlreadyExistingFaces.Count();
                    }
                }
                return count;
            }
        }
    }
}