﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Admin.Model
{
    public class Link
    {
        [JsonProperty(PropertyName = "href")]
        public Uri Href { get; set; }

    }
}
