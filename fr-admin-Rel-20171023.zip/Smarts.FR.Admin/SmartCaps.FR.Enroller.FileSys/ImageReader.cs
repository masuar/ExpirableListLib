﻿using log4net;
using SmartCaps.FR.Admin.FileReader;
using SmartCaps.FR.Common.MimeTypes;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCaps.FR.Enroller.FileSys
{
    public class ImageReader : IFileReader
    {
        private string folder;
        private IEnumerable<string> extensions;
        private ILog log;
        private MimeTypesHelper mimeTypesHelper = new MimeTypesHelper();

        public ImageReader(string folder)
        {

            this.log = log4net.LogManager.GetLogger("SmartCaps.FR.Enroller");
            log4net.Config.XmlConfigurator.Configure();
            this.folder = folder;
            
            this.extensions = this.mimeTypesHelper.GetExtensions(null); // Get all image and video extensions
            this.log.DebugFormat("Supported extensions: {0}", string.Join(",", this.extensions));
        }

        public static string Help = "Provide the following parameters for the constructor: string folder, params string[] mimeTypes";

        public string PluginName
        {
            get
            {
                return "FileSysEnroller";
            }
        }

        public string RefType
        {
            get
            {
                return "FILESYS";
            }
        }

        public IEnumerable<FileResult> GetFileNames(DateTime fromDate, DateTime toDate, int skip, int take)
        {
            IList<FileResult> data = new List<FileResult>();
            IEnumerable<FileInfo> files = new DirectoryInfo(folder).GetFiles("*.*", SearchOption.AllDirectories);
            files = files.Where(f => this.extensions.Contains(f.Extension.ToLower()));
            if (fromDate != default(DateTime))
            {
                files = files.Where(f => f.CreationTime >= fromDate);
            }

            if (toDate != default(DateTime))
            {
                files = files.Where(f => f.CreationTime <= toDate);
            }

            files = files.OrderBy(f => f.CreationTime).Skip(skip).Take(take);

            int i = 0;
            foreach (var f in files)
            {
                var result = new FileResult(i++.ToString(), f.FullName, this.mimeTypesHelper.GetMimeTypeFromFileName(f.Name));
                result.Metadata.Add("Source system", "File system (FACE admin tool)");
                // FOR TESTING ONLY
                // result.Metadata.Add(string.Format("TESTING {0}",Guid.NewGuid().ToString().Substring(0,5)), "TEST VALUE");
                // result.Metadata.Add("Test field", DateTime.UtcNow.ToString());
                data.Add(result);
            }

            return data;
        }

        public int Count(DateTime fromDate, DateTime toDate)
        {
            IEnumerable<FileInfo> files = new DirectoryInfo(folder).GetFiles("*.*", SearchOption.AllDirectories);
            files = files.Where(f => this.extensions.Contains(f.Extension.ToLower()));
            if (fromDate != default(DateTime))
            {
                files = files.Where(f => f.CreationTime >= fromDate);
            }

            if (toDate != default(DateTime))
            {
                files = files.Where(f => f.CreationTime <= toDate);
            }

            return files.Count();
        }

    }
}
