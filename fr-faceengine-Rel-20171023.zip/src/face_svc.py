import os
import json
import logging.config
import traceback
import sys

import win32service, winerror
import win32serviceutil
import win32event

import servicemanager

import util
import scpyfr.services as fr_services
import scpyfr.processors as fr_processors

class FaceWinSvc(win32serviceutil.ServiceFramework):
    
    thefolder = os.path.dirname(os.path.realpath(__file__))
    os.chdir(thefolder)
    _config = util.readFaceConf("face_svc.ini")
    _log = util.setupLogging(logger_name = 'FACE', inst_name = _config.name, verbose = _config.verbose, default_path = 'face_log_config.json')
    _svc_name_ = _config.name
    _svc_display_name_ = "SmartCaps FR FaceEngine ({})".format(_svc_name_)
    _svc_description_ = "This service handles the identification of faces and signature calculation for FACE."

    def __init__(self,args):
        win32serviceutil.ServiceFramework.__init__(self,args)
        self._faceEngine = None
        self.hWaitStop = win32event.CreateEvent(None, 0, 0, None)

    def SvcDoRun(self):
        servicemanager.LogMsg(servicemanager.EVENTLOG_INFORMATION_TYPE, servicemanager.PYS_SERVICE_STARTED, (self._svc_name_, ''))
        
        try:
            self._log.info("Loading...")
            msg = "Configuration read: "
            msg += 'instance name = {}; '.format(self._config.name)
            msg += 'models location = {}; '.format(self._config.models)
            msg += 'instance verbosity = {}; '.format(self._config.verbose)
            msg += 'activemq server = {}; '.format(self._config.server)
            msg += 'activemq user = {}; '.format(self._config.user)
            msg += 'activemq listento = {}; '.format(self._config.listento)
            msg += 'activemq pubto = {}; '.format(self._config.pubto)
            msg += 'face min size = {}; '.format(self._config.faceMinSize)
            self._log.debug(msg)
            self.printEventLogMsg(msg)

            #faceMinSize = 40
            faceFinalSize = 160

            featMetaFile = 'model-20170306-150500.meta'
            featCkptFile = 'model-20170306-150500.ckpt-250000'

            faceExtractor = fr_services.FacenetFaceExtractor(self._config.models, self._config.faceMinSize, faceFinalSize, self._log)
            featCalculator = fr_services.FacenetFeatCalculator(faceExtractor, self._config.models, featMetaFile, featCkptFile, self._log)

            self._faceEngine = fr_processors.FaceEngineCommandProcessor(faceExtractor, featCalculator, self._config, self._log)
            self._faceEngine.onStop = lambda _: win32event.SetEvent(self.hWaitStop)

            self._log.info('Loaded!')
            self._faceEngine.start()

        except Exception as ex:
            if hasattr(ex, 'message'):
                msg = ex.message
            else:
                msg = str(ex)
            
            self.printEventLogMsg('Error! ' + msg)
            win32event.SetEvent(self.hWaitStop)
            pass

        rc = None
        while rc != win32event.WAIT_OBJECT_0:
            rc = win32event.WaitForSingleObject(self.hWaitStop, 5000)
        
        servicemanager.LogMsg(servicemanager.EVENTLOG_INFORMATION_TYPE, servicemanager.PYS_SERVICE_STOPPED, (self._svc_name_,''))

    def SvcStop(self):
        self._faceEngine.stop()

    def printEventLogMsg(self, msg):
        servicemanager.LogMsg(servicemanager.EVENTLOG_INFORMATION_TYPE, 0xF000, (msg ,''))


if __name__ == '__main__':
    win32serviceutil.HandleCommandLine(FaceWinSvc)
