
from abc import ABCMeta, abstractmethod

import scpymsg.entities as entities
import logging
import uuid

import stomp 
import time
import sys

class StompMessageProcessor(entities.MessageProcessor):
    class Listener(stomp.ConnectionListener):
        def __init__(self, connInfo, on_recovered, process, stop, log = None):
            self._connInfo = connInfo
            self._log = log or logging.getLogger("{} ({})".format(__name__, self._connInfo.name))
            self._on_recovered = on_recovered
            self._process = process
            self._stop = stop

        def on_connected(self, headers, body):
            self._log.info("Started!")
            # self._start()

        def on_message(self, headers, message):
            rk = 'no-routing-key'
            if 'type' in headers:
                rk = headers['type']
            msgid = headers['message-id']
            self._log.info("Message '{}' of type '{}' received.".format(msgid, rk))
            self._log.debug("Message content: {}".format(message))
            try:
                self._process(rk, message)
                self._log.info("Message '{}' processed.".format(msgid))
                # self._conn.ack(msgid, self._connInfo.name)
                # self._log.debug("Message '{}' acknowledged.".format(msgid))
                # self._log.info("Message '{}' processed and accepted.".format(msgid))
            except Exception as ex:
                self._log.error("Error while processing message '{}': {}.".format(msgid, ex))
                # self._conn.nack(msgid, self._connInfo.name)
                #self._log.debug("Message '{}' nacked.".format(msgid))

            return

        def connect(self):
            self._log.debug("Attempting to connect")
            for n in range(1, 31):
                try:
                    self._log.debug("Connecting: Attempt %d" % n)
                    # self._conn = stomp.Connection([(self._connInfo.server, self._connInfo.port)], heartbeats=(0, 0))
                    self._conn = stomp.Connection([(self._connInfo.server, self._connInfo.port)], heartbeats=(30000, 30000))
                    self._conn.set_listener(self._connInfo.name, self)
                    self._conn.start()
                    self._conn.connect(self._connInfo.user, self._connInfo.pwd, wait=True)
                    self._conn.subscribe(self._connInfo.listento, id=self._connInfo.name, ack='auto')
                    # self._conn.subscribe(self._connInfo.listento, id=self._connInfo.name, ack='client-individual')
                    self._on_recovered()
                    break
                except stomp.exception.ConnectFailedException:
                    _, e, _ = sys.exc_info()
                    # Oh, still can't reconnect
                    self._log.error("Reconnect attempt failed: %s" % e)
                    time.sleep(2)      
            
            if self._conn.is_connected() == False:
                self._stop()

        def on_disconnected(self):
            self._log.info('Disconnected!')
            self.connect()
            #self.on_heartbeat_timeout()

    def __init__(self, connInfo, log = None):
        if connInfo.name == None:
            connInfo.name = "fr"
        super(StompMessageProcessor, self).__init__(connInfo.name)
        self._log = log or logging.getLogger(__name__)
        self._connInfo = connInfo
        self._listener = StompMessageProcessor.Listener(self._connInfo, self.on_recovered, self.onReceived, self.stop, log)
        self._stopRequested = False

    def start(self):
        self._listener.connect()
        self.onStart()        
        self._log.info("Listening on '{}' ({})...".format(self._connInfo.server, self._connInfo.listento))
        while self._stopRequested == False:
            time.sleep(1)

    def stop(self):
        self._log.info('Stop requested.')
        self._stopRequested = True

    def send(self, routingKey, body):
        self._listener._conn.send(self._connInfo.pubto, body, 'application/json', { "JMSType" : routingKey, "persistent" : True })
        self._log.debug("Message of type '{}' sent to '{}'.".format(routingKey, self._connInfo.pubto))

    @abstractmethod
    def onReceived(self, routingKey, body):
        raise NotImplementedError()
       
    def onStart(self):
        pass

    def on_recovered(self):
        pass
