import uuid
from abc import ABCMeta, abstractmethod

class MessageProcessor:    
    __metaclass__ = ABCMeta
    def __init__(self, name):
        if name == None:
            self._name = str(uuid.uuid1())
        else:
            self._name = name

    @property
    def name(self):
        return self._name

    @abstractmethod
    def start(self):
        raise NotImplementedError()

    @abstractmethod
    def stop(self):
        raise NotImplementedError()

    @abstractmethod
    def send(self, routingKey, body, on_status):
        raise NotImplementedError()

    @abstractmethod
    def onReceived(self, message):
        raise NotImplementedError()

