
from abc import ABCMeta, abstractmethod

import entities
import logging
import uuid

from proton import *
from proton.handlers import MessagingHandler
from proton.reactor import Container

class AmqMessageProcessor(entities.MessageProcessor):
    class Server(MessagingHandler):
        def __init__(self, name, url, queueToListen, process, start, topicToPublish, log = None):
            super(AmqMessageProcessor.Server, self).__init__(auto_accept = False, prefetch = 2)
            self._name = name
            self._log = log or logging.getLogger("{} ({})".format(__name__, self._name))
            self._url = url
            self._queueToListen = queueToListen
            self._process = process
            self._start = start
            self._topicToPublish = topicToPublish

        def onStart(self, event):
            self._conn = event.container.connect(self._url)
            self._receiver = event.container.create_receiver(self._conn, self._queueToListen)
            self._sender = event.container.create_sender(self._conn, self._topicToPublish)
            self._dlq_sender = event.container.create_sender(self._conn, 'queue://ActiveMQ.DLQ')
            self._start()
            self._log.info("Listening on '{}' ({})...".format(self._url, self._queueToListen))

        def on_message(self, event):
            self._log.info("Message '{}' of type '{}' received.".format(event.message.id, event.message.content_type))
            self._log.debug("Message content: {}".format(event.message))
            if event.message.body == "stop {}".format(self._name):
                self.accept(event.delivery)
                self.stop()
            else:
                try:
                    self._process(event.message)
                    self.accept(event.delivery)
                    self._log.info("Message '{}' processed and accepted.".format(event.message.id))
                except Exception as ex:
                    self._log.error("Error while processing message '{}': {}.".format(event.message.id, ex))
                    if event.message.delivery_count < 10:
                        self.reject(event.delivery)
                        self._log.warning("Message rejected (Delivery count: {0}).".format(event.message.delivery_count))
                    else:
                        self.accept(event.delivery)
                        self._dlq_sender.send(event.message)
                        self._log.warning("Message redirected to DLQ.")
            
        def stop(self):
            self._conn.close()
            self._log.info("Message processor stopped.")

        def send(self, routingKey, body):
            responseMessage = Message(id = uuid.uuid1(), body = body, content_type = routingKey, durable = True)
            self._sender.send(responseMessage)
            self._log.debug("Message of type '{}' sent to '{}'.".format(routingKey, self._topicToPublish))

    def __init__(self, name, url, queueToListen, topicToPublish, log = None):
        super(AmqMessageProcessor, self).__init__(name)
        self._log = log or logging.getLogger(__name__)
        self._server = AmqMessageProcessor.Server(self.name, url, queueToListen, self.onReceived, self.onStart, topicToPublish, log)
        self._container = Container(self._server)

    def start(self):
        self._container.run()

    def stop(self):
        self._container.stop()

    def send(self, routingKey, body, on_status = None):
        self._server.send(routingKey, body)

    @abstractmethod
    def onReceived(self, message):
        raise NotImplementedError()
       
    def onStart(self):
        pass
