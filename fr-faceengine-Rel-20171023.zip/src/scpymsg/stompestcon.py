from abc import ABCMeta, abstractmethod
import logging

from twisted.internet import reactor, defer

from stompest.config import StompConfig
from stompest.protocol import StompSpec

from stompest.async import Stomp
from stompest.async.listener import SubscriptionListener
from stompest.async.listener import ConnectListener
from stompest.error import StompConnectionError

import scpymsg.entities as entities

class StompestMessageProcessor(entities.MessageProcessor):
    def __init__(self, connInfo, log = None):
        if connInfo.name == None:
            connInfo.name = "fr"
        super(StompestMessageProcessor, self).__init__(connInfo.name)
        self._stopRequested = False
        self._connInfo = connInfo
        self._log = log or logging.getLogger("{} ({})".format(__name__, self._connInfo.name))
        constr = 'failover:(tcp://{}:{})?startupMaxReconnectAttempts=3,initialReconnectDelay=20,maxReconnectAttempts=10'.format(self._connInfo.server, self._connInfo.port)
        self.config = StompConfig(constr, login = connInfo.user, passcode = connInfo.pwd)

    def start(self):
        self._run()
        reactor.run()
        self._log.info('Process finished.')
        self.onStop()

    def stop(self):
        self._log.info('Stop requested.')
        if hasattr(self._client, 'disconnect'):
            self._client.disconnect()
        reactor.stop()

    def send(self, routingKey, body):
        try:
            self._client.send(self._connInfo.pubto, body.encode(), headers = { "JMSType" : routingKey, "persistent" : True })
            self._log.debug("Message of type '{}' sent to '{}'.".format(routingKey, self._connInfo.pubto))

        except Exception as ex:
            self._log.error(str(ex))

    def onStart(self):
        pass

    def onRecovered(self):
        pass

    def onStop(self):
        pass

    @abstractmethod
    def onReceived(self, routingKey, body):
        raise NotImplementedError()

    @defer.inlineCallbacks
    def _run(self):
        try:
            self._client = Stomp(self.config)
            
            try:
                yield self._client.connect()
            except:
                self._log.info("Unable to connect.")
                reactor.stop()
                return

            self.onStart()

            headers = { StompSpec.ACK_HEADER: StompSpec.ACK_CLIENT_INDIVIDUAL, 'activemq.prefetchSize':'10' }
            self._client.subscribe(self._connInfo.listento, headers, listener = SubscriptionListener(self.process, errorDestination = '/queue/SmartCaps.FR.Error'))

            while self._stopRequested == False and hasattr(self._client, 'disconnected'):
                try:
                    self._client = yield self._client.disconnected
                except StompConnectionError:
                    self._log.error("Connection error! Trying to reconnect...")
                    try:
                        yield self._client.connect()
                        self.onRecovered()
                        self._log.info("Listening on '{}' ({})...".format(self._connInfo.server, self._connInfo.listento))
                    except:
                        self._log.info("Unable to reconnect.")
                        reactor.stop()

            
        except Exception as ex:
            self._log.error(str(ex))

    def process(self, client, frame):
        try:
            for key, value in frame.headers.items():
                self._log.debug("Header: {} = {}".format(key, value))

            routingKey = frame.headers['type']
            body = frame.body.decode()
            self._log.debug("Message with Routing Key '{}' and content '{}' received!".format(routingKey, body))
            self.onReceived(routingKey, body)
        except Exception as ex:
            self._log.error("Error processing message '{}'".format(str(ex)))





