import inspect
import json
import entities

class BaseCommand(object):
    def __init__(self, token):
        self._token = token
        self._createdBy = None
        self._createdOn = None
        self._lastUpdatedBy = None
        self._lastUpdatedOn = None
        self._totalSteps = 0
        self._lastStepCompleted = 0
        self._stepsCompleted = 0

    @property
    def cmdType(self):
        return self.__class__.__name__

    @property
    def token(self):
        return self._token

    @token.setter
    def token(self, value):
        self._token = value

    @property
    def createdBy(self):
        return self._createdBy

    @createdBy.setter
    def createdBy(self, value):
        self._createdBy = value
        self._lastUpdatedBy = value

    @property
    def createdOn(self):
        return self._createdOn

    @createdOn.setter
    def createdOn(self, value):
        self._createdOn = value
        self._lastUpdatedOn = value

    @property
    def lastUpdatedBy(self):
        return self._lastUpdatedBy

    @lastUpdatedBy.setter
    def lastUpdatedBy(self, value):
        self._lastUpdatedBy = value

    @property
    def lastUpdatedOn(self):
        return self._lastUpdatedOn

    @lastUpdatedOn.setter
    def lastUpdatedOn(self, value):
        self._lastUpdatedOn = value

    @property
    def totalSteps(self):
        return self._totalSteps

    @totalSteps.setter
    def totalSteps(self, value):
        self._totalSteps = value

    @property
    def lastStepCompleted(self):
        return self._lastStepCompleted

    @lastStepCompleted.setter
    def lastStepCompleted(self, value):
        self._lastStepCompleted = value
        
    @property
    def stepsCompleted(self):
        return self._stepsCompleted
    
    @stepsCompleted.setter
    def stepsCompleted(self, value):
        self._stepsCompleted = value

class EvalFaceCommand(BaseCommand):
    @property
    def sourceFaceId(self):
        return self._sourceFaceId

    @sourceFaceId.setter
    def sourceFaceId(self, value):
        self._sourceFaceId = value

    @property
    def topN(self):
        return self._topN

    @topN.setter
    def topN(self, value):
        self._topN = value
        
    @property
    def neighbours(self):
        return self._neighbours

    @neighbours.setter
    def neighbours(self, value):
        self._neighbours = value

class EvalImageCommand(BaseCommand):
    @property
    def imageRef(self):
        return self._imageRef

    @imageRef.setter
    def imageRef(self, value):
        assert isinstance(value, entities.ImageRef)
        self._imageRef = value

    @property
    def faces(self):
        return self._faces

    @faces.setter
    def faces(self, value):
        assert isinstance(value, entities.FaceSet)
        self._faces = value

    @property
    def topN(self):
        return self._topN

    @topN.setter
    def topN(self, value):
        self._topN = value
    
    @property
    def neighbours(self):
        return self._neighbours

    @neighbours.setter
    def neighbours(self, value):
        self._neighbours = value

    @property
    def knnProcessedBy(self):
        return self._knnProcessedBy

    @knnProcessedBy.setter
    def knnProcessedBy(self, value):
        self._knnProcessedBy = value

    @property
    def knnProcessedOn(self):
        return self._knnProcessedOn

    @knnProcessedOn.setter
    def knnProcessedOn(self, value):
        self._knnProcessedOn = value

    @property
    def faceQualityScoreThreshold(self):
        return self._faceQualityScoreThreshold

    @faceQualityScoreThreshold.setter
    def faceQualityScoreThreshold(self, value):
        self._faceQualityScoreThreshold = value
        

class EnrollImageCommand(BaseCommand):
    @property
    def imageRef(self):
        return self._imageRef

    @imageRef.setter
    def imageRef(self, value):
        assert isinstance(value, entities.ImageRef)
        self._imageRef = value

    @property
    def faces(self):
        return self._faces

    @faces.setter
    def faces(self, value):
        assert isinstance(value, entities.FaceSet)
        self._faces = value

    @property
    def autoConfirm(self):
        return self._autoConfirm

    @autoConfirm.setter
    def autoConfirm(self, value):
        self._autoConfirm = value

    @property
    def tags(self):
        return self._tags

    @tags.setter
    def tags(self, value):
        self._tags = value

    @property
    def sienaRefs(self):
        return self._sienaRefs

    @sienaRefs.setter
    def sienaRefs(self, value):
        self._sienaRefs = value

    @property
    def focalPoints(self):
        return self._focalPoints

    @focalPoints.setter
    def focalPoints(self, value):
        self._focalPoints = value

    @property
    def faceQualityScoreThreshold(self):
        return self._faceQualityScoreThreshold

    @faceQualityScoreThreshold.setter
    def faceQualityScoreThreshold(self, value):
        self._faceQualityScoreThreshold = value

class BatchEnrollImageCommand(EnrollImageCommand):
    pass

class RemoveFacesCommand(BaseCommand):
    @property
    def faces(self):
        return self._faces

    @faces.setter
    def faces(self, value):
        assert isinstance(value, entities.FaceSet)
        self._faces = value

class EnrollAndEvalImageCommand(EvalImageCommand):
    @property
    def autoConfirm(self):
        return self._autoConfirm

    @autoConfirm.setter
    def autoConfirm(self, value):
        self._autoConfirm = value

    @property
    def tags(self):
        return self._tags

    @tags.setter
    def tags(self, value):
        self._tags = value

    @property
    def sienaRefs(self):
        return self._sienaRefs

    @sienaRefs.setter
    def sienaRefs(self, value):
        self._sienaRefs = value

    @property
    def focalPoints(self):
        return self._focalPoints

    @focalPoints.setter
    def focalPoints(self, value):
        self._focalPoints = value

    @property
    def faceQualityScoreThreshold(self):
        return self._faceQualityScoreThreshold

    @faceQualityScoreThreshold.setter
    def faceQualityScoreThreshold(self, value):
        self._faceQualityScoreThreshold = value
        

class StatusCommand(BaseCommand):
    pass

class ReEnrollRequestCommand(BaseCommand):
    pass

class ErrorCommand(BaseCommand):
    @property
    def errorMessage(self):
        return self._errorMessage

    @errorMessage.setter
    def errorMessage(self, value):
        self._errorMessage = value

class CommandsEncoder(json.JSONEncoder):
    def default(self, obj):
        if hasattr(obj, "toJson"):
            return self.default(obj.toJson())
        elif hasattr(obj, "__dict__"):
            d = dict(
                (key, value)
                for key, value in inspect.getmembers(obj)
                # if not key.startswith("__")
                if not key.startswith("_")
                and not inspect.isabstract(value)
                and not inspect.isbuiltin(value)
                and not inspect.isfunction(value)
                and not inspect.isgenerator(value)
                and not inspect.isgeneratorfunction(value)
                and not inspect.ismethod(value)
                and not inspect.ismethoddescriptor(value)
                and not inspect.isroutine(value)
            )
            return self.default(d)
        return obj

class CommandsDecoder(json.JSONDecoder):
    def decode(self,json_string):
        command = super(CommandsDecoder,self).decode(json_string)

        if "cmdType" in command and command["cmdType"] == "EvalFaceCommand":
            decoded = EvalFaceCommand(command["token"])
            decoded.sourceFaceId = command["sourceFaceId"]
            self._set_command_basic_props(decoded, command)
            self._set_command_faces_prop(decoded, command)
            self._set_command_neighbours_prop(decoded, command)

        elif "cmdType" in command and command["cmdType"] == "EvalImageCommand":
            decoded = EvalImageCommand(command["token"])
            decoded.faceQualityScoreThreshold = self._safe_get("faceQualityScoreThreshold", command)
            self._set_command_basic_props(decoded, command)
            self._set_command_faces_prop(decoded, command)
            self._set_command_neighbours_prop(decoded, command)
            self._set_command_imageRef_prop(decoded, command)

        elif "cmdType" in command and command["cmdType"] == "EnrollImageCommand":
            decoded = EnrollImageCommand(command["token"])
            decoded.autoConfirm = self._safe_get("autoConfirm", command)
            decoded.tags = self._safe_get("tags", command)
            decoded.sienaRefs = self._safe_get("sienaRefs", command)
            decoded.focalPoints = self._safe_get("focalPoints", command)
            decoded.faceQualityScoreThreshold = self._safe_get("faceQualityScoreThreshold", command)
            self._set_command_basic_props(decoded, command)
            self._set_command_faces_prop(decoded, command)
            self._set_command_imageRef_prop(decoded, command)

        elif "cmdType" in command and command["cmdType"] == "BatchEnrollImageCommand":
            decoded = BatchEnrollImageCommand(command["token"])
            decoded.autoConfirm = self._safe_get("autoConfirm", command)
            decoded.tags = self._safe_get("tags", command)
            decoded.sienaRefs = self._safe_get("sienaRefs", command)
            decoded.focalPoints = self._safe_get("focalPoints", command)
            decoded.faceQualityScoreThreshold = self._safe_get("faceQualityScoreThreshold", command)
            self._set_command_basic_props(decoded, command)
            self._set_command_faces_prop(decoded, command)
            self._set_command_imageRef_prop(decoded, command)

        elif "cmdType" in command and command["cmdType"] == "RemoveFacesCommand":
            decoded = RemoveFacesCommand(command["token"])
            self._set_command_basic_props(decoded, command)
            decoded.faces = entities.FaceSet(None)
            if "faces" in command:
                for f in command["faces"]:
                    face = entities.Face(self._safe_get("id", f))
                    decoded.faces.addFace(face)

        elif "cmdType" in command and command["cmdType"] == "EnrollAndEvalImageCommand":
            decoded = EnrollAndEvalImageCommand(command["token"])
            decoded.autoConfirm = self._safe_get("autoConfirm", command)
            decoded.tags = self._safe_get("tags", command)
            decoded.sienaRefs = self._safe_get("sienaRefs", command)
            decoded.focalPoints = self._safe_get("focalPoints", command)
            decoded.faceQualityScoreThreshold = self._safe_get("faceQualityScoreThreshold", command)
            self._set_command_neighbours_prop(decoded, command)
            self._set_command_basic_props(decoded, command)
            self._set_command_faces_prop(decoded, command)
            self._set_command_imageRef_prop(decoded, command)

        elif "cmdType" in command and command["cmdType"] == "StatusCommand":
            decoded = StatusCommand(command["token"])
            self._set_command_basic_props(decoded, command)

        else:
            decoded = command

        return decoded

    def _set_command_basic_props(self, command, dictio):
        command.createdBy = self._safe_get("createdBy", dictio)
        command.createdOn = self._safe_get("createdOn", dictio)
        command.lastUpdatedBy = self._safe_get("lastUpdatedBy", dictio)
        command.lastUpdatedOn = self._safe_get("lastUpdatedOn", dictio)
        command.totalSteps = self._safe_get("totalSteps", dictio)
        command.lastStepCompleted = self._safe_get("lastStepCompleted", dictio)
        command.stepsCompleted = self._safe_get("stepsCompleted", dictio)

    def _set_command_neighbours_prop(self, command, dictio):
        command.neighbours = []
        command.topN = self._safe_get("topN", dictio)
        if "neighbours" in dictio:
            for n in dictio["neighbours"]:
                neighbour = entities.FaceNeighbour(self._safe_get("sourceFaceId", n), self._safe_get("targetFaceId", n), self._safe_get("grade", n))
                command.neighbours.append(neighbour)
        
    def _set_command_faces_prop(self, command, dictio):
        command.faces = entities.FaceSet(None)
        if "faces" in dictio:
            for f in dictio["faces"]:
                face = entities.Face(self._safe_get("id", f))
                if f["boundingBox"]:
                    topLeft = entities.Coord(f["boundingBox"]["topLeft"]["x"], f["boundingBox"]["topLeft"]["y"])
                    downRight = entities.Coord(f["boundingBox"]["downRight"]["x"], f["boundingBox"]["downRight"]["y"])
                    face.boundingBox = entities.BoundingBox(topLeft, downRight)
                face.features = self._safe_get("features", f)
                if f["imageRef"]:
                    face.imageRef = entities.ImageRef()
                    face.imageRef.refType = self._safe_get("refType", f["imageRef"])
                    face.imageRef.imagePath = self._safe_get("imagePath", f["imageRef"])
                    face.imageRef.imageId = self._safe_get("imageId", f["imageRef"])
                face.insertedBy = self._safe_get("insertedBy",f)
                face.insertedOn = self._safe_get("insertedOn",f)
                face.lastUpdatedOn = self._safe_get("lastUpdatedOn",f)
                command.faces.addFace(face)
        
    def _set_command_imageRef_prop(self, command, dictio):
        command.imageRef = entities.ImageRef()
        if "imageRef" in dictio:
            command.imageRef.refType = self._safe_get("refType", dictio["imageRef"])
            command.imageRef.imagePath = self._safe_get("imagePath", dictio["imageRef"])
            command.imageRef.imageId = self._safe_get("imageId", dictio["imageRef"])

    def _safe_get(self, prop_name, dictio):
        if prop_name in dictio:
            return dictio[prop_name]
        else:
            return None
        
