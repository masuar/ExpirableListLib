import sys
import cv2
import json
import inspect
import datetime
import numpy
import tensorflow as tf

class ImageRef(object):
    def __init(self):
        self.refType = "NONE"
    
    @property
    def refType(self):
        return self._refType

    @refType.setter
    def refType(self, value):
        if value == "FILESYS" or value == "FMMS" or value == "IVAS" or value == "NONE":
            self._refType = value
        else:
            raise AttributeError("refType only valid values are 'FILESYS' or 'FMMS' or 'IVAS' or 'NONE'")
    
    @property
    def imagePath(self):
        return self._imagePath
    
    @imagePath.setter
    def imagePath(self, value):
        self._imagePath = value

    @property
    def imageId(self):
        return self._imageId
    
    @imageId.setter
    def imageId(self, value):
        self._imageId = value

    # @property
    # def image_md5(self):
    #     return self._image_md5
    
    # @image_md5.setter
    # def image_md5(self, value):
    #     self._image_md5 = value

class FaceNeighbour(object):
    def __init__(self, sourceFaceId, targetFaceId, grade):
        self._sourceFaceId = sourceFaceId
        self._targetFaceId = targetFaceId
        self._grade = grade
        
    @property
    def sourceFaceId(self):
        return self._sourceFaceId

    @property
    def targetFaceId(self):
        return self._targetFaceId

    @property
    def grade(self):
        return self._grade
    


class Coord(object):
    def __init__(self, x, y):
        self.x = x
        self.y = y
    
    @property
    def x(self):
        return self._x
    
    @x.setter
    def x(self, value):
        if isinstance(value, numpy.generic):
            self._x = numpy.asscalar(value)
        else:
            self._x = value

    @property
    def y(self):
        return self._y
    
    @y.setter
    def y(self, value):
        if isinstance(value, numpy.generic):
            self._y = numpy.asscalar(value)
        else:
            self._y = value
    
class BoundingBox(object):
    def __init__(self, topLeft, downRight):
        self.topLeft = topLeft
        self.downRight = downRight
    
    @property
    def topLeft(self):
        return self._topLeft
    
    @topLeft.setter
    def topLeft(self, value):
        assert isinstance(value, Coord)
        self._topLeft = value

    @property
    def downRight(self):
        return self._downRight
    
    @downRight.setter
    def downRight(self, value):
        assert isinstance(value, Coord)
        self._downRight = value

class Face(object):
    def __init__(self, id):
        self.id = id
        self._boundingBox = None
        self._image = None
        self._tags = None
        self._sienaRefs = None
        self._focalPoints = None
        self._imageRef = None
        self._features = []
        self._confirmed = False
    
    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, value):
        self._id = value

    @property
    def boundingBox(self):
        return self._boundingBox

    @boundingBox.setter
    def boundingBox(self, value):
        assert isinstance(value, BoundingBox)
        self._boundingBox = value

    @property
    def imageRef(self):
        return self._imageRef

    @imageRef.setter
    def imageRef(self, value):
        assert isinstance(value, ImageRef)
        self._imageRef = value

    @property
    def features(self):
        return self._features

    @features.setter
    def features(self, value):
        if isinstance(value, numpy.ndarray):
            self._features = value.tolist()
        else:
            self._features = value

    @property
    def confirmed(self):
        return self._confirmed

    @confirmed.setter
    def confirmed(self, value):
        self._confirmed = value

    @property
    def insertedBy(self):
        return self._insertedBy

    @insertedBy.setter
    def insertedBy(self, value):
        self._insertedBy = value

    @property
    def insertedOn(self):
        return self._insertedOn

    @insertedOn.setter
    def insertedOn(self, value):
        self._insertedOn = value

    @property
    def lastUpdatedOn(self):
        return self._lastUpdatedOn

    @lastUpdatedOn.setter
    def lastUpdatedOn(self, value):
        self._lastUpdatedOn = value

    @property
    def tags(self):
        return self._tags

    @tags.setter
    def tags(self, value):
        self._tags = value

    @property
    def sienaRefs(self):
        return self._sienaRefs

    @sienaRefs.setter
    def sienaRefs(self, value):
        self._sienaRefs = value

    @property
    def focalPoints(self):
        return self._focalPoints

    @focalPoints.setter
    def focalPoints(self, value):
        self._focalPoints = value

    @property
    def qualityScore(self):
        return self._qualityScore

    @qualityScore.setter
    def qualityScore(self, value):
        self._qualityScore = value

    def setImage(self, image):
        self._image = image

    def getImage(self, with_overlay = None):
        result = self._image
        if with_overlay == True:
            img = self._image.copy()
            font = cv2.FONT_HERSHEY_PLAIN 
            cv2.putText(img, str(self.__index),(10, 30), font, 2,(255,0,0), 2)
            # if len(self.__metrics) > 0:
            #     cv2.putText(img, self.__metrics[0].to_string(),(10, 60), font, 1,(255,0,0), 1)
            #     if len(self.__metrics) > 1:
            #         cv2.putText(img, self.__metrics[1].to_string(),(10, 80), font, 1,(255,0,0), 1)

            result = img
        
        return result

    def __getstate__(self):
        state = self.__dict__.copy()
        del state['_image']
        return state

    def __setstate__(self, state):
        self.__dict__.update(state)
    
class FaceSet(object):
    def __init__(self, image):
        self._image = image
        self._processedBy = None
        self._processedOn = None
        self._faces = []

    def getMainImage(self, with_overlay):
        result = self._image
        if with_overlay == True:
            img = self._image.copy()
            font = cv2.FONT_HERSHEY_PLAIN 
            for f in self.__faces:
                cv2.rectangle(img, (f.boundingBox.topLeft.x, f.boundingBox.topLeft.y), (f.boundingBox.downRight.x, f.boundingBox.downRight.y), (255, 0, 0), 3)
                cv2.putText(img, str(f.index),(f.boundingBox.topLeft.x + 10, f.boundingBox.topLeft.y + 30), font, 2,(255,0,0), 2)
                # if len(f.metrics) > 0:
                #     cv2.putText(img, f.metrics[0].to_string(),(f.boundingBox.topLeft.x + 10, f.boundingBox.topLeft.y + 60), font, 1,(255,0,0), 1)
                #     if len(f.metrics) > 1:
                #         cv2.putText(img, f.metrics[1].to_string(),(f.boundingBox.topLeft.x + 10, f.boundingBox.topLeft.y + 80), font, 1,(255,0,0), 1)

            result = img
        
        return result

    def addFace(self, face):
        assert isinstance(face, Face) or issubclass(type(face), Face)
        self._faces.append(face)

    def getFace(self, index):
        return self._faces[index]

    def getFacesImages(self):
        result = []
        for face in self._faces:
            result.append(face.getImage())
        
        return result

    def count(self):
        return len(self._faces)

    @property
    def processedBy(self):
        return self._processedBy

    @processedBy.setter
    def processedBy(self, value):
        self._processedBy = value

    @property
    def processedOn(self):
        return self._processedOn

    @processedOn.setter
    def processedOn(self, value):
        self._processedOn = value

    def toJson(self):
        return self._faces
        

