import json
import uuid
import time
import os.path
import hashlib
import datetime
from scipy import misc

import commands
from scpymsg import stompestcon as stompestcon

class FaceEngineCommandProcessor(stompestcon.StompestMessageProcessor):
    def __init__(self, faceExtractor, featCalculator, connInfo, log = None):
        super(FaceEngineCommandProcessor, self).__init__(connInfo, log)
        self._faceExtractor = faceExtractor
        self._featCalculator = featCalculator

    def onRecovered(self):
        self._log.info("Recovered!")

    def onReceived(self, routingKey, body):
        try:
            cmd = json.loads(body, cls = commands.CommandsDecoder)
            now = self._getIsoFormat(datetime.datetime.utcnow())

            cmd.lastStepCompleted = 1
            cmd.stepsCompleted = 1
            cmd.lastUpdatedBy = "{} ({})".format(self.__class__.__name__, self.name)
            cmd.lastUpdatedOn = now

            if routingKey != "SmartCaps.FR.Status":
                image = misc.imread(os.path.expanduser(cmd.imageRef.imagePath), mode='RGB')
                self._log.info('Starting feat. calculations...')
                faces = self._faceExtractor.obtain_faces(image, cmd.faceQualityScoreThreshold)
                cmd.faces = self._featCalculator.calcFeats(faces)
                for faceIndex in range(cmd.faces.count()):
                    theFace = cmd.faces.getFace(faceIndex)
                    theFace.imageRef = cmd.imageRef
                    theFace.insertedBy = cmd.createdBy
                    theFace.insertedOn = now
                    theFace.lastUpdatedOn = now
                    if hasattr(cmd, 'autoConfirm'):
                        theFace.confirmed = cmd.autoConfirm != None and cmd.autoConfirm == True
                    if hasattr(cmd, 'tags'):
                        theFace.tags = cmd.tags
                    if hasattr(cmd, 'sienaRefs'):
                        theFace.sienaRefs = cmd.sienaRefs
                    if hasattr(cmd, 'focalPoints'):
                        theFace.focalPoints = cmd.focalPoints
                
                self._log.info('Features done for {} face/s...'.format(cmd.faces.count()))
                cmdMsg = json.dumps(cmd, cls = commands.CommandsEncoder)
                self.send(routingKey + '.FacesExtracted', cmdMsg)	
            else:
                cmd.lastStepCompleted += 1
                cmdMsg = json.dumps(cmd, cls = commands.CommandsEncoder)
                time.sleep(0.5) # Wait a bit
                self.send('SmartCaps.FR.Status.IAmAlive', cmdMsg)
            
        except Exception as ex:
            self._log.error("Error while processing message '{}': {}.".format(routingKey, ex))
            errorMsg = self._compileErrorMsg(body, ex)
            self.send(routingKey + '.Error', errorMsg)
            self._log.warning("Error message sent.")

    def _compileErrorMsg(self, msgBody, ex):
        rawCmd = json.loads(msgBody)
        token = rawCmd["token"]
        errorCmd = commands.ErrorCommand(token)
        errorCmd.createdBy = "{} ({})".format(self.__class__.__name__, self.name)
        errorCmd.createdOn = self._getIsoFormat(datetime.datetime.utcnow())
        errorCmd.errorMessage = str(ex)
        errorMsg = json.dumps(errorCmd, cls = commands.CommandsEncoder)
        return errorMsg
        
    def _getIsoFormat(self, dt):
        if dt != None:
            return dt.isoformat("T") + "Z"
        else:
            return ""
    
class KnnEngineCommandProcessor(stompestcon.StompestMessageProcessor):
    def __init__(self, knnCalculator, connInfo, log = None):
        super(KnnEngineCommandProcessor, self).__init__(connInfo, log)
        self._knnCalculator = knnCalculator

    def onRecovered(self):
        self._log.info("Recovered!")
        self._knnCalculator.printHowManyFaces()

    def onStart(self):
        cmd = commands.ReEnrollRequestCommand(str(uuid.uuid4()))
        cmd.createdBy = "{} ({})".format(self.__class__.__name__, self.name)
        cmd.createdOn = self._getIsoFormat(datetime.datetime.utcnow())
        cmd_msg = json.dumps(cmd, cls = commands.CommandsEncoder)
        self.send("SmartCaps.FR.ReEnroll", cmd_msg)
        self._log.info("Re-enroll requested!")

    def onReceived(self, routingKey, body):
        try:
            cmd = json.loads(body, cls = commands.CommandsDecoder)
            cmd.lastStepCompleted = 2
            cmd.stepsCompleted = 2
            cmd.lastUpdatedBy = "{} ({})".format(self.__class__.__name__, self.name)
            cmd.lastUpdatedOn = self._getIsoFormat(datetime.datetime.utcnow())

            if routingKey == "SmartCaps.FR.EvalImage.FacesExtracted":
                cmd.neighbours = []        
                for i in range(cmd.faces.count()):
                    cmd.neighbours.extend(self._knnCalculator.calcKnn(cmd.faces.getFace(i), cmd.topN))

                cmdMsg = json.dumps(cmd, cls = commands.CommandsEncoder)
                self.send(routingKey + '.KnnDone', cmdMsg)

            elif routingKey == "SmartCaps.FR.EnrollImage.FacesExtracted":
                self._knnCalculator.enrollFaces(cmd.faces)
                # Why do not respond here?

            elif routingKey == "SmartCaps.FR.EnrollAndEvalImage.FacesExtracted":
                try:
                    cmd.neighbours = []        
                    for i in range(cmd.faces.count()):
                        cmd.neighbours.extend(self._knnCalculator.calcKnn(cmd.faces.getFace(i), cmd.topN))
                except Exception as ex:
                    self._log.error(ex)

                self._knnCalculator.enrollFaces(cmd.faces)
                cmdMsg = json.dumps(cmd, cls = commands.CommandsEncoder)
                self.send(routingKey + '.KnnDone', cmdMsg)

            elif routingKey == "SmartCaps.FR.RemoveFaces":
                self._knnCalculator.removeFaces(cmd.faces)
                # Why do not respond here?

            elif routingKey == "SmartCaps.FR.EvalFace":
                cmd.neighbours = []        
                cmd.neighbours.extend(self._knnCalculator.calcKnnOfInMem(cmd.sourceFaceId, cmd.topN))
                cmdMsg = json.dumps(cmd, cls = commands.CommandsEncoder)
                self.send(routingKey + '.KnnDone', cmdMsg)
            
            elif routingKey == "SmartCaps.FR.Status":
                cmdMsg = json.dumps(cmd, cls = commands.CommandsEncoder)
                self.send('SmartCaps.FR.Status.IAmAlive', cmdMsg)

        except Exception as ex:
            self._log.error("Error while processing message '{}': {}.".format(routingKey, ex))
            errorMsg = self._compileErrorMsg(body, ex)
            self.send(routingKey + '.Error', errorMsg)
            self._log.warning("Error message sent.")

    def _compileErrorMsg(self, msgBody, ex):
        rawCmd = json.loads(msgBody)
        token = rawCmd["token"]
        errorCmd = commands.ErrorCommand(token)
        errorCmd.createdBy = "{} ({})".format(self.__class__.__name__, self.name)
        errorCmd.createdOn = self._getIsoFormat(datetime.datetime.utcnow())
        if hasattr(ex,'message'):
            errorCmd.errorMessage = ex.message
        else:
            errorCmd.errorMessage = ex
        error_msg = json.dumps(errorCmd, cls = commands.CommandsEncoder)
        return error_msg
        


    def _getIsoFormat(self, dt):
        if dt != None:
            return dt.isoformat("T") + "Z"
        else:
            return ""
