import cv2
import sys
import uuid
import hashlib
import os.path
import logging
import entities
import numpy as np
from scipy import misc
import tensorflow as tf
from align import detect_face
import facenet

from sklearn.neighbors import NearestNeighbors

class FacenetFeatCalculator(object):
    def __init__(self, faceExtractor, featModelDir, featMetaFile, featCkptFile, log = None):
        self._log = log or logging.getLogger(__name__)
        self._faceExtractor = faceExtractor
        self._log.info("Initializing feature calculator model...")
        self._sess = tf.Session(config = tf.ConfigProto(log_device_placement = False))

        # facenet.load_model(featModelDir, featMetaFile, featCkptFile)
        modelDirExp = os.path.expanduser(featModelDir)
        saver = tf.train.import_meta_graph(os.path.join(modelDirExp, featMetaFile))
        saver.restore(self._sess, os.path.join(modelDirExp, featCkptFile))

        self._images_placeholder = tf.get_default_graph().get_tensor_by_name("input:0")
        self._embeddings = tf.get_default_graph().get_tensor_by_name("embeddings:0")
        self._phase_train_placeholder = tf.get_default_graph().get_tensor_by_name("phase_train:0")
        self._log.info("Feature calculator model initialized successfully.")

    def __del__(self):
        self._log.info('Feature calculator TF session started releasing...')
        self._sess.close()
        self._log.info('Feature calculator TF session released successfully.')

    def calcFeats(self, faces):
        if faces.count() > 0:
            feed_dict = { self._images_placeholder: faces.getFacesImages(), self._phase_train_placeholder: False }
            self._log.debug('Getting features...')
            features = self._sess.run(self._embeddings, feed_dict = feed_dict)
            self._log.debug('Got {} features'.format(len(features)))
            for faceIndex in range(faces.count()):
                faces.getFace(faceIndex).features = features[faceIndex]

        return faces

class FakeFeatCalculator(object):
    def calcFeats(self, image):
        return self._createFakeFaces()
    
    def _createFakeFaces(self):
        fs = entities.FaceSet(None)
        fs.addFace(entities.Face(str(uuid.uuid1())))
        fs.addFace(entities.Face(str(uuid.uuid1())))
        fs.addFace(entities.Face(str(uuid.uuid1())))
        return fs

    def _getIsoFormat(self, dt):
        if dt != None:
            return dt.isoformat("T") + "Z"
        else:
            return ""

class SKLearnKnnCalculator(object):
    def __init__(self, log = None):
        self._log = log or logging.getLogger(__name__)
        self._log.info("Initializing SKLearnKnnCalculator...")
        self._nearestNeighbours = NearestNeighbors()
        self._faces = {}

    def enrollFaces(self, faceSet):
        howManyFaces = faceSet.count()
        self._log.info("Enrolling {} face/s...".format(howManyFaces))
        if howManyFaces > 0: # Saves some time and processing
            for i in range(howManyFaces):
                face = faceSet.getFace(i)
                self._faces[face.id] = face.features

            self._nearestNeighbours.fit(np.array(list(self._faces.values())))

        self.printHowManyFaces()

    def removeFaces(self, faceSet):
        howManyFaces = faceSet.count()
        self._log.info("Removing {} face/s...".format(howManyFaces))
        if howManyFaces > 0: # Saves some time and processing
            for i in range(howManyFaces):
                face = faceSet.getFace(i)
                if face.id in self._faces:
                    del self._faces[face.id]
                    self._log.info("Face {} removed.".format(face.id))
                else:
                    self._log.info("Face {} not found.".format(face.id))
            
            self._nearestNeighbours.fit(np.array(list(self._faces.values())))
        self.printHowManyFaces()

    def printHowManyFaces(self):
        self._log.info("There are {} faces available for Knn.".format(len(self._faces)))

    def calcKnn(self, source_face, topN):
        real_topN = min(topN + 1, len(self._faces))
        self._log.info("Calculating {} neighbors for face '{}'...".format(real_topN, source_face.id))
        result = []
        dist, knn = self._nearestNeighbours.kneighbors(np.array([source_face.features]), n_neighbors = real_topN)
        self._log.debug("Dist: {}".format(dist[0]))
        self._log.debug("Knn: {}".format(knn[0]))
        for i in range(len(knn[0])):
            face_index = knn[0][i]
            targetFaceId = list(self._faces.keys())[face_index]
            if targetFaceId != source_face.id:
                result.append(entities.FaceNeighbour(source_face.id, targetFaceId, dist[0][i]))
        
        return result
    
    def calcKnnOfInMem(self, sourceFaceId, topN):
        if sourceFaceId not in self._faces:
            # face not found
            raise Exception("Face '{}' not found.".format(sourceFaceId))
        
        face = entities.Face(sourceFaceId)
        face.features = self._faces[sourceFaceId]
        return self.calcKnn(face, topN)

class FakeKnnCalculator(object):
    def __init__(self):
        self._faces = {}

    def enrollFaces(self, faceSet):
        for i in range(faceSet.count()):
            face = faceSet.getFace(i)
            self._faces[face.id](face.features)

    def removeFaces(self, faces_set):
        for i in range(faceSet.count()):
            face = faceSet.getFace(i)
            del self._faces[face.id]

    def calcKnn(self, face, topN):
        return self._createFakeKnns(face.id, topN)
    
    def calcKnnOfInMem(self, sourceFaceId, topN):
        return self._createFakeKnns(face.id, topN)
        
    def _createFakeKnns(self, sourceFaceId, topN):
        result = []
        for i in range(topN):
            result.append(entities.FaceNeighbour(sourceFaceId, str(uuid.uuid4()), 0.5))

        return result
    
class FacenetFaceExtractor(object):
    def __init__(self, faceModelPath, faceMinSize, faceFinalSize, log = None):
        self._log = log or logging.getLogger(__name__)
        self._faceMinSize = faceMinSize
        self._faceFinalSize = faceFinalSize or 160
        self._log.info("Initializing face extractor model...")
        self._sess = tf.Session(config = tf.ConfigProto(log_device_placement = False))
        self._pnet, self._rnet, self._onet = detect_face.create_mtcnn(self._sess, faceModelPath)
        self._log.info("Face extractor model initialized successfully.")

        # with tf.Graph().as_default():
        #     sess = tf.Session(config = tf.ConfigProto(log_device_placement = False))
        #     with sess.as_default():
        #         self._pnet, self._rnet, self._onet = detect_face.create_mtcnn(sess, model_path)

    def __del__(self):
        self._sess.close()
        self._log.info('Face extractor TF session released successfully.')

    def obtain_faces(self, image, minScore = 0):
        #minsize = 20 # minimum size of face
        threshold = [ 0.6, 0.7, 0.7 ]  # three steps's threshold
        factor = 0.709 # scale factor
        argsmargin = 44
        argsimage_size = 182
        
        # image = misc.imread(os.path.expanduser(imagePath), mode='RGB')
        image_size = np.asarray(image.shape)[0:2]
        try:
            self._log.debug('Image shape: {}'.format(image.shape))
            self._log.debug('Getting faces...')
            boundingBoxes, _ = detect_face.detect_face(image, self._faceMinSize, self._pnet, self._rnet, self._onet, threshold, factor)
        except:
            self._log.debug(sys.exc_info()[0])
            self._log.info('No faces found!')
            boundingBoxes = []

        resultingFaces = entities.FaceSet(image)
        howManyFaces = boundingBoxes.shape[0]
        self._log.debug('Got {} faces.'.format(howManyFaces))

        if len(boundingBoxes) > 0 and howManyFaces > 0:
            for i in range(howManyFaces):
                det = np.squeeze(boundingBoxes[i,0:4])
                score = boundingBoxes[i,4] 
                if score > minScore:
                    bb = np.zeros(4, dtype=np.int32)
                    bb[0] = np.maximum(det[0]-argsmargin/2, 0)
                    bb[1] = np.maximum(det[1]-argsmargin/2, 0)
                    bb[2] = np.minimum(det[2]+argsmargin/2, image_size[1])
                    bb[3] = np.minimum(det[3]+argsmargin/2, image_size[0])
                    
                    result = image[bb[1]:bb[3],bb[0]:bb[2],:]
                    result = misc.imresize(result, (self._faceFinalSize, self._faceFinalSize), interp='bilinear')
                    result = facenet.prewhiten(result)

                    md5 = hashlib.md5(result.tostring()).hexdigest()
                    face = entities.Face(md5)
                    face.boundingBox = entities.BoundingBox(
                        entities.Coord(bb[0], bb[1]), 
                        entities.Coord(bb[2], bb[3])
                        )
                    face.setImage(result)
                    face.qualityScore = score
                    resultingFaces.addFace(face)

        return resultingFaces

