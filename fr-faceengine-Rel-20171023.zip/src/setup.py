from setuptools import setup

setup(name='scpyfr',
      version='1.0',
      description='Smart Capabilities Face Recognition Python Engine',
      author='Europol',
      author_email='mauricio.asuar-garcia@europol.europa.eu',
      packages=['scpyfr'],
      install_requires=[
          'scpymsg',
          'tensorflow',
          'numpy',
          'facenet',
          'sklearn'
          'cv2',
          'scipy',
          'inspect',
          'json',
          'sys',
          'datetime',
          'uuid',
          'logging',
      ],
      zip_safe=False)