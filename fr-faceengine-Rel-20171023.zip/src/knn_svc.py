import os
import json
import logging.config
import traceback
import sys

import win32service, winerror
import win32serviceutil
import win32event

import servicemanager

import util
import scpyfr.services as fr_services
import scpyfr.processors as fr_processors

class KnnWinSvc(win32serviceutil.ServiceFramework):
    
    thefolder = os.path.dirname(os.path.realpath(__file__))
    os.chdir(thefolder)
    _config = util.readKnnConf("knn_svc.ini")
    _log = util.setupLogging(logger_name = 'KNN', inst_name = _config.name, verbose = _config.verbose, default_path = 'knn_log_config.json')
    _svc_name_ = _config.name
    _svc_display_name_ = "SmartCaps FR Knn ({})".format(_svc_name_)
    _svc_description_ = "This service handles the KNN process for getting faces similarities."

    def __init__(self,args):
        win32serviceutil.ServiceFramework.__init__(self,args)
        self._knnEngine = None
        self.hWaitStop = win32event.CreateEvent(None, 0, 0, None)

    def SvcDoRun(self):
        servicemanager.LogMsg(servicemanager.EVENTLOG_INFORMATION_TYPE, servicemanager.PYS_SERVICE_STARTED, (self._svc_name_,''))

        try:
            self._log.info("Loading...")
            msg = "Configuration read: "
            msg += 'instance name = {}; '.format(self._config.name)
            msg += 'instance verbosity = {}; '.format(self._config.verbose)
            msg += 'activemq server = {}; '.format(self._config.server)
            msg += 'activemq user = {}; '.format(self._config.user)
            msg += 'activemq listento = {}; '.format(self._config.listento)
            msg += 'activemq pubto = {}; '.format(self._config.pubto)
            self._log.debug(msg)
            self.printEventLogMsg(msg)
        
            knnCalculator = fr_services.SKLearnKnnCalculator(self._log)
            self._knnEngine = fr_processors.KnnEngineCommandProcessor(knnCalculator, self._config, self._log)
            self._knnEngine.onStop = lambda _: win32event.SetEvent(self.hWaitStop)

            self._log.info('Loaded!')
            self._knnEngine.start()

        except Exception as ex:
            if hasattr(ex, 'message'):
                msg = ex.message
            else:
                msg = str(ex)
            
            self.printEventLogMsg('Error! ' + msg)
            win32event.SetEvent(self.hWaitStop)
            pass
        
        rc = None
        while rc != win32event.WAIT_OBJECT_0:
            rc = win32event.WaitForSingleObject(self.hWaitStop, 5000)
        
        servicemanager.LogMsg(servicemanager.EVENTLOG_INFORMATION_TYPE, servicemanager.PYS_SERVICE_STOPPED, (self._svc_name_,''))

    def SvcStop(self):
        self._knnEngine.stop()

    def printEventLogMsg(self, msg):
        servicemanager.LogMsg(servicemanager.EVENTLOG_INFORMATION_TYPE, 0xF000, (msg ,''))

if __name__ == '__main__':
    win32serviceutil.HandleCommandLine(KnnWinSvc)
