import os
import json
import logging.config
import optparse

import scpyfr.processors as fr_processors
import scpyfr.services as fr_services

def setup_logging(logger_name, inst_name, verbose = False, default_path = 'face_log_config.json'):
    path = default_path
    if os.path.exists(path):
        with open(path, 'rt') as f:
            config = json.load(f)
        logging.config.dictConfig(config)
    else:
        logging.basicConfig(level = logging.INFO)

    if verbose == True:
        loglevel = logging.DEBUG
    else:
        loglevel = logging.INFO

    log = logging.getLogger(logger_name)
    log = logging.LoggerAdapter(log, {'inst_name' : inst_name})
    log.setLevel(loglevel)

    if verbose == True:
        log.debug('Verbose ON.')
    
    return log

def main(opts, args):
    log = setup_logging(logger_name = 'FACE', inst_name = opts.name, verbose = opts.verbose)

    # faceModelPath = '/home/smartcaps/facenet/src/align'
    faceMinSize = 40
    faceFinalSize = 160

    # featModelDir = '/home/smartcaps/facenet/data/msceleb-20170306-150500-fix'
    featMetaFile = 'model-20170306-150500.meta'
    featCkptFile = 'model-20170306-150500.ckpt-250000'

    faceExtractor = fr_services.FacenetFaceExtractor(opts.models, faceMinSize, faceFinalSize, log)
    featCalculator = fr_services.FacenetFeatCalculator(faceExtractor, opts.models, featMetaFile, featCkptFile, log)

    face_engine = fr_processors.FaceEngineCommandProcessor(faceExtractor, featCalculator, opts, log)
    log.info('Go!')
    face_engine.start()

if __name__ == "__main__":
    parser = optparse.OptionParser(usage = "usage: %prog [options]", description = "Listen to Face Engine AMQP messages to process.")
    parser.add_option("-n", "--name", type="string", help="the instance name")
    parser.add_option("-s", "--server", default = "localhost", help = "server to which messages will be listen (default %default)")
    parser.add_option("-p", "--port", default = "61613", help = "port to which messages will be listen (default %default)")
    parser.add_option("-u", "--user", default = "admin", help = "stomp server user (default %default)")
    parser.add_option("-x", "--pwd", default = "admin", help = "stomp server pwd (default %default)")
    parser.add_option("-q", "--listento", type="string", default="/queue/SmartCaps.FR.FaceEngine", help="the queue to listen to (default %default)")
    parser.add_option("-t", "--pubto", type="string", default="/topic/SmartCaps_TOPIC", help="the topic to publish the responses to (default %default)")
    parser.add_option("-m", "--models", type='string', default = "..\\models", help="Path to local models store (default %default)")
    parser.add_option("-v", "--verbose", action='store_true', help="verbose mode")
    # parser.add_option("-f", "--fake", action='store_true', help="fake mode")

    opts, args = parser.parse_args()

    main(opts, args)
