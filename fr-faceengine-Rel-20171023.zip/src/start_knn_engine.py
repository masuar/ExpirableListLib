import os
import json
import logging.config
import optparse

import scpyfr.services as fr_services
import scpyfr.processors as fr_processors

def setup_logging(logger_name, inst_name, verbose = False, default_path = 'knn_log_config.json'):
    path = default_path
    if os.path.exists(path):
        with open(path, 'rt') as f:
            config = json.load(f)
        logging.config.dictConfig(config)
    else:
        logging.basicConfig(level = logging.INFO)

    if verbose == True:
        loglevel = logging.DEBUG
    else:
        loglevel = logging.INFO

    log = logging.getLogger(logger_name)
    log = logging.LoggerAdapter(log, {'inst_name' : inst_name})
    log.setLevel(loglevel)

    if verbose == True:
        log.debug('Verbose ON.')
    
    return log

def main(opts, args):
    log = setup_logging(logger_name = 'KNN', inst_name = opts.name, verbose = opts.verbose)
    
    if opts.fake == None:
        knnCalculator = fr_services.SKLearnKnnCalculator(log)
    else:
        knnCalculator = fr_services.FakeKnnCalculator()
    
    knn_engine = fr_processors.KnnEngineCommandProcessor(knnCalculator, opts, log)
    log.info('Starting...')
    knn_engine.start()

if __name__ == "__main__":
    parser = optparse.OptionParser(usage = "usage: %prog [options]", description = "Listen to Knn Engine AMQP messages to process.")
    parser.add_option("-n", "--name", type="string", help="the instance name")
    parser.add_option("-s", "--server", default = "localhost", help = "server to which messages will be listen (default %default)")
    parser.add_option("-p", "--port", default = "61613", help = "port to which messages will be listen (default %default)")
    parser.add_option("-u", "--user", default = "admin", help = "stomp server user (default %default)")
    parser.add_option("-x", "--pwd", default = "admin", help = "stomp server pwd (default %default)")
    parser.add_option("-q", "--listento", type="string", default="/queue/SmartCaps.FR.Knn", help="the queue to listen to (default %default)")
    parser.add_option("-t", "--pubto", type="string", default="/topic/SmartCaps_TOPIC", help="the topic to publish the responses to (default %default)")
    parser.add_option("-v", "--verbose", action='store_true', help="verbose mode")
    parser.add_option("-f", "--fake", action='store_true', help="fake mode")

    opts, args = parser.parse_args()

    main(opts, args)
