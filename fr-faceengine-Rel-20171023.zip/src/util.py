import os
import json
import configparser
import logging.config

class MicroMock(object):
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

def readFaceConf(iniFile):
    config = configparser.ConfigParser()
    config.read(iniFile)

    faceConfig = MicroMock(
        name = config.get('instance', 'name'), 
        server = config.get('activemq', 'server'), 
        port = config.get('activemq', 'port'), 
        user = config.get('activemq', 'user'), 
        pwd = config.get('activemq', 'pwd'), 
        listento = config.get('activemq', 'listento'), 
        pubto = config.get('activemq', 'pubto'), 
        verbose = config.getboolean('instance', 'verbose'),
        models = config.get('instance', 'models'),
        faceMinSize = config.getint('faceProcessing', 'minSize'))

    return faceConfig

def readKnnConf(iniFile):
    config = configparser.ConfigParser()
    config.read(iniFile)

    knnConfig = MicroMock(
        name = config.get('instance', 'name'), 
        server = config.get('activemq', 'server'), 
        port = config.get('activemq', 'port'), 
        user = config.get('activemq', 'user'), 
        pwd = config.get('activemq', 'pwd'), 
        listento = config.get('activemq', 'listento'), 
        pubto = config.get('activemq', 'pubto'), 
        verbose = config.getboolean('instance', 'verbose'))

    return knnConfig

def setupLogging(logger_name, inst_name, verbose = False, default_path = 'logging.json'):
    path = default_path
    if os.path.exists(path):
        with open(path, 'rt') as f:
            config = json.load(f)
        logging.config.dictConfig(config)
    else:
        self.printEventLogMsg('{} not found. Will use default logging.'.format(default_path))
        logging.basicConfig(level = logging.INFO)

    if verbose == True:
        loglevel = logging.DEBUG
    else:
        loglevel = logging.INFO

    log = logging.getLogger(logger_name)
    log = logging.LoggerAdapter(log, {'inst_name' : inst_name})
    log.setLevel(loglevel)

    if verbose == True:
        log.debug('Verbose ON.')
    
    return log
