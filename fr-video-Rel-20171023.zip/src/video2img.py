import os
import datetime
import shutil
import argparse
import logging
import scpyfr.services as fr_services
import util
from scipy import misc
import json
import urllib.parse

import requests, base64, datetime
from requests.auth import HTTPBasicAuth

logger = logging.getLogger(__name__)


class VideoSplitter:

    def __init__(self, input_video_path, output_folder=None, log=None):
        self._log = log
        self.input_video_path = input_video_path

        if output_folder:
            self.WORKING_DIR = output_folder
        else:
            self.WORKING_DIR = input_video_path + '_data'

        if not os.path.exists(self.WORKING_DIR):
            os.mkdir(self.WORKING_DIR)
        else:
            shutil.rmtree(self.WORKING_DIR)
            os.mkdir(self.WORKING_DIR)

    def split_with_open_cv(self, detailed=False):
        import cv2
        self._log.debug("Cutting video with open cv " + cv2.__version__ + "...")

        vidcap = cv2.VideoCapture(self.input_video_path)
        success, image = vidcap.read()
        fps = vidcap.get(cv2.CAP_PROP_FPS)
        fps = int(round(fps))
        self._log.debug(str(fps)+"fps")

        count = 0
        success = True
        while success:
            frameId = int(round(vidcap.get(1)))
            success, image = vidcap.read()
            if frameId % fps == 0:  # only one frame per second
                cv2.imwrite(self.WORKING_DIR+"\\img%.4d.jpg" % count, image)
                count += 1
            else:
                if detailed:
                    cv2.imwrite(self.WORKING_DIR+"\\img%.4d.jpg" % count, image)
                    count += 1
        self._log.debug("Video split into " + str(count) + " frames.")
        if count>60:
            self._log.debug(str(count/60)+" minutes.")
        return count

    def compare_cv_histogram(self, img1, img2):
        import cv2
        im1 = cv2.imread(img1, 0)
        hist1 = cv2.calcHist([im1], [0], None, [256], [0,256])
        im2 = cv2.imread(img2, 0)
        hist2 = cv2.calcHist([im2], [0], None, [256], [0,256])
        a = cv2.compareHist(hist1, hist2, cv2.HISTCMP_BHATTACHARYYA)
        return 100 - a * 100

    def reduce_by_comparing(self, cutoffpertentage):
        img_list = []
        allFiles = os.listdir(self.WORKING_DIR)
        self._log.debug("Found {} files.".format(len(allFiles)))
        for filename in allFiles:
            if (filename.endswith(".png") or filename.endswith(".jpg")) and os.stat(os.path.join(self.WORKING_DIR, filename)).st_size != 0:
                img_list.append(filename)
            else:
                os.remove(os.path.join(self.WORKING_DIR, filename))
                self._log.debug("File {} removed.".format(filename))

        a = 0
        b = 1
        c = 0

        for i in range(1, len(img_list)):
            percent = self.compare_cv_histogram(os.path.join(self.WORKING_DIR, img_list[a]), os.path.join(self.WORKING_DIR, img_list[b]))
            self._log.debug("Image {} and {} are {} percent equals.".format(img_list[a],img_list[b],percent))
            if percent > cutoffpertentage:
                os.remove(os.path.join(self.WORKING_DIR, img_list[b]))
                self._log.debug(str(int(percent))+"\t"+img_list[b]+" removed")
                b += 1
            else:
                self._log.debug(str(int(percent)) + "\t" +img_list[b] + " stays")
                b += 1
                a = b-1
                c += 1
        return c

    def reduce_by_facelookup(self, faceExtractor, faceQualityScoreThreshold):
        a = 0
        for filename in os.listdir(self.WORKING_DIR):
            if (filename.endswith(".png") or filename.endswith(".jpg")) and os.stat(os.path.join(self.WORKING_DIR, filename)).st_size != 0:
                path = os.path.join(self.WORKING_DIR, filename)

                image = misc.imread(os.path.expanduser(path), mode='RGB')

                faces = faceExtractor.obtain_faces(image, faceQualityScoreThreshold)
                if faces.count() == 0:
                    self._log.debug(filename + ":\t" + 'removed. 0 faces')
                    os.remove(os.path.join(self.WORKING_DIR, filename))
                else:
                    self._log.debug(filename + ":\t"+str(faces.count()))
                    a += 1
        return a


    def enroll_img_in_api(self, img, requestor, tags, focalPoints, sienaNums, faceThreshold, originalFileName, apiserv='https://fr-api.dev.development.int', apiusr='erpl', apipass='ABCabc123.'):
            imgname = os.path.basename(img)
            files = {imgname: open(img, 'rb')}
            url = apiserv + '/commands/enroll/images?' \
                            'imageRefType=FILESYS' \
                            '&async=false' \
                            '&options.eval=false' \
                            '&options.batchMode=true' \
                            '&options.requestedBy=' + requestor + \
                            '&options.confirm=false' + \
                            '&options.faceQualityScoreThreshold=' + str(faceThreshold) + \
                            self.getTagsParams(imgname, originalFileName, tags) + \
                            self.getSienaNumsParams(sienaNums) + \
                            self.getFocalPointsParams(focalPoints)
                            
            r = requests.post(url,
                          files=files,
                          auth=HTTPBasicAuth(apiusr, apipass),
                          verify=False
                          )
            if r.status_code == 201:
                response = r.json()
                self._log.debug(response)
                return response
            else:
                self._log.error("REQUEST RETURNED " + str(r.status_code))
                return {imgname: "REQUEST RETURNED " + str(r.status_code)}
        
    def getTagsParams(self, imageName, originalFileName, tags):
        result = '&options.tags=video&options.tags=' + self.getSafeString(imageName)
        if originalFileName:
            result += '&options.tags=' + self.getSafeString(originalFileName)
        if tags:
            for tag in tags:
                result += '&options.tags=' + self.getSafeString(tag)

        return result

    def getFocalPointsParams(self, focalPoints):
        result = ''
        if focalPoints:
            for focalPoint in focalPoints:
                result += '&options.focalPoints=' + self.getSafeString(focalPoint)

        return result

    def getSienaNumsParams(self, sienaNums):
        result = ''
        if sienaNums:
            for sienaNum in sienaNums:
                result += '&options.sienaRefs=' + self.getSafeString(sienaNum)

        return result


    def getSafeString(self, string):
        result = string
        if string:
            result = result.replace('.','-').replace('_','-').replace('#','-')
            #result = urllib.parse.urlencode(result)

        return result

def main(args):
    config = util.readVideoConf(".\\video_svc.ini")
    msg = "Configuration read: \n"
    for conf in config.__dict__:
        msg += '{} = {};\n'.format(conf, config.__dict__[conf])
    log = util.setupLogging(inst_name=config.name, verbose=config.verbose, filename=config.logfile)
    log.info(msg)

    faceExtractor = fr_services.FacenetFaceExtractor(config.models, 40, 160, log)

    t1 = datetime.datetime.now()
    v = VideoSplitter(args.input, args.output, log)
    frmcnt1 = v.split_with_open_cv(args.detailed_split_mode)
    t2 = datetime.datetime.now()
    frmcnt2 = v.reduce_by_comparing(args.cutoff)
    t3 = datetime.datetime.now()
    frmcnt3 = v.reduce_by_facelookup(faceExtractor, 0.9999)
    t4 = datetime.datetime.now()
    paths = []
    for filename in os.listdir(args.output):
            path = os.path.join(args.output, filename)
            paths.append(path)
    resp = v.enroll_in_api(paths, 'test',)
    print(resp)
    t5 = datetime.datetime.now()
    timedelta1 = t2 - t1
    timedelta2 = t3 - t2
    timedelta3 = t4 - t3
    timedelta4 = t4 - t3
    log.info(">>Split time: "+str(timedelta1.total_seconds())+" \t images:"+str(frmcnt1))
    log.info(">>Compare time: "+str(timedelta2.total_seconds())+" \t images:"+str(frmcnt2))
    log.info(">>FindFace time: "+str(timedelta3.total_seconds())+" \t images:"+str(frmcnt3))
    log.info(">>API enroll time: " + str(timedelta4.total_seconds()) + " \t images:" + str(len(paths)))

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Video Splitter v. 1.0")
    parser.add_argument('input', type=str, help="Full Path of the video to process")
    parser.add_argument('output', type=str, help="Directroy to whitch images will be put")
    parser.add_argument('--cutoff', type=int, default = "75", help="percentage of similarity between pictures")
    parser.add_argument('--detailed_split_mode', action='store_true', default=False, help=" In this mode instead of 1 frame per second, all frames will be extracted")

    args = parser.parse_args()
    main(args)

#python video2img.py c:\Humi\moviez\video4.mp4 c:\Humi\moviez\output --cutoff 70