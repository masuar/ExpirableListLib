import os
import sys
import json
import configparser
import logging
import datetime

class MicroMock(object):
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

def readVideoConf(iniFile):
    config = configparser.ConfigParser()
    config.read(iniFile)

    videoConfig = MicroMock(
        name = config.get('instance', 'name'),
        verbose = config.getboolean('instance', 'verbose'),
        workingdir = config.get('instance', 'workingdir'),
        apiserver=config.get('instance', 'apiserver'),
        apiuser=config.get('instance', 'apiuser'),
        apiuserpwd=config.get('instance', 'apiuserpwd'),
        logfile=config.get('instance', 'logfile'),
        models=config.get('face', 'models'),
        faceMinSize=config.getint('face', 'faceMinSize'),
        faceFinalSize=config.getint('face', 'faceFinalSize'),
        server = config.get('activemq', 'server'),
        port = config.get('activemq', 'port'),
        user = config.get('activemq', 'user'),
        pwd = config.get('activemq', 'pwd'),
        listento = config.get('activemq', 'listento'),
        pubto = config.get('activemq', 'pubto'))
    return videoConfig


def setupLogging(logger_name='VIDEO', inst_name='video', verbose=False, filename='face[DATE].log'):

    if verbose == True:
        loglevel = logging.DEBUG
    else:
        loglevel = logging.INFO

    logger = logging.getLogger(logger_name)
    logger.setLevel(loglevel)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    consoleHandler = logging.StreamHandler(sys.stdout)
    consoleHandler.setFormatter(formatter)
    consoleHandler.setLevel(loglevel)
    logger.addHandler(consoleHandler)

    filename = filename.replace('[DATE]', datetime.date.today().strftime("%y%m%d"))
    handler = logging.FileHandler(filename)
    handler.setLevel(loglevel)
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    logger = logging.LoggerAdapter(logger, {'inst_name' : inst_name})

    if verbose == True:
        logger.debug('Verbose ON.')
    
    return logger
