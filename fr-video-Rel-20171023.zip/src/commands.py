import inspect
import json
import entities

class BaseCommand(object):
    def __init__(self, token):
        self._token = token
        self._createdBy = None
        self._createdOn = None
        self._lastUpdatedBy = None
        self._lastUpdatedOn = None
        self._totalSteps = 0
        self._lastStepCompleted = 0

    @property
    def cmdType(self):
        return self.__class__.__name__

    @property
    def token(self):
        return self._token

    @token.setter
    def token(self, value):
        self._token = value

    @property
    def createdBy(self):
        return self._createdBy

    @createdBy.setter
    def createdBy(self, value):
        self._createdBy = value
        self._lastUpdatedBy = value

    @property
    def createdOn(self):
        return self._createdOn

    @createdOn.setter
    def createdOn(self, value):
        self._createdOn = value
        self._lastUpdatedOn = value

    @property
    def lastUpdatedBy(self):
        return self._lastUpdatedBy

    @lastUpdatedBy.setter
    def lastUpdatedBy(self, value):
        self._lastUpdatedBy = value

    @property
    def lastUpdatedOn(self):
        return self._lastUpdatedOn

    @lastUpdatedOn.setter
    def lastUpdatedOn(self, value):
        self._lastUpdatedOn = value

    @property
    def totalSteps(self):
        return self._totalSteps

    @totalSteps.setter
    def totalSteps(self, value):
        self._totalSteps = value

    @property
    def lastStepCompleted(self):
        return self._lastStepCompleted

    @lastStepCompleted.setter
    def lastStepCompleted(self, value):
        self._lastStepCompleted = value


class EnrollImagesFromVideoCommand(BaseCommand):

    @property
    def imageRef(self):
        return self._imageRef

    @imageRef.setter
    def imageRef(self, value):
        #assert isinstance(value, entities.ImageRef)
        self._imageRef = value


    @property
    def faceQualityScoreThreshold(self):
        return self._faceQualityScoreThreshold

    @faceQualityScoreThreshold.setter
    def faceQualityScoreThreshold(self, value):
        self._faceQualityScoreThreshold = value


    @property
    def faces(self):
        return self._faces

    @faces.setter
    def faces(self, value):
        #assert isinstance(value, entities.FaceSet)
        self._faces = value


    @property
    def ProgressInfo(self):
        return self._ProgressInfo

    @ProgressInfo.setter
    def ProgressInfo(self, value):
        self._ProgressInfo = value

    @property
    def callResults(self):
        return self._callResults

    @callResults.setter
    def callResults(self, value):
        # assert isinstance(value, entities.FaceSet)
        self._callResults = value

    @property
    def originalFileName(self):
        return self._originalFileName

    @originalFileName.setter
    def originalFileName(self, value):
        # assert isinstance(value, entities.FaceSet)
        self._originalFileName = value


class ErrorCommand(BaseCommand):
    @property
    def errorMessage(self):
        return self._errorMessage

    @errorMessage.setter
    def errorMessage(self, value):
        self._errorMessage = value


class CommandsEncoder(json.JSONEncoder):
    def default(self, obj):
        if hasattr(obj, "toJson"):
            return self.default(obj.toJson())
        elif hasattr(obj, "__dict__"):
            d = dict(
                (key, value)
                for key, value in inspect.getmembers(obj)
                # if not key.startswith("__")
                if not key.startswith("_")
                and not inspect.isabstract(value)
                and not inspect.isbuiltin(value)
                and not inspect.isfunction(value)
                and not inspect.isgenerator(value)
                and not inspect.isgeneratorfunction(value)
                and not inspect.ismethod(value)
                and not inspect.ismethoddescriptor(value)
                and not inspect.isroutine(value)
            )
            return self.default(d)
        return obj


class CommandsDecoder(json.JSONDecoder):
    def decode(self, json_string):
        command = super(CommandsDecoder, self).decode(json_string)

        if "cmdType" in command and command["cmdType"] == "EnrollImagesFromVideoCommand":
            decoded = EnrollImagesFromVideoCommand(command["token"])
            self._set_command_basic_props(decoded, command)
            self._set_command_imageRef_prop(decoded, command)
            decoded.faceQualityScoreThreshold = self._safe_get("faceQualityScoreThreshold", command)
            decoded.faces = self._safe_get("faces", command)
            decoded.callResults = self._safe_get("callResults", command)
            decoded.ProgressInfo = self._safe_get("ProgressInfo", command)
            decoded.autoConfirm = self._safe_get("autoConfirm", command)
            decoded.tags = self._safe_get("tags", command)
            decoded.sienaRefs = self._safe_get("sienaRefs", command)
            decoded.focalPoints = self._safe_get("focalPoints", command)
            decoded.originalFileName = self._safe_get("originalFileName", command)
        else:
            decoded = command

        return decoded

    def _set_command_basic_props(self, command, dictio):
        command.createdBy = self._safe_get("createdBy", dictio)
        command.createdOn = self._safe_get("createdOn", dictio)
        command.lastUpdatedBy = self._safe_get("lastUpdatedBy", dictio)
        command.lastUpdatedOn = self._safe_get("lastUpdatedOn", dictio)
        command.totalSteps = self._safe_get("totalSteps", dictio)
        command.lastStepCompleted = self._safe_get("lastStepCompleted", dictio)

    def _set_command_imageRef_prop(self, command, dictio):
        command.imageRef = entities.ImageRef()
        if "imageRef" in dictio:
            command.imageRef.refType = self._safe_get("refType", dictio["imageRef"])
            command.imageRef.imagePath = self._safe_get("imagePath", dictio["imageRef"])
            command.imageRef.imageId = self._safe_get("imageId", dictio["imageRef"])

    def _safe_get(self, prop_name, dictio):
        if prop_name in dictio:
            return dictio[prop_name]
        else:
            return None
