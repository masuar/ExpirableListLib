import os
import json
import logging.config
import optparse
import traceback
import sys

import util
import scpyfr.services as fr_services
import processor

def main(opts, args):
    config = util.readVideoConf("video_svc.ini")
    log = util.setupLogging(inst_name=config.name, verbose=config.verbose)

    config.apiserver=opts.faceApiServer
    config.apiuser=opts.faceApiUser
    config.apiuserpwd=opts.faceApiPwd
    config.server=opts.momServer
    config.user=opts.momUser
    config.pwd=opts.momPwd
    config.verbose = opts.verbose

    log.info("Loading...")
    log.warn("Some configuration values are overriden by arguments passed (or their default value).")
    msg = "Configuration read / overriden: \n"
    for conf in config.__dict__:
        msg += '{} = {};\n'.format(conf, config.__dict__[conf])
    log.debug(msg)

    faceextractor = fr_services.FacenetFaceExtractor(config.models, config.faceMinSize, config.faceFinalSize, log)
    videoEngine = processor.VideoEngineCommandProcessor(faceextractor, config, log)

    log.info('Service started!')
    videoEngine.start()

if __name__ == "__main__":
    parser = optparse.OptionParser(usage = "usage: %prog [options]", description = "Listen to Knn Engine AMQP messages to process.")
    parser.add_option("-s", "--faceApiServer", default = "http://localhost:34456", help = "Face API server (default %default)")
    parser.add_option("-u", "--faceApiUser", default = "erpl", help = "Face API server user (default %default)")
    parser.add_option("-p", "--faceApiPwd", default = "ABCabc123.", help = "Face API server pwd (default %default)")

    parser.add_option("--momServer", default = "localhost", help = "Stomp server (default %default)")
    parser.add_option("--momUser", default = "admin", help = "Stomp server user (default %default)")
    parser.add_option("--momPwd", default = "admin", help = "Stomp server pwd (default %default)")

    parser.add_option("-v", "--verbose", action='store_true', help="verbose mode")

    opts, args = parser.parse_args()

    main(opts, args)
