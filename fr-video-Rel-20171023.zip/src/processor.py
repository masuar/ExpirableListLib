import json
import uuid
import time
import os.path
import hashlib
import datetime
from scipy import misc

import commands
from scpymsg import stompestcon as stompestcon
from video2img import VideoSplitter

class VideoEngineCommandProcessor(stompestcon.StompestMessageProcessor):
    def __init__(self, faceextractor, conf, log=None):
        super(VideoEngineCommandProcessor, self).__init__(conf, log)
        self._config = conf
        self._log = log
        self._faceExtractor = faceextractor

    def onRecovered(self):
        self._log.info("Recovered!")

    def onReceived(self, routingKey, body):
        self._log.debug("[onReceived]=========================BEGIN================================================")
        try:
            cmd = json.loads(body, cls=commands.CommandsDecoder)
            if routingKey != "SmartCaps.FR.Status":
                self._log.info("Video: " + cmd.imageRef.imagePath)
                self._log.info("Reducing process started...")
                self._log.debug("Initializing VideoSplitter...")
                v = VideoSplitter(cmd.imageRef.imagePath, self._config.workingdir, self._log)

                self._log.debug("Video Splitting started")
                #cmd.ProgressInfo = "Video Splitting started"
                #self.send(routingKey + '.VideoProgress', json.dumps(cmd, cls=commands.CommandsEncoder))
                count = v.split_with_open_cv()
                self._log.info("Video reduced to {} images (video splitter).".format(count))

                self._log.debug("Histogram Reductor Started")
                #cmd.ProgressInfo = "Histogram Reductor Started"
                #self.send(routingKey + '.VideoProgress', json.dumps(cmd, cls=commands.CommandsEncoder))
                count = v.reduce_by_comparing(80)
                self._log.info("Video reduced to {} images (histogram reductor).".format(count))

                self._log.debug("FaceFind Reductor started")
                #cmd.ProgressInfo = "FaceFind Reductor started"
                #self.send(routingKey + '.VideoProgress', json.dumps(cmd, cls=commands.CommandsEncoder))
                count = v.reduce_by_facelookup(self._faceExtractor, cmd.faceQualityScoreThreshold)
                self._log.info("Video reduced to {} images (facefind reductor).".format(count))

                self._log.info("Reducing process finished. Sending results to API...")
                results = []
                ReqFailed = []
                total = os.listdir(v.WORKING_DIR).count
                i = 0
                for filename in os.listdir(v.WORKING_DIR):
                    path = os.path.join(v.WORKING_DIR, filename)
                    #cmd.ProgressInfo = "Sending image {} of {} to API".format(i, total)
                    #self.send(routingKey + '.VideoProgress', json.dumps(cmd, cls=commands.CommandsEncoder))
                    respons = v.enroll_img_in_api(path, 
                        cmd.createdBy, 
                        cmd.tags, 
                        cmd.focalPoints, 
                        cmd.sienaRefs, 
                        cmd.faceQualityScoreThreshold, 
                        cmd.originalFileName, 
                        self._config.apiserver,
                        self._config.apiuser, 
                        self._config.apiuserpwd)
                    try:
                        results.extend(respons['notFinished'])
                        results.extend(respons['failed'])
                        results.extend(respons['success'])
                        i += 1
                    except:
                        ReqFailed.extend(respons)

                cmd.callResults = {'results': results, 'message': ReqFailed}
                self._log.info("Process asked for {} images ingestion.".format(i))
            else:
                 pass

            cmd.lastStepCompleted = 1
            cmd.lastUpdatedBy = "{} ({})".format(self.__class__.__name__, self.name)
            cmd.lastUpdatedOn = self._getIsoFormat(datetime.datetime.utcnow())
            cmd.ProgressInfo = "Done"
            cmdMsg = json.dumps(cmd, cls=commands.CommandsEncoder)
            self.send(routingKey + '.VideoDone', cmdMsg)
            self._log.info("Video done.")

        except Exception as ex:
            self._log.error("Error while processing message '{}': {}.".format(body, ex))
            errorMsg = self._compileErrorMsg(body, ex)
            self.send(routingKey + '.Error', errorMsg)
            self._log.warning("Error message sent.")
        self._log.debug("[onReceived]=========================END================================================")

    def _compileErrorMsg(self, msgBody, ex):
        rawCmd = json.loads(msgBody)
        token = rawCmd["token"]
        errorCmd = commands.ErrorCommand(token)
        errorCmd.createdBy = "{} ({})".format(self.__class__.__name__, self.name)
        errorCmd.createdOn = self._getIsoFormat(datetime.datetime.utcnow())
        if hasattr(ex, 'message'):
            errorCmd.errorMessage = ex.message
        else:
            errorCmd.errorMessage = ex
        error_msg = json.dumps(errorCmd, cls=commands.CommandsEncoder)
        return error_msg

    def _getIsoFormat(self, dt):
        if dt != None:
            return dt.isoformat("T") + "Z"
        else:
            return ""
